"use strict";
const KBConvert=(() => {
  const enc=(t)=>String(t??"").replace(/([\\`*_\[\]<>#])/g,"\\$1");
  const clean=(t)=>String(t??"").replace(/\s+/g," ").trim();
  const safeUrl=(s)=>/^(https?:|\/|#)/i.test(String(s||""))?String(s):"";
  function convert(xml,{sourceBase,pageId,spaceKey,imageWidth=832,imageMode="markdown"}) {
    const references=[],images=[],fileLinks=[],warnings=[];
    // Confluence body.storage is XHTML with self-closing namespaced ac:/ri: tags.
    // Parse as XML first: parsing as text/html corrupts self-closing ri:attachment tags.
    // HTML fallback treats CDATA as a comment and silently erases code-macro
    // bodies AND custom link labels. Decode CDATA in plain-text-body and
    // plain-text-link-body before XML/HTML parsing so a displayed label like
    // 'Kerberos auth' never falls back to the target title 'Keycloak15'.
    const escapeXmlText=(value)=>String(value).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
    const normalized=String(xml).replace(/(<ac:(plain-text-body|plain-text-link-body)\b[^>]*>)([\s\S]*?)(<\/ac:\2>)/gi,
      (whole,start,tagName,content,end)=>start+content.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,(_,code)=>escapeXmlText(code))+end);
    const source=`<kb-root xmlns:ac="http://atlassian.com/content" xmlns:ri="http://atlassian.com/resource/identifier">${normalized.replace(/&nbsp;/gi,"&#160;")}</kb-root>`;
    let doc=new DOMParser().parseFromString(source,"application/xml");
    let root=doc.documentElement;
    if(doc.getElementsByTagName("parsererror").length){
      warnings.push("Storage XHTML invalid ca XML; conversie HTML de rezervă (verifică imaginile/linkurile).");
      doc=new DOMParser().parseFromString(normalized,"text/html");root=doc.body;
    }
    let next=0;
    const mark=(prefix)=>`KBMIGR_${prefix}_${next++}_END`;
    const elt=(node)=>node?.nodeType===1;
    const tag=(node)=>elt(node)?node.tagName.toLowerCase():"";
    const attr=(node,...names)=>{for(const n of names){const v=node?.getAttribute?.(n);if(v!==null&&v!==undefined)return v;}return "";};
    const first=(node,name)=>Array.from(node?.getElementsByTagName?.("*")||[]).find(x=>tag(x)===name)||null;
    // The visible anchor label is not necessarily the target page title or the
    // attachment filename. In Confluence storage these are separate fields.
    // Prefer what the author typed, including inline rich-text link bodies.
    function visibleLinkText(node){
      const explicit=first(node,"ac:plain-text-link-body")||first(node,"ac:link-body");
      if(explicit && clean(explicit.textContent))return clean(explicit.textContent);
      const fragments=[];
      for(const child of Array.from(node.childNodes||[])){
        if(child.nodeType===3){fragments.push(child.nodeValue||"");continue;}
        if(child.nodeType!==1)continue;
        // ri:* nodes describe the TARGET, not the displayed text.
        const childTag=tag(child);
        if(childTag.startsWith("ri:")||childTag==="ac:parameter")continue;
        fragments.push(child.textContent||"");
      }
      return clean(fragments.join(" "));
    }
    // Plain Confluence paragraphs may contain shell commands prefixed with '#'.
    // Outline's Markdown parser can mistake these for headings or other syntax.
    // Keep recognizable standalone commands as *literal* code rather than
    // interpreting their punctuation as Markdown formatting.
    const shellCommand=/^\s*(?:#\s*)?(?:\/\S+|\.\/\S+|(?:sudo\s+)?(?:nginx|apt(?:-get)?|yum|dnf|systemctl|service|chmod|chown|chgrp|tar|cd|cp|mv|rm|ls|mkdir|nano|vim|vi|grep|awk|sed|cat|curl|wget|keytool|java|bduitool|bd|realm|kinit|klist|timedatectl|ufw|firewall-cmd|echo|openssl|mysql|psql|docker|kubectl)\b)/i;
    const quoteInlineCode=(value)=>{const tick='`'.repeat(Math.max(1,(value.match(/`+/g)||[]).reduce((n,x)=>Math.max(n,x.length+1),1)));return tick+value+tick;};
    // A number of legacy Confluence pages contain command lines whose visual
    // layout (CSS and old editor markup) was lost in storage XHTML. Rescue only
    // the unmistakable nginx case: a /etc/nginx path immediately followed by
    // another `grep -R` command, without even one separating character.
    // Never apply this to arbitrary prose or to all path/command combinations.
    function repairJoinedNginxCommands(value){
      const raw=String(value||"").replace(/\r\n?/g,"\n");
      if(!shellCommand.test(raw.trim()) || !(raw.match(/\bgrep\s+-R\b/g)||[]).length)return raw;
      let fixed=0;
      const restored=raw.replace(/(\/etc\/nginx(?:\/modules-enabled\/)?)((?=grep[ \t]+-R\b))/g,(whole,path)=>{fixed++;return path+"\n";});
      if(fixed)warnings.push(`Au fost separate ${fixed} comenzi nginx concatenate în XHTML-ul KB; verifică liniile după actualizare.`);
      return restored;
    }
    function simpleCommandParagraph(node){
      // textContent misses the line breaks introduced by <br> and CSS block
      // wrappers. A paragraph is treated as code only when *every* nonempty
      // line looks like a shell command.
      const allowed=new Set(['br','span','font','strong','b','em','i','code','tt']);
      const safe=(n)=>Array.from(n.childNodes||[]).every(child=>child.nodeType!==1||(allowed.has(tag(child))&&safe(child)));
      if(!safe(node))return null;
      const val=repairJoinedNginxCommands(codeText(node)).trim();
      const lines=val.split('\n').map(x=>x.trim()).filter(Boolean);
      if(!lines.length||!lines.every(l=>shellCommand.test(l)))return null;
      return val;
    }
    // Unlike normal prose, code is whitespace-sensitive. In particular,
    // node.textContent does not include the visual newlines created by <br>.
    // Older Confluence pages often store a whole command list inside one
    // <code> element with <br> children, or in several <code> siblings.
    function codeText(node){
      if(!node)return "";
      if(node.nodeType===3)return node.nodeValue||"";
      if(node.nodeType!==1)return "";
      const t=tag(node);
      if(t==="br")return "\n";
      const content=Array.from(node.childNodes||[]).map(codeText).join("");
      const isBlockSpan=t==='span'&&/\bdisplay\s*:\s*(?:block|list-item)\b/i.test(attr(node,'style'));
      return ["p","div","li","pre","section"].includes(t)||isBlockSpan?content+"\n":content;
    }
    // Only label command-like multiline code as bash, not SQL/JSON snippets.
    function guessCodeLanguage(value){
      const lines=String(value||"").split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
      if(!lines.length)return "";
      return lines.filter(x=>shellCommand.test(x)).length>lines.length/2?"bash":"";
    }
    function codeFence(value,language=""){
      const raw=String(value||"").replace(/\r\n?/g,"\n")
        .replace(/^(?:[ \t]*\n)+/,"").replace(/(?:\n[ \t]*)+$/,"");
      const fence="`".repeat(Math.max(3,(raw.match(/`+/g)||[]).reduce((n,x)=>Math.max(n,x.length+1),3)));
      return "\n"+fence+language+"\n"+raw+"\n"+fence+"\n\n";
    }
    // <p><code>line1</code><br/><code>line2</code></p> must be one
    // multiline code block, not a single inline-code span with lost breaks.
    // Do not interfere with ordinary paragraphs containing inline code.
    function multilineCodeParagraph(node){
      // Confluence sometimes wraps inline <code> nodes in styling <span>s,
      // or places several code nodes next to one another without explicit BRs.
      // Read the code leaves in document order; other text/content must prevent
      // the entire paragraph from being reinterpreted as a code block.
      const atoms=[];
      function visit(n){
        if(n.nodeType===3){if(n.nodeValue.trim())return false;return true;}
        if(n.nodeType!==1)return true;
        const t=tag(n);
        if(t==='br'){atoms.push({kind:'break',value:'\n'});return true;}
        if(t==='code'||t==='tt'){atoms.push({kind:'code',value:codeText(n)});return true;}
        if(t==='span'||t==='font')return Array.from(n.childNodes||[]).every(visit);
        return false;
      }
      if(!Array.from(node.childNodes||[]).every(visit))return null;
      const codes=atoms.filter(x=>x.kind==='code');
      if(!codes.length)return null;
      const implicitBreak=codes.length>1 && codes.every(x=>shellCommand.test(x.value.trim()));
      const explicitBreak=atoms.some(x=>x.kind==='break') || codes.some(x=>/[\r\n]/.test(x.value));
      const combined=codes.map(x=>x.value).join('');
      const hasJoinedNginx=/\/etc\/nginx(?:\/modules-enabled\/)?grep[ \t]+-R\b/.test(combined);
      if(!implicitBreak&&!explicitBreak&&!hasJoinedNginx)return null;
      let raw='';let prevKind='';
      for(const a of atoms){
        if(a.kind==='code'&&prevKind==='code'&&implicitBreak)raw+='\n';
        raw+=a.value;prevKind=a.kind;
      }
      raw=repairJoinedNginxCommands(raw);
      return raw.trim()?codeFence(raw,guessCodeLanguage(raw)):null;
    }
    let codeMacroCount=0,codeMacroConverted=0;const codeBodies=[];
    const render=(node,inline=false)=>{
      if(!node)return "";
      if(node.nodeType===3)return enc(node.nodeValue).replace(/\s+/g," ");
      if(node.nodeType!==1)return "";
      const t=tag(node), kids=()=>Array.from(node.childNodes||[]).map(c=>render(c,inline)).join("");
      if(t==="br")return "  \n";
      if(/^h[1-6]$/.test(t))return "\n"+"#".repeat(Number(t[1]))+" "+clean(kids())+"\n\n";
      if(t==="p"){
        const multiline=multilineCodeParagraph(node);
        if(multiline!==null)return multiline;
        const literal=simpleCommandParagraph(node);
        if(literal){
          if(literal.includes("\n"))return "\n```bash\n"+literal+"\n```\n\n";
          return "\n"+quoteInlineCode(literal)+"\n\n";
        }
        const content=kids().trim();
        // A leading '1.' in an ordinary paragraph is not necessarily an
        // ordered-list item; preserve it unless Confluence used <ol>.
        const safe=content.replace(/^(\d{1,3})([.)])(?=\s)/,(_,n,mark)=>n+"\\"+mark);
        return "\n"+safe+"\n\n";
      }
      // Empty bold/italic wrappers are common in older Confluence 6.x pages.
      // Wrapping an empty <strong><br /></strong> produces bare ** lines in
      // Outline. For formatted text spanning multiple paragraphs, wrap each
      // nonempty line instead of putting the delimiters on their own lines.
      if(t==="strong"||t==="b"||t==="em"||t==="i"){
        const marker=(t==="strong"||t==="b")?"**":"*";
        const content=kids();
        if(!clean(node.textContent))return content;
        const wrapLine=(line)=>{
          const m=/^(\s*)([\s\S]*?)(\s*)$/.exec(line);
          if(!m||!m[2].trim())return line;
          return m[1]+marker+m[2]+marker+m[3];
        };
        // Markdown cannot sensibly make an entire fenced code block bold.
        if(/(?:^|\n)\s*`{3,}/.test(content))return content;
        return content.includes("\n")?content.split("\n").map(wrapLine).join("\n"):wrapLine(content);
      }
      if(t==="u")return kids();
      if(t==="code"||t==="tt"){
        const raw=repairJoinedNginxCommands(codeText(node));
        if(raw.includes("\n"))return codeFence(raw,guessCodeLanguage(raw));
        return raw.trim()?quoteInlineCode(raw.trim().replace(/\s+/g," ")):"";
      }
      if(t==="pre")return codeFence(repairJoinedNginxCommands(codeText(node)));
      if(t==="blockquote")return "\n"+kids().trim().split("\n").map(x=>"> "+x).join("\n")+"\n\n";
      if(t==="hr")return "\n---\n\n";
      if(t==="ul"||t==="ol"){
        // Never call clean() on a list item's full output: it turns multiline
        // code fences into a single line and corrupts embedded code/macros.
        return "\n"+Array.from(node.children).filter(c=>tag(c)==="li").map((li,i)=>{
          const bullet=t==="ul"?"- ":`${i+1}. `;
          const content=Array.from(li.childNodes||[]).map(child=>render(child,true)).join("").trim();
          if(!content)return bullet.trim();
          const lines=content.split("\n");
          const first=lines.shift();
          // The blank line before a fenced code block is important for
          // Markdown parsers (including Outline/ProseMirror).
          return bullet+first+lines.map(line=>"\n"+(line?" ".repeat(bullet.length)+line:"")).join("");
        }).join("\n")+"\n\n";
      }
      if(t==="table"){
        const rows=Array.from(node.querySelectorAll("tr")).map(tr=>Array.from(tr.children).filter(c=>["td","th"].includes(tag(c))).map(c=>clean(render(c,true)).replace(/\|/g,"\\|")));
        if(!rows.length)return "";
        const cols=Math.max(...rows.map(r=>r.length));
        const line=(r)=>"| "+Array.from({length:cols},(_,i)=>r[i]||" ").join(" | ")+" |";
        return "\n"+line(rows[0])+"\n"+line(Array(cols).fill("---"))+"\n"+rows.slice(1).map(line).join("\n")+"\n\n";
      }
      if(t==="ac:image"||t==="img"){
        const ri=first(node,"ri:attachment");
        const filename=attr(ri,"ri:filename")||"";
        const src=t==="img"?attr(node,"src"):attr(first(node,"ri:url"),"ri:value");
        const token=mark("IMAGE");
        const linkedPage=first(ri,"ri:page");
        images.push({token,filename,src,sourcePageId:attr(linkedPage,"ri:content-id")||attr(ri,"ri:content-id"),
          sourcePageTitle:attr(linkedPage,"ri:content-title"),sourceSpaceKey:attr(linkedPage,"ri:space-key")||spaceKey,
          alt:attr(node,"alt","ac:alt")||filename||"Imagine",width:attr(node,"ac:width","width")});
        return "\n"+token+"\n\n";
      }
      if(t==="ac:link"||t==="a"){
        const ri=first(node,"ri:page"),attachment=first(node,"ri:attachment"),anchor=first(node,"ri:anchor");
        const body=first(node,"ac:plain-text-link-body")||first(node,"ac:link-body");
        const authorLabel=visibleLinkText(node);
        const label=authorLabel||clean(attr(ri,"ri:content-title")||attr(attachment,"ri:filename")||"Deschide")||"Deschide";
        if(attachment){
          const token=mark("FILE");
          // An attachment may belong to ANOTHER Confluence page. In that case
          // it is a reference, not an attachment missing from this page.
          const linkedPage=first(attachment,"ri:page");
          fileLinks.push({token,filename:attr(attachment,"ri:filename"),label,labelExplicit:!!authorLabel,
            sourcePageId:attr(linkedPage,"ri:content-id")||attr(attachment,"ri:content-id"),
            sourcePageTitle:attr(linkedPage,"ri:content-title"),
            sourceSpaceKey:attr(linkedPage,"ri:space-key")||spaceKey});
          return token;
        }
        // Confluence external links often use <ac:link><ri:url ri:value="https://..." />
        // rather than HTML <a href="...">. Preserve their URL in Outline.
        const resourceUrl=first(node,"ri:url");
        const href=t==="a"?attr(node,"href"):attr(resourceUrl,"ri:value");
        // Links to Confluence attachment downloads may be plain HTML anchors,
        // not <ri:attachment>. Treat them as file transfers, not page links.
        if(href){
          try{
            const resolved=new URL(href,sourceBase.replace(/\/$/,"")+"/");
            const b=new URL(sourceBase);
            const prefix=b.pathname.replace(/\/$/,"")+"/download/attachments/";
            if(resolved.origin===b.origin&&resolved.pathname.startsWith(prefix)){
              const pieces=resolved.pathname.slice(prefix.length).split("/");
              if(pieces.length===2&&/^\d+$/.test(pieces[0])){
                const token=mark("FILE");
                fileLinks.push({token,filename:decodeURIComponent(pieces[1]),label,labelExplicit:!!authorLabel,
                  sourcePageId:pieces[0],directUrl:resolved.href});
                return token;
              }
            }
          }catch(_){}
        }
        const title=attr(ri,"ri:content-title"),space=attr(ri,"ri:space-key")||spaceKey;
        const contentId=attr(ri,"ri:content-id");
        if(ri||href){const token=mark("LINK");references.push({token,label,labelExplicit:!!authorLabel,contentTitle:title,contentId,spaceKey:space,href,anchor:attr(anchor,"ri:anchor")});return `[${enc(label)}](${token})`;}
        return enc(label);
      }
      if(t==="ac:task-list"){
        const tasks=Array.from(node.getElementsByTagName("*")).filter(x=>tag(x)==="ac:task");
        return "\n"+tasks.map(task=>{
          const status=first(task,"ac:task-status")?.textContent?.trim()?.toLowerCase()||"";
          const content=first(task,"ac:task-body");
          const body=content?clean(content.textContent):"";
          return `- [${["complete","completed","done"].includes(status)?"x":" "}] ${enc(body)}`;
        }).join("\n")+"\n\n";
      }
      if(t==="ac:structured-macro"){
        const name=attr(node,"ac:name");
        const plain=first(node,"ac:plain-text-body");
        if(["view-file","viewpdf"].includes(name)){
          // Confluence embeds a PDF using a view-file macro. Outline Markdown
          // cannot reproduce its PDF viewer, but must keep a usable file link
          // and let the upload stage migrate the same attachment.
          const parameter=Array.from(node.getElementsByTagName("*")).find(x=>tag(x)==="ac:parameter"&&["name","file"].includes(attr(x,"ac:name")));
          const attachment=first(parameter||node,"ri:attachment");
          const filename=attr(attachment,"ri:filename")||clean(parameter?.textContent||"");
          const linkedPage=first(attachment,"ri:page");
          if(filename){
            const token=mark("FILE");
            fileLinks.push({token,filename,label:filename,labelExplicit:true,
              sourcePageId:attr(linkedPage,"ri:content-id")||attr(attachment,"ri:content-id"),
              sourcePageTitle:attr(linkedPage,"ri:content-title"),sourceSpaceKey:attr(linkedPage,"ri:space-key")||spaceKey});
            warnings.push("Previzualizarea PDF Confluence a fost înlocuită cu link către fișier: "+filename);
            return "\n"+token+"\n\n";
          }
          warnings.push("Macro view-file fără nume de fișier; necesită verificare manuală.");
          return "\n[Previzualizare fișier Confluence – verificare manuală]\n\n";
        }
        if(["code","noformat"].includes(name)){
          codeMacroCount++;
          if(!plain || !plain.textContent.trim()){
            warnings.push("BLOCANT: macro de cod gol sau necitit din Confluence ("+name+").");
            return "\n[COD CONFLUENCE NECONVERTIT]\n\n";
          }
          codeMacroConverted++;
          const langNode=Array.from(node.getElementsByTagName("*")).find(x=>tag(x)==="ac:parameter"&&attr(x,"ac:name")==="language");
          const rawLang=(langNode?.textContent||"").trim().toLowerCase();
          const lang=/^[a-z0-9_+.#-]{1,24}$/i.test(rawLang)?rawLang:"";
          const code=repairJoinedNginxCommands(plain.textContent).replace(/^\n+|\n+$/g,"");
          codeBodies.push(code);
          const fence="`".repeat(Math.max(3,(code.match(/`+/g)||[]).reduce((a,x)=>Math.max(a,x.length+1),3)));
          return "\n"+fence+lang+"\n"+code+"\n"+fence+"\n\n";
        }
        if(["info","note","warning","tip","panel","expand"].includes(name)){
          const content=first(node,"ac:rich-text-body");
          if(!content){warnings.push("Macro fără conținut convertibil: "+name);return "\n[Macro de verificat: "+name+"]\n\n";}
          return "\n> "+render(content,true).trim().replace(/\n/g,"\n> ")+"\n\n";
        }
        if(name==="toc")return "";
        if(name==="status"){
          const title=Array.from(node.getElementsByTagName("*")).find(x=>tag(x)==="ac:parameter"&&attr(x,"ac:name")==="title");
          const statusText=title?.textContent?.trim()||"";
          return /^MIGRAT ÎN OUTLINE$|^EXCLUS DIN MIGRARE$/i.test(statusText)?"":` **[${enc(statusText||"STATUS")}]** `;
        }
        warnings.push(`Macro Confluence nerecunoscut: ${name||"fără nume"}; verificare manuală necesară.`);
        return "\n[Macro Confluence de verificat: "+enc(name||"necunoscut")+"]\n\n";
      }
      if(t==="script"||t==="style")return "";
      if(["div","section","article","ac:rich-text-body"].includes(t))return "\n"+kids()+"\n";
      return kids();
    };
    let out=Array.from(root.childNodes).map(n=>render(n)).join("");
    // Last line of defence for malformed Confluence XHTML or unsupported
    // nesting: remove only standalone generated emphasis markers OUTSIDE code.
    // Literal asterisks from the source are escaped, and code is untouched.
    let emphasisFenceLength=0;
    let orphanEmphasis=0;
    out=out.split("\n").filter((line)=>{
      const marker=/^\s*(`{3,})(.*)$/.exec(line);
      if(marker){
        if(!emphasisFenceLength)emphasisFenceLength=marker[1].length;
        else if(marker[1].length>=emphasisFenceLength&&!marker[2].trim())emphasisFenceLength=0;
      }
      if(!emphasisFenceLength && /^\s*(?:\*\*|\*|\*\*\*\*)\s*$/.test(line)){
        orphanEmphasis++;
        return false;
      }
      return true;
    }).join("\n");
    if(orphanEmphasis)warnings.push(`Au fost eliminate ${orphanEmphasis} marcaje Markdown orfane provenite din formatarea Confluence.`);
    // Collapse excessive paragraph gaps, but never the intentional blank
    // lines inside fenced code or they would change the pasted commands.
    let fenceLength=0,blankCount=0;
    const spaced=[];
    for(const line of out.split("\n")){
      const fenceMatch=/^\s*(`{3,})(.*)$/.exec(line);
      if(fenceMatch){
        if(!fenceLength)fenceLength=fenceMatch[1].length;
        else if(fenceMatch[1].length>=fenceLength&&!fenceMatch[2].trim())fenceLength=0;
      }
      if(!fenceLength&&!line.trim()){
        if(blankCount>=1)continue;
        blankCount++;
      }else blankCount=0;
      spaced.push(line);
    }
    out=spaced.join("\n").trim();
    if(/\/etc\/nginx(?:\/modules-enabled\/)?grep[ \t]+-R\b/.test(out))
      warnings.push('BLOCANT: comenzi nginx concatenate au rămas în rezultatul conversiei. Nu actualiza Outline înainte de verificarea XHTML sursă.');
    return {text:out,references,images,fileLinks,warnings,codeMacroCount,codeMacroConverted,codeBodies};
  }
  function escXml(s){return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");}
  function markBlock(type,user,when,extra){
    const status=type==="M"?"MIGRAT ÎN OUTLINE":"EXCLUS DIN MIGRARE";
    const col=type==="M"?"Green":"Grey";
    const lines=type==="M"?`<p><strong>Destinație Outline:</strong> <a href="${escXml(extra)}">${escXml(extra)}</a></p>`:
      `<p><strong>Motiv:</strong> ${escXml(extra)}</p>`;
    return `<ac:structured-macro ac:name="status" ac:schema-version="1"><ac:parameter ac:name="title">${status}</ac:parameter><ac:parameter ac:name="colour">${col}</ac:parameter></ac:structured-macro>`+
      `<p><strong>KB → Outline</strong> | Responsabil: ${escXml(user)} | Data: ${escXml(when)}</p>${lines}<hr />`;
  }
  function stripExistingBlock(xml){
    // Confluence may rewrite attribute order and add ac:macro-id after PUT;
    // the previous exact-string regex silently failed, copying our own KB
    // migration banner into Outline during an UPDATE.
    const original=String(xml||'');
    let tail=original;
    const macro=/^\s*<ac:structured-macro\b(?=[^>]*\bac:name\s*=\s*["']status["'])[^>]*>[\s\S]*?<\/ac:structured-macro>\s*/i.exec(tail);
    if(!macro)return original;
    if(!/MIGRAT\s+ÎN\s+OUTLINE|EXCLUS\s+DIN\s+MIGRARE/i.test(macro[0]))return original;
    tail=tail.slice(macro[0].length);
    const by=/^<p\b[^>]*>[\s\S]*?<strong\b[^>]*>\s*KB\s*(?:→|&rarr;|&#8594;|&#x2192;)\s*Outline\s*<\/strong>[\s\S]*?<\/p>\s*/i.exec(tail);
    if(!by)return original;
    tail=tail.slice(by[0].length);
    const details=/^<p\b[^>]*>\s*<strong\b[^>]*>\s*(?:Destinație\s+Outline|Motiv)\s*:\s*<\/strong>[\s\S]*?<\/p>\s*/i.exec(tail);
    if(!details)return original;
    tail=tail.slice(details[0].length);
    const rule=/^<hr\b[^>]*\/?>\s*/i.exec(tail);
    if(!rule)return original;
    return tail.slice(rule[0].length);
  }
  function canonicalKb(base,pageId){return `${base.replace(/\/$/,"")}/pages/viewpage.action?pageId=${encodeURIComponent(pageId)}`;}
  function provenance(base,pageId,by,iso){return `\n\n---\n\n### Sursă KB\n\n- **Confluence pageId:** ${pageId}\n- **Pagina originală:** [Deschide în KB](${canonicalKb(base,pageId)})\n- **Migrat de:** ${by.replace(/[\[\]\n]/g," ")}\n- **Data migrării:** ${iso}\n`}
  return {convert,markBlock,stripExistingBlock,canonicalKb,provenance};
})();
