"use strict";
const $=(id)=>document.getElementById(id);
const state={sourceTab:0,kb:null,page:null,user:null,attachments:[],renderedAttachmentLinks:[],renderedPageLinks:[],selected:new Set(),preview:null,logs:[],token:"",permissionOrigin:"",mapped:null,outlineBase:"",lastDocument:null,auditPlan:[],repairChoices:new Map(),repairPrevious:null,repairDestId:"",assetSizes:new Map()};
function log(message,level="INFO"){
 const line=`${new Date().toLocaleTimeString("ro-RO")} [${level}] ${message}`;
 state.logs.push(line); $("log").textContent=state.logs.slice(-150).join("\n");$("log").scrollTop=$("log").scrollHeight;
}
function note(message,bad=false){$("notice").textContent=message;$("notice").className="notice "+(bad?"bad":"good");}
function fail(e){const m=String(e?.message||e);log(m,"EROARE");note(m,true);return m;}
function showTab(name){
 const allowed=["migrate","evaluate","links","settings","log"];
 if(!allowed.includes(name))name="migrate";
 for(const k of allowed){
  const tab=document.getElementById("tab"+k[0].toUpperCase()+k.slice(1));
  const btn=document.getElementById("tabButton"+k[0].toUpperCase()+k.slice(1));
  tab.hidden=k!==name;btn.classList.toggle("active",k===name);btn.setAttribute("aria-selected",String(k===name));
 }
}
for(const t of document.querySelectorAll(".tab[data-tab]"))t.addEventListener("click",()=>showTab(t.dataset.tab));
function migrationState(page=state.page, mapping=state.mapped){
 const prefix=String(page?.title||"").match(/^\[(M|X)\](?:\s|$)/i)?.[1]?.toUpperCase();
 const mapped=["M","X","P"].includes(mapping?.status)?mapping.status:"";
 if(prefix && mapped && mapped!==prefix && mapped!=="P")return "CONFLICT";
 // The registry can be marked M while the page PUT has not committed.
 // Recover this as a pending operation, not as a completed migration.
 if(!prefix && mapped==="M")return "P";
 return prefix||mapped||"";
}
function statusText(status){
 if(status==="M")return "Pagina este deja migrată [M]. Migrarea și excluderea sunt blocate. Pentru schimbări, debifează «Părinte» și apasă «Actualizează în Outline» pe pagina existentă.";
 if(status==="X")return "Pagina a fost deja evaluată și exclusă [X]. Nu poate fi migrată sau exclusă încă o dată din extensie.";
 if(status==="P")return "Documentul a fost creat în Outline, dar [M] nu este finalizat. Dacă blocurile de cod sunt goale, folosește întâi «Repară documentul existent»; altfel poți finaliza marcarea [M].";
 if(status==="CONFLICT")return "CONFLICT: prefixul din titlu nu corespunde registrului migrării. Operațiile sunt blocate până la verificare manuală.";
 return "";
}
function statusUI(){
 const status=migrationState();
 const banner=$("statusBanner");const message=statusText(status);
 banner.hidden=!message;banner.textContent=message;
 if(state.page && $("sourceInfo").textContent){
  const lines=$("sourceInfo").textContent.split("\n");lines[0]=state.page.title;
  $("sourceInfo").textContent=lines.join("\n");
 }
 banner.className="statebanner "+(status==="M"?"migrated":status==="X"?"excluded":"pending");
 $("migrate").disabled=!state.page||!!status;
 $("updateExisting").hidden=!(state.page && ["M","P"].includes(status));
 $("updateExisting").disabled=!state.page||$("isParent").checked||!(state.mapped?.outlineUrl||$("destination").value.trim());
 $("exclude").disabled=!state.page||!!status;
 $("migrate").textContent=status?"Stare pagină – nu se poate migra":"Migrează în Outline";
 $("repairContent").hidden=!(state.page && (status==="P" || status==="" || status==="M") && (status!=="M" || !!state.mapped?.outlineUrl));
 $("exclude").textContent=status?"Stare pagină – nu se poate exclude":"Marchează în KB cu [X]";
 if(status==="M"||status==="X"||status==="CONFLICT")$("finalizeKB").hidden=true;
 return status;
}
function notifyLocked(status){
 const message=statusText(status);
 if(!message)return false;
 note(message,true);log(message,"AVERTISMENT");return true;
}
async function freshStatusCheck(){
 const p=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 const property=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId))?.value||null;
 const status=migrationState(p,property);
 if(status){state.page=p;state.mapped=property;statusUI();notifyLocked(status);return {ok:false,status};}
 if(state.page?.version?.number!==p.version?.number){
  state.page=p;state.mapped=property;statusUI();throw new Error("Pagina KB a fost actualizată între timp. Apasă Reîncarcă și verifică din nou.");
 }
 return {ok:true,status:""};
}
function stripTitle(s){return String(s||"").replace(/^\[(?:M|X|NM)\]\s*/i,"").trim();}
function escapeMd(s){return String(s||"").replace(/([\\`*_\[\]<>#])/g,"\\$1");}
function bytesize(n){return n>=1048576?(n/1048576).toFixed(1)+" MB":(n/1024).toFixed(1)+" KB";}
function baseUrl(v){const u=new URL(v);if(!["https:","http:"].includes(u.protocol))throw new Error("URL trebuie să fie HTTP(S)");return u.origin+u.pathname.replace(/\/$/,"");}
function originFor(url){let u=new URL(url);if(!["https:","http:"].includes(u.protocol))throw new Error("Domeniu nepermis.");return `${u.origin}/*`;}
async function saveSettings(){
 const v=baseUrl($("outlineBase").value.trim());
 const token=$("outlineToken").value.trim();
 if(!token)throw new Error("Introdu tokenul Outline.");
 state.token=token;state.outlineBase=v;
 await chrome.storage.local.set({outlineBase:v,rememberToken:$("rememberToken").checked,imageWidth:$("imageWidth").value,imageMode:$("imageMode").value});
 await chrome.storage.session.set({outlineToken:token});
 if($("rememberToken").checked){await chrome.storage.local.set({outlineToken:token});log("Token salvat persistent pe acest profil Chrome (nu este criptat la nivel de extensie).","AVERTISMENT");}
 else await chrome.storage.local.remove("outlineToken");
 note("Setările Outline au fost salvate.");
}
async function restoreSettings(){
 const local=await chrome.storage.local.get(["outlineBase","outlineToken","rememberToken","imageWidth","imageMode"]);
 const session=await chrome.storage.session.get("outlineToken");
 $("outlineBase").value=local.outlineBase||"";
 $("outlineToken").value=session.outlineToken||local.outlineToken||"";
 $("rememberToken").checked=!!local.rememberToken;
 $("imageWidth").value=local.imageWidth||"832";
 $("imageMode").value=local.imageMode||"markdown";
 state.outlineBase=local.outlineBase||"";state.token=$("outlineToken").value;
}
async function permissionForOutline(ask=false){
 const u=originFor($("outlineBase").value.trim());
 if(await chrome.permissions.contains({origins:[u]}))return true;
 if(!ask)throw new Error("Nu există permisiune Chrome pentru Outline. Apasă «Testează Outline» și permite accesul la domeniu.");
 if(!(await chrome.permissions.request({origins:[u]})))throw new Error("Nu a fost acordat accesul Chrome la domeniul Outline.");
 return true;
}
async function outlineCall(op,data){
 const b=baseUrl($("outlineBase").value.trim());
 if(!(await chrome.permissions.contains({origins:[originFor(b)]})))throw new Error("Permisiune Chrome Outline lipsă; apasă «Testează Outline».");
 const token=$("outlineToken").value.trim();if(!token)throw new Error("Token Outline lipsă.");
 const url=b+"/api/"+op;
 const r=await fetch(url,{method:"POST",headers:{Authorization:"Bearer "+token,"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(data||{}),cache:"no-store"});
 const raw=await r.text();let body;
 try{body=JSON.parse(raw);}catch(_){throw new Error(`Outline ${op}: răspuns non-JSON HTTP ${r.status} (${raw.slice(0,100)})`);}
 if(!r.ok || body.success===false || body.ok===false)throw new Error(`Outline ${op} HTTP ${r.status}: ${body.message||body.error||JSON.stringify(body).slice(0,240)}`);
 return body.data??body;
}
function outlineId(link){
 const u=new URL(link);const ob=new URL(baseUrl($("outlineBase").value.trim()));
 if(u.origin!==ob.origin)throw new Error("Linkul destinație nu aparține serverului Outline configurat.");
 const slug=decodeURIComponent(u.pathname.split("/").filter(Boolean).pop()||"");
 if(!slug)throw new Error("Link Outline fără identificator de document.");
 return slug;
}
async function outlineInfo(link){
 const id=outlineId(link);
 try{return await outlineCall("documents.info",{id});}
 catch(e){try{return await outlineCall("documents.info",{id:link});}
 catch(_){throw new Error("Documentul Outline nu a fost găsit sau nu ai acces. Verifică linkul. Detalii: "+e.message);}}
}
function finalOutlineLink(doc){
 const b=baseUrl($("outlineBase").value.trim());
 if(!doc?.url && !doc?.id)throw new Error("Outline nu a returnat URL-ul/ID-ul documentului.");
 return doc.url?new URL(doc.url,b+"/").href:b+"/doc/"+doc.id;
}
async function testOutline(){
 // Permission request is the first operation inside the user's button click.
 const pattern=originFor($("outlineBase").value.trim());
 if(!(await chrome.permissions.request({origins:[pattern]})))throw new Error("Chrome nu a acordat accesul la Outline.");
 await saveSettings();
 const user=await outlineCall("auth.info",{});
 note("Outline API funcționează. Cont: "+(user?.user?.name||user?.user?.email||user?.name||"autentificat"));
 log("Outline API confirmat pentru utilizatorul curent.");
}
async function loadKb(){
 if(!state.sourceTab)throw new Error("Nu am identificat fila activă. Deschide o pagină Confluence KB și redeschide extensia.");
 const kb=await KBBridge.detect(state.sourceTab);
 if(!kb.pageId)throw new Error("Nu s-a identificat pageId. Deschide o pagină Confluence validă.");
 state.kb=kb;
 state.user=await KBBridge.getUser(state.sourceTab,kb.baseUrl);
 state.page=await KBBridge.getPage(state.sourceTab,kb.baseUrl,kb.pageId);
 state.attachments=await KBBridge.getAttachments(state.sourceTab,kb.baseUrl,kb.pageId);
 try{state.renderedAttachmentLinks=await KBBridge.getRenderedAttachmentLinks(state.sourceTab);}
 catch(e){state.renderedAttachmentLinks=[];log("Nu am putut citi linkurile către atașamentele din alte pagini: "+e.message,"AVERTISMENT");}
 try{state.renderedPageLinks=await KBBridge.getRenderedPageLinks(state.sourceTab);}
 catch(e){state.renderedPageLinks=[];log("Nu am putut citi textele linkurilor din pagina afișată: "+e.message,"AVERTISMENT");}
 state.selected=new Set(state.attachments.map(f=>f.id));
 state.mapped=(await KBBridge.getProperty(state.sourceTab,kb.baseUrl,kb.pageId))?.value||null;
 if(["P"].includes(state.mapped?.status)&&state.mapped.outlineUrl){
  $("finalizeKB").hidden=false;
  $("destination").value=state.mapped.outlineUrl;
  $("isParent").checked=false;
  $("existingActions").hidden=false;
 }
 else if(state.mapped?.status==="M"&&state.mapped.outlineUrl){
  $("finalizeKB").hidden=/^\[M\]/i.test(state.page.title);
  $("destination").value=state.mapped.outlineUrl;
  $("isParent").checked=false;
  $("existingActions").hidden=false;
 }
 else $("finalizeKB").hidden=true;
 state.assetSizes.clear();state.preview=null;state.repairChoices.clear();state.repairPrevious=null;state.repairDestId="";hideRepairChoices();$("reviewed").checked=false;
 $("userName").textContent=`Confluence: ${state.user.displayName||state.user.username} (${state.user.username})`;
 let summary=`${state.page.title}\npageId: ${kb.pageId}\nVersiune KB: ${state.page.version?.number}\nFișiere: ${state.attachments.length}\nSursă stabilă: ${KBConvert.canonicalKb(kb.baseUrl,kb.pageId)}`;
 if(state.mapped?.status==="M")summary+=`\nDEJA MIGRATĂ: ${state.mapped.outlineUrl||"Destinație necunoscută"}`;
 if(state.mapped?.status==="P")summary+=`\nTRANSFERATĂ, ÎN AȘTEPTAREA VALIDĂRII: ${state.mapped.outlineUrl}`;
 if(state.mapped?.status==="X")summary+="\nEXCLUSĂ DIN MIGRARE (X)";
 $("sourceInfo").textContent=summary;
 $("attachmentBox").hidden=!state.attachments.length;$("noAttachments").hidden=!!state.attachments.length;
 $("attachmentList").replaceChildren();
 for(const f of state.attachments){
  const row=document.createElement("div");row.className="fileitem";
  const label=document.createElement("label");const ck=document.createElement("input");ck.type="checkbox";ck.checked=true;
  ck.addEventListener("change",()=>{if(ck.checked)state.selected.add(f.id);else state.selected.delete(f.id);state.preview=null;});
  const name=document.createElement("span");name.textContent=" "+f.title;label.append(ck,name);
  const size=document.createElement("span");size.className="filesize";size.textContent=bytesize(f.extensions?.fileSize||0);
  row.append(label,size);$("attachmentList").append(row);
 }
 const warnings=[];
 if(/^\[M\]/i.test(state.page.title))warnings.push("Pagina are deja prefix [M]. Nu crea automat încă un document Outline.");
 if(/^\[X\]/i.test(state.page.title))warnings.push("Pagina este exclusă [X]; revizuiește decizia înainte de migrare.");
 if(state.mapped?.outlineUrl)warnings.push("Există o destinație în registrul KB: "+state.mapped.outlineUrl);
 $("warnings").hidden=warnings.length===0;$("warnings").textContent=warnings.join("\n");
 log(`KB încărcat: pageId=${kb.pageId}, versiune=${state.page.version.number}, ${state.attachments.length} atașamente.`);
 const st=statusUI();if(st)note(statusText(st),true);else note("Pagina KB a fost detectată și încărcată automat. Verifică destinația și bifează confirmarea.");
 try{await restoreSkippedReport();}catch(e){log("Nu am putut reîncărca raportul anterior: "+e.message,"AVERTISMENT");}
}
// Only Confluence page routes are treated as KB links. Paths on other
// websites (including /display/...) are always ordinary external links.
function kbUrlInfo(href){
 try {
  const u=new URL(href,state.kb?.url||state.kb.baseUrl+"/");
  const b=new URL(state.kb.baseUrl);
  if(u.origin!==b.origin)return {url:u,isKb:false};
  const ctx=b.pathname.replace(/\/$/,"");
  const p=u.pathname;
  const page=p===ctx+"/pages/viewpage.action"||p===ctx+"/viewpage.action";
  const display=p.startsWith(ctx+"/display/");
  return {url:u,isKb:page||display,isPage:page,isDisplay:display,ctx};
 } catch(_){return null;}
}
function hrefPageId(href){
 const inf=kbUrlInfo(href);
 if(!inf?.isPage)return "";
 const id=inf.url.searchParams.get("pageId")||inf.url.searchParams.get("pageID")||"";
 return /^\d+$/.test(id)?id:"";
}
function hrefDisplay(href){
 const inf=kbUrlInfo(href);
 if(!inf?.isDisplay)return null;
 const suffix=inf.url.pathname.slice((inf.ctx+"/display/").length);
 const pos=suffix.indexOf("/");if(pos<0)return null;
 try{return {spaceKey:decodeURIComponent(suffix.slice(0,pos)),contentTitle:decodeURIComponent(suffix.slice(pos+1).replace(/\+/g," "))};}
 catch(_){return null;}
}
async function resolveTitle(space,title){
 const q=new URLSearchParams({spaceKey:space,title,limit:"2"});
 const r=await KBBridge.api(state.sourceTab,state.kb.baseUrl,"content?"+q);
 if(!r.ok)throw new Error("Rezolvare titlu KB: HTTP "+r.status);
 const matches=r.data.results||[];
 return matches.length===1?String(matches[0].id):"";
}
async function resolveKbRef(ref){
 const href=String(ref.href||"");
 const fallbackBase=state.kb?.url||state.kb.baseUrl+"/";
 // External URLs and links to non-page resources must be left untouched.
 // Never attempt to resolve them by a guessed Confluence title.
 if(!ref.contentTitle&&!ref.contentId){
  if(href.startsWith("#"))return {kind:"anchor",id:"",url:href,label:ref.label};
  const parsed=kbUrlInfo(href);
  if(!parsed?.url)return {kind:"invalid",id:"",url:"",unresolved:true,label:ref.label};
  if(!["http:","https:","mailto:"].includes(parsed.url.protocol))return {kind:"invalid",id:"",url:"",unresolved:true,label:ref.label};
  if(!parsed.isKb)return {kind:"external",id:"",url:/^(?:https?:|mailto:)/i.test(href)?href:parsed.url.href,label:ref.label};
 }
 let id=/^\d+$/.test(String(ref.contentId||""))?String(ref.contentId):hrefPageId(href);
 let title=ref.contentTitle,space=ref.spaceKey||state.page?.space?.key||"";
 if(!id){const display=hrefDisplay(href);if(display){title=display.contentTitle;space=display.spaceKey;}}
 if(!id&&title){
  id=await resolveTitle(space,title);
  if(!id)id=await resolveTitle(space,"[M] "+stripTitle(title));
  if(!id)id=await resolveTitle(space,"[X] "+stripTitle(title));
 }
 if(id){
  const prop=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,id))?.value;
  const url=prop?.status==="M"&&prop?.outlineUrl?prop.outlineUrl:KBConvert.canonicalKb(state.kb.baseUrl,id);
  return {kind:"kb",id,url,migrated:prop?.status==="M",excluded:prop?.status==="X",label:ref.label,anchor:ref.anchor||kbUrlInfo(href)?.url?.hash||""};
 }
 if(href){
  const u=new URL(href,fallbackBase);
  if(!["http:","https:","mailto:"].includes(u.protocol))return {kind:"invalid",id:"",url:"",unresolved:true,label:ref.label};
  if(kbUrlInfo(href)?.isKb)return {kind:"kb",id:"",url:u.href,unresolved:true,label:ref.label};
  return {kind:"external",id:"",url:/^(?:https?:|mailto:)/i.test(href)?href:u.href,label:ref.label};
 }
 return {kind:"kb",id:"",url:"",unresolved:true,label:ref.label};
}
// Preserve the *displayed link title* from Confluence. Filename / target
// title is used only as an identity for transfer, never as link text.
function linkLabelForAttachment(f,sourcePageId){
 const label=String(f.label||'').replace(/\s+/g,' ').trim();
 if(f.labelExplicit)return label;
 const id=String(sourcePageId||f.sourcePageId||state.kb.pageId);
 const name=normalFileName(f.filename);
 const links=(state.renderedAttachmentLinks||[]).filter(r=>
   String(r.containerId)===id && normalFileName(r.filename)===name && String(r.displayedText||'').trim());
 const labels=[...new Set(links.map(r=>r.displayedText.replace(/\s+/g,' ').trim()))];
 return labels.length===1?labels[0]:label;
}
function linkLabelForPage(ref,resolved){
 if(ref.labelExplicit)return ref.label;
 const id=String(resolved.id||ref.contentId||'');
 if(!id)return ref.label;
 const candidates=(state.renderedPageLinks||[]).filter(r=>r.contentId===id);
 const labels=[...new Set(candidates.map(r=>r.label).filter(Boolean))];
 return labels.length===1?labels[0]:ref.label;
}
function mediaLink(url,name,isImage,width,mode){
 const alt=escapeMd(name||"Fișier");
 if(isImage && mode==="html")return `<img src="${String(url).replace(/"/g,"&quot;")}" alt="${alt.replace(/"/g,"&quot;")}" width="${width}" />`;
 return isImage?`![${alt}](${url})`:`[${alt}](${url})`;
}
function normalFileName(name){
 return String(name||"").normalize("NFC").trim().toLocaleLowerCase();
}
// Only Confluence attachment URLs under the configured KB may be copied.
// This also covers links embedded as ordinary <a href=".../download/attachments/...">.
function kbAttachmentUrl(href){
 try{
  const u=new URL(href,state.kb?.url||state.kb.baseUrl+"/");
  const b=new URL(state.kb.baseUrl);
  const ctx=b.pathname.replace(/\/$/,"");
  if(u.origin!==b.origin)return null;
  const prefix=ctx+"/download/attachments/";
  if(!u.pathname.startsWith(prefix))return null;
  const rest=u.pathname.slice(prefix.length).split("/");
  if(rest.length!==2||!/^\d+$/.test(rest[0])||!rest[1])return null;
  const filename=decodeURIComponent(rest[1]);
  return {url:u.href,sourcePageId:rest[0],filename};
 }catch(_){return null;}
}
// External-to-page attachment references are distinct from local attachments
// and should keep the actual source URL (Confluence page may be retired later).
async function referencedAttachment(f){
 const key=normalFileName(f.filename);
 const candidates=(state.renderedAttachmentLinks||[]).filter(r=>normalFileName(r.filename)===key);
 const foreign=candidates.filter(r=>/^\d+$/.test(String(r.containerId)) && String(r.containerId)!==String(state.kb.pageId));
 const local=candidates.some(r=>String(r.containerId)===String(state.kb.pageId));
 const direct=f.directUrl||f.src||"";
 // External images/files cannot be reinterpreted as KB attachments by name.
 if(direct){
  try{const u=new URL(direct,state.kb.baseUrl+"/");
   if(u.origin!==new URL(state.kb.baseUrl).origin)return null;
  }catch(_){}
 }
 const fromHref=kbAttachmentUrl(direct);
 const explicitId=/^\d+$/.test(String(f.sourcePageId||""))?String(f.sourcePageId):(fromHref?.sourcePageId||"");
 const crossByTitle=!!f.sourcePageTitle && stripTitle(f.sourcePageTitle).toLocaleLowerCase()!==stripTitle(state.page.title).toLocaleLowerCase();
 // Require a single unambiguous foreign target. A same-name link to multiple
 // foreign resources must be reviewed, not silently sent to the wrong file.
 const destinations=new Map(foreign.map(r=>[String(r.containerId),r.href]));
 if(explicitId===String(state.kb.pageId))return null;
 if(explicitId){
  // A pageId explicitly supplied by Confluence is authoritative, even if an
  // unrelated local attachment happens to have the same filename.
  const match=foreign.find(r=>String(r.containerId)===explicitId);
  if(match)return {url:fromHref?.url||match.href,sourcePageId:explicitId};
  return {url:fromHref?.url||`${state.kb.baseUrl.replace(/\/$/,"")}/download/attachments/${explicitId}/${encodeURIComponent(f.filename)}`,sourcePageId:explicitId};
 }
 if(destinations.size===1 && !local){
  const [id,url]=destinations.entries().next().value;
  return {url,sourcePageId:id};
 }
 if(crossByTitle && !local && destinations.size===0){
  const id=await resolveTitle(f.sourceSpaceKey||state.page.space?.key||"",f.sourcePageTitle);
  if(id && id!==String(state.kb.pageId))
   return {url:`${state.kb.baseUrl.replace(/\/$/,"")}/download/attachments/${id}/${encodeURIComponent(f.filename)}`,sourcePageId:id};
 }
 return null;
}
async function buildPreview(){
 if(!state.page)throw new Error("Citește mai întâi pagina KB.");
 const width=Math.min(3000,Math.max(100,Number($("imageWidth").value)||832));
 const mode=$("imageMode").value;
 const c=KBConvert.convert(KBConvert.stripExistingBlock(state.page.body?.storage?.value||""),{sourceBase:state.kb.baseUrl,pageId:state.kb.pageId,spaceKey:state.page.space?.key,imageWidth:width,imageMode:mode});
 const findings=[...c.warnings];let text=c.text;const resolved=[];
 for(const ref of c.references){
   try{const r=await resolveKbRef(ref);resolved.push(r);
     // Hash fragments belonging to external URLs remain valid and are not warnings.
     if(r.kind==="kb"&&r.anchor)findings.push("Ancoră KB de verificat după migrare: "+ref.label);
     if(r.unresolved&&r.kind==="kb")findings.push("Link către pagină KB neidentificată: "+ref.label);
     if(r.kind==="invalid")findings.push("Link cu adresă/protocol invalid: "+ref.label);
     if(r.excluded)findings.push("Link către pagină exclusă [X]: "+ref.label);
     if(!r.url)findings.push("Link fără destinație: "+ref.label);
     const shown=linkLabelForPage(ref,r);
     if(shown!==ref.label){
       // Only the visible label changes. Never derive it from the target title.
       // Mirror converter.enc() when matching the generated Markdown label.
       const oldMarkup=`[${String(ref.label).replace(/([\\`*_\[\]<>#])/g,"\\$1")}](${ref.token})`;
       if(text.includes(oldMarkup))
         text=text.replace(oldMarkup,`[${String(shown).replace(/([\\`*_\[\]<>#])/g,"\\$1")}](${r.url||"#verificare-link"})`);
       else { log("Etichetă link dificil de corelat: "+ref.label,"AVERTISMENT");text=text.split(ref.token).join(r.url||"#verificare-link"); }
     }else text=text.split(ref.token).join(r.url||"#verificare-link");
   }catch(e){findings.push("Link de verificat: "+ref.label+" ("+e.message+")");text=text.split(ref.token).join(ref.href||"#verificare-link");}
 }
 const attachmentsByName=new Map(state.attachments.map(a=>[normalFileName(a.title),a]));
 const needed=new Map();
 const remoteUploads=new Map();
 function registerRemote(f,foreign){
  const parsed=kbAttachmentUrl(foreign.url);
  if(!parsed||parsed.sourcePageId!==String(foreign.sourcePageId)){
   findings.push("Atașament inter-pagină cu adresă invalidă: "+f.filename);
   return null;
  }
  const key=parsed.sourcePageId+":"+normalFileName(parsed.filename);
  let transfer=remoteUploads.get(key);
  if(!transfer){
   const marker="KBMIGR_REMOTE_FILE_"+remoteUploads.size+"_END";
   transfer={key,title:parsed.filename,_links:{download:parsed.url},sourcePageId:parsed.sourcePageId,marker};
   remoteUploads.set(key,transfer);
  }
  return transfer;
 }
 for(const im of c.images){
  let name=im.filename;
  if(!name && im.src){
   try{const u=new URL(im.src,state.kb.baseUrl+"/");name=decodeURIComponent(u.pathname.split("/").pop()||"");}catch(_){}
  }
  const local=attachmentsByName.get(normalFileName(name));
  const remote=await referencedAttachment({...im,filename:name});
  // An image attached to a different page must be copied, not hot-linked.
  if(remote){
   const item=registerRemote({filename:name},remote);
   if(item)text=text.split(im.token).join(mediaLink(item.marker,im.alt,true,width,mode));
   else text=text.split(im.token).join("[IMAGINE DE VERIFICAT: "+name+"]");
  }else if(local){
   needed.set(String(local.id),local);
   text=text.split(im.token).join(mediaLink(`[UPLOAD:${local.title}]`,im.alt,true,width,mode));
  }else if(im.src){
   const u=new URL(im.src,state.kb.baseUrl+"/");
   if(!["https:","http:"].includes(u.protocol)){
    findings.push("Imagine cu protocol invalid: "+im.src);
    text=text.split(im.token).join("[IMAGINE DE VERIFICAT]");
   }else{
    text=text.split(im.token).join(mediaLink(u.href,im.alt,true,width,mode));
    if(u.origin===new URL(state.kb.baseUrl).origin)findings.push("Imagine KB fără atașament rezolvat: "+im.src);
   }
  }else{
   findings.push("Imagine nedetectată în atașamente: "+name);
   text=text.split(im.token).join("[IMAGINE DE VERIFICAT: "+name+"]");
  }
 }
 for(const f of c.fileLinks){
  const foreign=await referencedAttachment(f);
  const shown=linkLabelForAttachment(f,foreign?.sourcePageId||f.sourcePageId||state.kb.pageId);
  if(foreign){
   const item=registerRemote(f,foreign);
   if(item)text=text.split(f.token).join(mediaLink(item.marker,shown,false,width,mode));
   else text=text.split(f.token).join("[FIȘIER DE VERIFICAT: "+f.filename+"]");
   continue;
  }
  const a=attachmentsByName.get(normalFileName(f.filename));
  if(a){
   needed.set(String(a.id),a);
   text=text.split(f.token).join(mediaLink(`[UPLOAD:${a.title}]`,shown,false,width,mode));
  }else{
   findings.push("Fișier referit, dar nedetectat: "+f.filename+". Nu există o referință sigură către altă pagină KB.");
   text=text.split(f.token).join("[FIȘIER DE VERIFICAT: "+f.filename+"]");
  }
 }
 const selected=state.attachments.filter(a=>state.selected.has(a.id));
 for(const a of selected){
   if(/\.(?:pem|key|p12|pfx|kdbx|env|asc)$/i.test(a.title))findings.push("FIȘIER SENSIBIL selectat: "+a.title);
 }
 for(const a of needed.values())if(!state.selected.has(a.id))findings.push("Atașament folosit în text, dar deselectat: "+a.title);
 const standalone=selected.filter(a=>!needed.has(String(a.id)));
 if($("includeOtherAttachments").checked&&standalone.length){
  text+="\n\n## Fișiere atașate\n\n"+standalone.map(a=>`- [${escapeMd(a.title)}]([UPLOAD:${a.title}])`).join("\n")+"\n";
 }
 // Report only the TYPE of a possible secret. Never print values into
 // the extension's journal (which users may export for troubleshooting).
 const sourceStorage=state.page.body?.storage?.value||"";
 const credentialTypes=[];
 if(/-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/i.test(sourceStorage))credentialTypes.push("cheie privată");
 if(/\bBearer\s+[A-Za-z0-9_\-\.]{15,}/i.test(sourceStorage))credentialTypes.push("Bearer token");
 const fieldRegex=/\b(password|passwd|secret|api[_-]?key|client[_-]?secret)\s*[:=]\s*[^\s<]{5,}/gi;
 const fields=new Set();let keyMatch;
 while((keyMatch=fieldRegex.exec(sourceStorage))!==null && fields.size<6)fields.add(keyMatch[1].toLowerCase());
 if(fields.size)credentialTypes.push("atribuire posibil sensibilă: "+Array.from(fields).join(", "));
 if(credentialTypes.length)findings.push("POSIBILE CREDENȚIALE în KB ("+credentialTypes.join("; ")+"). Verifică valorile în pagina sursă înainte de migrare; valorile nu apar în jurnal.");
 // Content-safety warnings are advisory after the mandatory user confirmation.
 // Missing files/images and incomplete transfers are still blocking.
 const criticalFindings=findings.filter(w=>/deselectat|nedetectată în atașamente|fără atașament rezolvat|fișier referit, dar nedetectat|atașament inter-pagină cu adresă invalidă|BLOCANT: (?:macro de cod|comenzi nginx)/i.test(w));
 text+=KBConvert.provenance(state.kb.baseUrl,state.kb.pageId,state.user.displayName||state.user.username,new Date().toISOString().slice(0,10));
 state.preview={text,conv:c,resolved,findings,criticalFindings,needed,remoteUploads,selected,standalone,width,mode,sourceVersion:state.page.version?.number,
    sourceTitle:state.page.title,sourceStorage};
 const externalCount=resolved.filter(r=>r.kind==="external").length;
 const kbCount=resolved.filter(r=>r.kind==="kb").length;
 log(`Analiză automată: ${c.references.length} linkuri (${externalCount} externe păstrate, ${kbCount} KB), ${c.images.length} imagini, ${selected.length} atașamente selectate.`);
 log(`Macro-uri de cod Confluence: ${c.codeMacroConverted}/${c.codeMacroCount} convertite.`);
 log(`Atașamente din alte pagini KB de copiat în Outline: ${remoteUploads.size}.`);
 const linked=$('linkedAttachments');
 linked.hidden=!remoteUploads.size;
 linked.textContent=remoteUploads.size?"Fișiere referite de pe alte pagini KB (se copiază automat în Outline):\n"+
   [...remoteUploads.values()].map(a=>`• ${a.title} · pageId ${a.sourcePageId}`).join("\n"):"";
 $("linkDetails").hidden=false;
 $("linkDetails").textContent=resolved.map(r=>`${r.label} → ${r.kind==="external"?"EXTERN · păstrat":r.kind==="anchor"?"ANCORĂ":r.migrated?"OUTLINE":r.excluded?"KB [X]":r.kind==="kb"?"KB":"NEVALID"} ${r.url}`).join("\n")||"Nicio referință la pagini.";
 $("warnings").hidden=!findings.length;$("warnings").textContent=findings.map(f=>(criticalFindings.includes(f)?"[BLOCANT] ":"[ATENȚIE] ")+f).join("\n");
 for(const f of criticalFindings)log("BLOCANT: "+f,"AVERTISMENT");
 for(const f of findings.filter(w=>/POSIBILE CREDENȚIALE|FIȘIER SENSIBIL/i.test(w)))
  log("Avertisment informativ, acceptat prin «Am verificat»: "+f,"AVERTISMENT");
 if(findings.length)log(`${findings.length} avertizări (${criticalFindings.length} blocante) la verificarea automată.`,"AVERTISMENT");
 return state.preview;
}
function downloadPath(att){
 const p=att._links?.download;
 if(!p)throw new Error("Atașamentul "+att.title+" nu are URL de descărcare.");
 const b=new URL(state.kb.baseUrl);
 if(/^https?:\/\//.test(p))return p;
 if(p.startsWith("/")){
   // If Confluence runs under a context path, attachment _links may already include it.
   if(b.pathname!=="/"&&!p.startsWith(b.pathname+"/"))return b.origin+b.pathname+p;
   return b.origin+p;
 }
 return state.kb.baseUrl.replace(/\/$/,"")+"/"+p;
}
function base64Blob(b64,mime){const binary=atob(b64);const bytes=new Uint8Array(binary.length);for(let i=0;i<bytes.length;i++)bytes[i]=binary.charCodeAt(i);return new Blob([bytes],{type:mime});}
async function reduceImage(blob,width){
 if(!/^image\/(png|jpeg|webp)$/i.test(blob.type))return blob;
 try{
  const img=await createImageBitmap(blob);
  if(img.width<=width){img.close();return blob;}
  const canvas=document.createElement("canvas");canvas.width=width;canvas.height=Math.max(1,Math.round(img.height*width/img.width));
  canvas.getContext("2d").drawImage(img,0,0,canvas.width,canvas.height);img.close();
  const smaller=await new Promise(resolve=>canvas.toBlob(resolve,blob.type,0.94));
  return smaller||blob;
 }catch(_){log("Imaginea nu a putut fi redimensionată local; folosesc originalul.","AVERTISMENT");return blob;}
}
// Compatible with Outline responses with and without the optional `mode` field.
// Old servers may return {uploadUrl,form,attachment} but no `mode`.
function selectUploadPlan(up,base){
 const mode=(up?.mode==="post"||up?.mode==="put")?up.mode:
   (typeof up?.uploadUrl==="string"&&up.uploadUrl?"post":
    typeof up?.url==="string"&&up.url?"put":"");
 const raw=mode==="post"?(up.uploadUrl||up.url):up?.url;
 if(!mode||typeof raw!=="string"||!raw.trim()){
  const keys=up&&typeof up==="object"?Object.keys(up).join(", "):"none";
  throw new Error(`Outline attachments.create nu a furnizat parametrii de upload (mode=${String(up?.mode||"absent")}; câmpuri=${keys}). Verifică jurnalul și versiunea serverului Outline.`);
 }
 const url=new URL(raw,base.replace(/\/$/,"")+"/").href;
 const parsed=new URL(url);
 if(!["https:","http:"].includes(parsed.protocol))throw new Error("Protocol neacceptat pentru upload Outline.");
 return {mode,url,form:up.form&&typeof up.form==="object"?up.form:{},headers:up.headers&&typeof up.headers==="object"?up.headers:{}};
}
// Checkpoint per source attachment/version and Outline server. Avoids duplicate
// upload on retries after a later file gives HTTP 404 or the popup closes.
async function uploadCacheId(att){
 const ref=String(att.id||att.key||att._links?.download||att.title);
 const version=String(att.version?.number||att._links?.download||"");
 const identity=JSON.stringify([baseUrl($("outlineBase").value.trim()),state.kb.baseUrl,state.kb.pageId,ref,version,att.title,att.extensions?.fileSize||""]);
 const digest=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(identity));
 return "kbm39_asset_"+Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,"0")).join("");
}
async function cachedUpload(att){
 const id=await uploadCacheId(att);
 const found=(await chrome.storage.local.get(id))[id];
 if(found?.url && /^https?:\/\//.test(found.url)){
  const size=Number(found.size??att.extensions?.fileSize);
  if(Number.isSafeInteger(size)&&size>=0)state.assetSizes.set(found.url,size);
  log(`Atașament deja transferat – reutilizez: ${att.title}.`);
  return {id,url:found.url};
 }
 return {id,url:""};
}
function isDownload404(err){return /(?:^|\s)Descărcare HTTP (?:404|410)\b/i.test(String(err?.message||err));}
function isMissing404(err){return /^Atașament KB «[^»]+»[^:]*: Descărcare HTTP (?:404|410)\b/i.test(String(err?.message||err));}

// Only HTTP 404/410 while downloading from Confluence may be skipped.
// HTTP 401/403, CORS problems and Outline upload errors remain fatal.
function missedAttachment(att,role){
 return {filename:String(att.title||"Fișier fără nume"),sourcePageId:String(att.sourcePageId||att.container?.id||state.kb?.pageId||""),role};
}
function regexLiteral(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,"\\$&");}
// Replace the original media reference at its exact position, retaining its
// visible link label while removing the broken URL. Handles Markdown & HTML.
function substituteMissingFile(text,marker,filename){
 const quoted=regexLiteral(marker);let count=0;
 const tag=new RegExp('(!?)\\[([^\\]\\n]*)\\]\\('+quoted+'\\)','g');
 text=text.replace(tag,(_,image,label)=>{
  count++;
  const type=image?"Imagine":"Fișier";
  const adjective=image?"neimportată":"neimportat";
  return `**[${type} ${adjective} (HTTP 404/410): ${escapeMd(label||filename)}]**`;
 });
 const htmlImage=new RegExp('<img\\b[^>]*?\\bsrc=["\\\']'+quoted+'["\\\'][^>]*>','gi');
 text=text.replace(htmlImage,()=>{count++;return `**[Imagine neimportată (HTTP 404/410): ${escapeMd(filename)}]**`;});
 if(text.includes(marker)){
  // No generated internal placeholder may survive a completed import.
  text=text.split(marker).join(`[Fișier neimportat (HTTP 404/410): ${escapeMd(filename)}]`);
  count++;
 }
 return {text,count};
}
function addMissingAttachmentReport(text,skipped){
 if(!skipped.length)return text;
 const unique=[...new Map(skipped.map(x=>[x.sourcePageId+":"+normalFileName(x.filename),x])).values()];
 return text.trimEnd()+"\n\n### Fișiere indisponibile la migrare (HTTP 404/410)\n\n"+
  "Următoarele fișiere au fost omise după confirmarea utilizatorului. Linkurile originale nu mai sunt funcționale în Confluence.\n\n"+
  unique.map(x=>`- ${escapeMd(x.filename)}${x.sourcePageId?` (KB pageId: ${x.sourcePageId})`:""}`).join("\n")+"\n";
}
function showSkippedSummary(skipped,documentUrl=""){
 state.lastSkipped=skipped;
 const box=$("skippedReport");
 box.hidden=!skipped.length;
 if(skipped.length){
  box.textContent=`Migrare continuată cu ${skipped.length} fișier(e) omise (HTTP 404/410):\n`+
   skipped.map(x=>`• ${x.filename}${x.sourcePageId?` · KB pageId ${x.sourcePageId}`:""}`).join("\n")+
   (documentUrl?`\nDocument Outline: ${documentUrl}`:"");
 }
}
async function storeSkippedReport(skipped,url,operation){
 showSkippedSummary(skipped,url);
 if(!state.kb?.pageId)return;
 const key="kbm40_missing_"+state.kb.pageId;
 const report={operation,outlineUrl:url,createdAt:new Date().toISOString(),pageId:state.kb.pageId,files:skipped};
 try{await chrome.storage.local.set({[key]:report});}
 catch(e){log("Lista fișierelor omise nu a putut fi salvată local: "+e.message,"AVERTISMENT");}
 if(skipped.length){
  log(`OPERAȚIE CU ${skipped.length} FIȘIERE OMISE (HTTP 404/410): ${skipped.map(x=>x.filename).join("; ")}`,"AVERTISMENT");
  note(`Operația a continuat, dar ${skipped.length} fișiere au fost omise. Consultă lista afișată și tabul Jurnal.`,true);
 }
}
async function restoreSkippedReport(){
 if(!state.kb?.pageId)return;
 const key="kbm40_missing_"+state.kb.pageId;
 const report=(await chrome.storage.local.get(key))[key];
 if(report?.files?.length){showSkippedSummary(report.files,report.outlineUrl||"");
  log(`Ultimul raport de fișiere omise (${report.createdAt}): ${report.files.map(x=>x.filename).join("; ")}`,"AVERTISMENT");}
 else showSkippedSummary([]);
}

function downloadCandidates(att){
 const first=downloadPath(att);
 const result=[first];
 try{
  const u=new URL(first);if(u.search){u.search="";result.push(u.href);}
  const base=new URL(state.kb.baseUrl);const match=u.pathname.match(/\/download\/attachments\/(\d+)\/[^/]+$/);
  const page=match?.[1]||String(att.container?.id||att.sourcePageId||"");
  if(/^\d+$/.test(page))result.push(base.origin+base.pathname.replace(/\/$/,"")+"/download/attachments/"+page+"/"+encodeURIComponent(att.title));
 }catch(_){}
 return [...new Set(result)];
}
async function getKbFile(att){
 const urls=downloadCandidates(att);let last;
 for(let i=0;i<urls.length;i++){
  const pathname=new URL(urls[i]).pathname; // log no signed query strings
  log(`Descărcare KB [${i+1}/${urls.length}]: ${att.title} · ${pathname}`);
  try{
   const raw=await KBBridge.request(state.sourceTab,state.kb.baseUrl,urls[i],"GET",null,true,20);
   if(!raw.ok)throw new Error("Descărcare HTTP "+raw.status);
   return raw;
  }catch(e){
   last=e;
   if(!isDownload404(e))break;
  }
 }
 throw new Error(`Atașament KB «${att.title}» (${att.sourcePageId||att.container?.id||state.kb.pageId}): ${last?.message||"descărcare eșuată"}. Încercat ${urls.length} variante de link.`);
}
async function uploadFile(att,width){
 const already=await cachedUpload(att);
 if(already.url)return already.url;
 const raw=await getKbFile(att);
 const ext=att.title.split(".").pop().toLowerCase();
 if(["pem","key","p12","pfx","kdbx","env","asc"].includes(ext))
  log("Fișier cu extensie posibil sensibilă confirmat de utilizator: "+att.title,"AVERTISMENT");
 let mime=att.metadata?.mediaType||raw.mime.split(";")[0]||"application/octet-stream";
 let blob=base64Blob(raw.base64,mime);
 if(mime.startsWith("image/"))blob=await reduceImage(blob,width);
 const up=await outlineCall("attachments.create",{name:att.title,contentType:blob.type||mime,size:blob.size});
 const base=baseUrl($("outlineBase").value.trim());
 const plan=selectUploadPlan(up,base);
 log(`Outline attachments.create: ${att.title}; mod ${plan.mode}; destinație ${new URL(plan.url).origin} (fără URL semnat în jurnal).`);
 if(up.maxUploadSize && blob.size>Number(up.maxUploadSize)){
  throw new Error(`Fișierul ${att.title} (${bytesize(blob.size)}) depășește limita serverului Outline (${bytesize(Number(up.maxUploadSize))}).`);
 }
 const origin=originFor(plan.url);
 if(!(await chrome.permissions.contains({origins:[origin]}))){
  state.permissionOrigin=origin;$("permissionStorage").hidden=false;
  throw new Error("Domeniul storage "+origin+" necesită permisiune Chrome. Apasă «Autorizează domeniul pentru fișiere», apoi reîncearcă.");
 }
 const urlInfo=new URL(plan.url),outlineInfo=new URL(base);
 // A local Outline installation posts multipart files to /api/files.create.
 // API bearer authentication is required on some Outline versions. NEVER
 // forward the personal API key to S3, MinIO, or any other host.
 const isLocalOutlineUpload=(urlInfo.origin===outlineInfo.origin&&/\/api\/files\.create\/?$/.test(urlInfo.pathname));
 let r;
 try{
  if(plan.mode==="post"){
   const fd=new FormData();
   for(const [k,v]of Object.entries(plan.form))fd.append(k,String(v));
   fd.append("file",blob,att.title);
   r=await fetch(plan.url,{method:"POST",body:fd,headers:isLocalOutlineUpload?{Authorization:"Bearer "+$("outlineToken").value.trim()}:undefined,redirect:isLocalOutlineUpload?"error":"follow"});
  }else{
   // Presigned S3 PUT must receive only the headers declared by Outline.
   r=await fetch(plan.url,{method:"PUT",body:blob,headers:plan.headers});
  }
 }catch(e){
  throw new Error(`Nu s-a putut transfera ${att.title} către ${urlInfo.origin} (${plan.mode.toUpperCase()}). Verifică accesul la storage, permisiunile Chrome și CORS. ${e?.message||e}`);
 }
 if(!r.ok){
  let snippet="";
  try{snippet=(await r.text()).replace(/\s+/g," ").slice(0,180);}catch(_){}
  throw new Error(`Upload ${att.title}: HTTP ${r.status}${snippet?" – "+snippet:""}`);
 }
 const linked=KBFileLinks.canonicalUploadedUrl(up,base);
 const final=linked.url;
 if(!linked.id)log(`Outline nu a returnat ID pentru ${att.title}; folosesc URL-ul furnizat de server, fără a-l reinterpreta.`,"AVERTISMENT");
 state.assetSizes.set(final,blob.size);
 // Keep local progress only for stable links, never for signed expiring URLs.
 const cachedLink=new URL(final);
 const queryKeys=[...cachedLink.searchParams.keys()];
 const stable=queryKeys.every(key=>["id","attachmentId"].includes(key));
 if(stable)await chrome.storage.local.set({[already.id]:{url:final,filename:att.title,size:blob.size,attachmentId:linked.id,storedAt:new Date().toISOString()}});
 else log(`Fișierul ${att.title} are URL temporar/sensibil: nu persist linkul în profilul Chrome.`,"AVERTISMENT");
 log("Fișier încărcat în Outline: "+att.title+" ("+bytesize(blob.size)+") – progres salvat pentru reluare.");
 return final;
}
function withNativeOutlineAttachments(text){
 const base=baseUrl($("outlineBase").value.trim());
 const result=KBFileLinks.format(text,{base,sizeByUrl:state.assetSizes,
  sizesByFilename:KBFileLinks.sourceSizes(state.attachments)});
 if(result.changed)log(`Linkuri fișiere convertite în formatul nativ Outline (nume + dimensiune): ${result.changed}.`);
 return result.text;
}
function replaceMediaUrls(text,uploaded,preview){
 let out=text;
 for(const im of preview.conv.images){
  const f=im.filename||(()=>{try{return decodeURIComponent(new URL(im.src,state.kb.baseUrl).pathname.split("/").pop());}catch(_){return "";}})();
  if(uploaded.has(f))out=out.replaceAll(`[UPLOAD:${f}]`,uploaded.get(f));
 }
 for(const f of preview.conv.fileLinks){if(uploaded.has(f.filename))out=out.replaceAll(`[UPLOAD:${f.filename}]`,uploaded.get(f.filename));}
 for(const [name,url]of uploaded)out=out.replaceAll(`[UPLOAD:${name}]`,url);
 return out;
}
async function finishKBMigration(url,id){
 const p=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 const currentRecord=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId))?.value||null;
 if(["M","X","CONFLICT"].includes(migrationState(p,currentRecord))){
  throw new Error("Pagina KB a fost deja marcată [M]/[X] de un administrator. Nu mai efectuăm încă o modificare.");
 }
 // Strict conflict check avoids silently editing a page changed after preview.
 if(state.preview&&p.version?.number!==state.preview.sourceVersion){
  if(p.title!==state.preview.sourceTitle || p.body?.storage?.value!==state.preview.sourceStorage)
   throw new Error("Pagina KB și-a schimbat conținutul după citire. Documentul Outline este salvat; reîncarcă KB și finalizează separat.");
  log("Versiunea Confluence a avansat, dar textul și titlul sunt neschimbate; continui marcarea [M].","AVERTISMENT");
 }
 // Verify the code macros survived the Outline write/read round trip.
 // A page with lost commands must not be marked as fully migrated.
 const converted=KBConvert.convert(p.body?.storage?.value||"",{
   sourceBase:state.kb.baseUrl,pageId:state.kb.pageId,spaceKey:p.space?.key});
 if(converted.codeMacroCount!==converted.codeMacroConverted)
   throw new Error("Un macro de cod Confluence nu a fost citit corect; [M] nu se aplică.");
 if(converted.codeBodies.length){
   const outlineDoc=await outlineInfo(url);
   const docText=String(outlineDoc.text||"");
   const missing=converted.codeBodies.filter(code=>code.split(/\r?\n/).map(x=>x.trim()).filter(x=>x.length>=4).some(x=>!docText.includes(x)));
   if(missing.length)throw new Error(`${missing.length} bloc(uri) de cod Confluence nu sunt prezente integral în Outline. Folosește «Repară documentul existent»; [M] nu se aplică.`);
   log(`Verificare cod Outline: ${converted.codeBodies.length} macro-uri prezente în document.`);
 }
 const who=state.user.displayName||state.user.username,iso=new Date().toISOString().slice(0,10);
 const title="[M] "+stripTitle(p.title);
 const body=KBConvert.markBlock("M",who,iso,url)+KBConvert.stripExistingBlock(p.body?.storage?.value||"");
 log(`Marcarea [M] în KB: trimit actualizare Confluence PUT, pageId=${state.kb.pageId}, versiune=${p.version.number+1}.`);
 await KBBridge.updatePage(state.sourceTab,state.kb.baseUrl,state.kb.pageId,title,body,p.version.number);
 const checked=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 if(checked.title!==title)throw new Error("PUT Confluence a răspuns, dar titlul [M] nu a fost confirmat la recitire. Verifică istoricul paginii.");
 log("Marcarea [M] confirmată prin recitirea titlului Confluence.");
 const record={...state.mapped,status:"M",kbPageId:state.kb.pageId,outlineId:id,outlineUrl:url,
    migratedBy:state.user.username,validatedAt:new Date().toISOString()};
 try{await KBBridge.setProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId,record);}
 catch(e){log("Titlul KB este [M], dar registrul Content Property trebuie verificat: "+e.message,"AVERTISMENT");}
 state.mapped=record;
 state.page=checked;
 log("KB marcat [M], cu responsabil, dată și link Outline.");
}
async function migration(){
 if(!state.page)throw new Error("Pagina KB nu a fost încă detectată.");
 if(notifyLocked(migrationState()))return;
 if(!$("reviewed").checked)throw new Error("Bifează «Am verificat informațiile» înainte de migrare.");
 if(!$("destination").value.trim())throw new Error("Introdu linkul destinație Outline.");
 if(!(await freshStatusCheck()).ok)return;
 // Fără pas separat de preview: conversia se pregătește automat înainte de transfer.
 await buildPreview();
 if(state.preview.criticalFindings.length)
  throw new Error("Migrare oprită din cauza următoarelor verificări:\n• "+state.preview.criticalFindings.join("\n• ")+"\nConsultă și tabul Jurnal. Linkurile externe valide sunt păstrate și nu blochează migrarea.");
 // Fail before any Outline write if the KB page changed since preview.
 const kbFresh=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 if(kbFresh.version?.number!==state.preview.sourceVersion)throw new Error("Pagina KB s-a modificat între timp. Reîncarcă pagina și încearcă din nou.");
 const dest=await outlineInfo($("destination").value.trim());
 if(!dest?.id||!dest?.collectionId)throw new Error("Nu am obținut id/collectionId pentru documentul Outline.");
 let previous=null;
 if(!$("isParent").checked){
  previous=dest.text||"";
  if(!confirm(`Urmează să ${$("mode").value==="append"?"adaugi text în":"înlocuiești conținutul"} documentul Outline «${dest.title}». Confirmi?`))return;
 } else if(!confirm(`Creez subdocumentul «${stripTitle(state.page.title)}» sub «${dest.title}»?`))return;
 const att=new Map(),skippedFiles=[];
 // Upload required files first. When the user opts in, source HTTP 404/410
 // can be omitted even for linked files, with a visible annotation and report.
 const chosen=state.preview.selected.filter(a=>$("includeOtherAttachments").checked||state.preview.needed.has(String(a.id)));
 chosen.sort((a,b)=>Number(state.preview.needed.has(String(b.id)))-Number(state.preview.needed.has(String(a.id))));
 for(const a of chosen){
  try{const url=await uploadFile(a,state.preview.width);att.set(a.title,url);}
  catch(e){
   if($("skipUnavailableExtras").checked && isMissing404(e)){
    skippedFiles.push(missedAttachment(a,state.preview.needed.has(String(a.id))?"în text":"suplimentar"));
    log(`HTTP 404/410 – OMIT după confirmare: ${a.title} (KB pageId ${a.container?.id||state.kb.pageId})`,"AVERTISMENT");
    continue;
   }
   throw e;
  }
 }
 for(const a of state.preview.needed.values())if(!att.has(a.title)&&!skippedFiles.some(f=>f.sourcePageId===String(a.container?.id||state.kb.pageId)&&normalFileName(f.filename)===normalFileName(a.title)))throw new Error("Fișier lipsă după transfer: "+a.title);
 // Linked files from OTHER Confluence pages are copied by default. Only
 // explicit opt-in permits omitting a 404/410 download from KB.
 const remoteUrls=new Map();
 for(const item of state.preview.remoteUploads.values()){
  log(`Transfer din altă pagină KB: pageId=${item.sourcePageId}, fișier=${item.title}.`);
  try{remoteUrls.set(item.key,await uploadFile(item,state.preview.width));}
  catch(e){
   if($("skipUnavailableExtras").checked && isMissing404(e)){
    skippedFiles.push(missedAttachment(item,"link inter-pagină"));
    log(`HTTP 404/410 – OMIT după confirmare: ${item.title} (KB pageId ${item.sourcePageId})`,"AVERTISMENT");
   }else throw e;
  }
 }
 let markdown=replaceMediaUrls(state.preview.text,att,state.preview);
 for(const item of state.preview.remoteUploads.values()){
  const url=remoteUrls.get(item.key);
  if(url)markdown=markdown.split(item.marker).join(url);
  else if(skippedFiles.some(f=>f.sourcePageId===String(item.sourcePageId)&&normalFileName(f.filename)===normalFileName(item.title))){
   markdown=substituteMissingFile(markdown,item.marker,item.title).text;
  }else throw new Error("Atașament inter-pagină neîncărcat: "+item.title);
 }
 for(const missing of skippedFiles.filter(x=>x.role!=="link inter-pagină")){
  markdown=substituteMissingFile(markdown,`[UPLOAD:${missing.filename}]`,missing.filename).text;
 }
 markdown=addMissingAttachmentReport(markdown,skippedFiles);
 markdown=withNativeOutlineAttachments(markdown);
 if(/KBMIGR_REMOTE_FILE_\d+_END/.test(markdown))throw new Error("Au rămas atașamente inter-pagină neînlocuite.");
 if(/\[UPLOAD:/.test(markdown))throw new Error("Au rămas referințe de încărcare neînlocuite în document.");
 // Re-check KB too: no writes to Outline if another administrator already marked [M] or [X].
 if(!(await freshStatusCheck()).ok)return;
 // Re-check destination: avoid accidental overwrite of concurrent edits.
 let result;
 if($("isParent").checked){
  result=await outlineCall("documents.create",{title:stripTitle(state.page.title),text:markdown,collectionId:dest.collectionId,parentDocumentId:dest.id,publish:true});
 }else{
  const fresh=await outlineInfo($("destination").value.trim());
  if((fresh.text||"")!==previous)throw new Error("Documentul destinație Outline a fost editat între timp. Operația este oprită înainte de suprascriere.");
  const text=$("mode").value==="append"?previous.trim()+"\n\n"+markdown:markdown;
  result=await outlineCall("documents.update",{id:dest.id,text});
 }
 const finalUrl=finalOutlineLink(result?.id?result:dest),docId=result?.id||dest.id;
 log("Outline salvat: "+finalUrl);
 // Registry is written first: safe recovery if title/status update fails.
 const mapping={status:"P",kbPageId:state.kb.pageId,outlineId:docId,outlineUrl:finalUrl,
   migratedBy:state.user.username,migratedAt:new Date().toISOString()};
 try{await KBBridge.setProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId,mapping);state.mapped=mapping;log("Maparea KB → Outline a fost salvată în Content Properties.");}
 catch(e){log("Outline salvat, dar registrul KB nu s-a actualizat: "+e.message,"AVERTISMENT");}
 await storeSkippedReport(skippedFiles,finalUrl,"migrare");
 if($("markKB").checked){
  try{await finishKBMigration(finalUrl,docId);}
  catch(e){state.mapped=mapping;$("finalizeKB").hidden=false;throw new Error("OUTLINE SALVAT: "+finalUrl+". Marcarea KB a eșuat: "+e.message);}
 }else{
  $("finalizeKB").hidden=false;
  log("Documentul Outline a fost transferat; marcarea [M] așteaptă validarea vizuală.","AVERTISMENT");
 }
 note($("markKB").checked
  ?`Migrare completă${skippedFiles.length?` (cu ${skippedFiles.length} fișiere 404/410 omise)`:""}; KB marcat [M]. ${finalUrl}`
  :`Document salvat${skippedFiles.length?` cu ${skippedFiles.length} fișiere omise`:""}. Marcarea [M] este în așteptare.`);
 statusUI();
 $("destination").value=finalUrl;$("isParent").checked=false;$("existingActions").hidden=false;
 log(skippedFiles.length?`MIGRARE COMPLETĂ CU ${skippedFiles.length} FIȘIERE OMISE (404/410).`:"MIGRARE COMPLETĂ.");
}
// Explicit UPDATE of an already [M] document. No new Outline page, no change
// to the [M] Confluence title, no automatic re-upload of existing media.
async function updateExisting(){
 if(!state.page)throw new Error("Pagina KB nu este încărcată.");
 const status=migrationState();
 if(["X","CONFLICT"].includes(status))return notifyLocked(status);
 if(!["M","P"].includes(status))throw new Error("Pentru o pagină nemigrată folosește Migrează; actualizarea directă este pentru [M] sau transfer în așteptare.");
 if($("isParent").checked)throw new Error("Debifează «document-părinte» – actualizarea se face numai în pagina Outline existentă.");
 if(!$("reviewed").checked)throw new Error("Bifează «Am verificat informațiile».");
 const link=$("destination").value.trim();if(!link)throw new Error("Introdu linkul documentului existent în Outline.");
 const doc=await outlineInfo(link);if(!doc?.id)throw new Error("Documentul din Outline nu există sau nu poate fi citit.");
 if(state.mapped?.outlineId && String(doc.id)!==String(state.mapped.outlineId))
  throw new Error("Linkul introdus indică alt document decât cel asociat acestui pageId KB. Nu actualizez altă pagină.");
 if(!state.mapped?.outlineId){
  const canon=KBConvert.canonicalKb(state.kb.baseUrl,state.kb.pageId);
  if(!(doc.text||"").includes(canon) && !(doc.text||"").includes(`**Confluence pageId:** ${state.kb.pageId}`))
   throw new Error("Nu există registru de migrare și documentul Outline nu conține referința pageId KB. Nu pot confirma că este destinația corectă.");
 }
 const previous=String(doc.text||"");
 await buildPreview();
 if(status==="M" && state.mapped?.migratedAt){
  const oldProvenance=KBConvert.provenance(state.kb.baseUrl,state.kb.pageId,
   state.mapped?.migratedBy||state.user.username,String(state.mapped.migratedAt).slice(0,10));
  const newProvenance=KBConvert.provenance(state.kb.baseUrl,state.kb.pageId,
   state.user.displayName||state.user.username,new Date().toISOString().slice(0,10));
  if(state.preview.text.endsWith(newProvenance))state.preview.text=state.preview.text.slice(0,-newProvenance.length)+oldProvenance;
 }
 if(state.preview.criticalFindings.length)throw new Error("Conversie incompletă: "+state.preview.criticalFindings.join("; "));
 if(!confirm(`Actualizez documentul Outline EXISTENT «${doc.title}» (${ $("mode").value==="append"?"adăugare integrală (poate dubla conținutul)":"înlocuire" })?\nNu voi crea subpagină și nu voi modifica prefixul KB ${status==="M"?"[M]":"(în așteptare)"}.`))return;
 // User choices must belong to this exact document revision.
 if(state.repairDestId!==String(doc.id)||state.repairPrevious!==previous){
  state.repairChoices.clear();state.repairDestId=String(doc.id);state.repairPrevious=previous;hideRepairChoices();
 }
 const reused=KBMediaRepair.build(state.preview,previous,{kbBase:state.kb.baseUrl,
  outlineBase:baseUrl($("outlineBase").value.trim()),choices:state.repairChoices,allowMissing:true});
 if(reused.ambiguities.length){
  showRepairChoices(reused.ambiguities);
  note("Există mai multe URL-uri posibile pentru unele atașamente. Alege destinațiile și apasă «Continuă actualizarea».",true);
  log(`Actualizare oprită înainte de scriere: ${reused.ambiguities.length} asocieri ambigue.`,"AVERTISMENT");
  $("continueRepair").textContent="Continuă actualizarea";
  $("continueRepair").dataset.action="update";
  return;
 }
 hideRepairChoices();
 const byName=new Map(state.attachments.map(a=>[normalFileName(a.title),a]));
 let text=reused.text;
 const newAssets=new Map(),skipped=[];
 for(const entry of reused.missing||[]){
  if(newAssets.has(entry.marker))continue;
  let attachment=null;
  if(String(entry.marker).startsWith("[UPLOAD:"))attachment=byName.get(normalFileName(entry.filename));
  else attachment=[...state.preview.remoteUploads.values()].find(a=>a.marker===entry.marker);
  if(!attachment)throw new Error(`Nu găsesc fișierul nou în sursă: ${entry.filename||entry.label}. Actualizarea a fost oprită.`);
  try{newAssets.set(entry.marker,await uploadFile(attachment,state.preview.width));}
  catch(e){
   if($("skipUnavailableExtras").checked && isMissing404(e)){
    skipped.push({marker:entry.marker,...missedAttachment(attachment,String(entry.marker).startsWith("[UPLOAD:")?"atașament local":"link inter-pagină")});
    log(`HTTP 404/410 – OMIT la actualizare: ${attachment.title}`,"AVERTISMENT");
   }else throw e;
  }
 }
 for(const [marker,url]of newAssets)text=text.split(marker).join(url);
 for(const item of skipped)text=substituteMissingFile(text,item.marker,item.filename).text;
 text=addMissingAttachmentReport(text,skipped);
 text=withNativeOutlineAttachments(text);
 if(/\[UPLOAD:|KBMIGR_REMOTE_FILE_\d+_END/.test(text))throw new Error("Au rămas fișiere nerezolvate; nu actualizez documentul.");
 const checkKb=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 const cur=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId))?.value||null;
 if(migrationState(checkKb,cur)!==status || checkKb.version?.number!==state.page.version?.number)
  throw new Error("Starea/versiunea KB s-a schimbat în timpul actualizării. Reîncarcă pagina.");
 const fresh=await outlineInfo(link);
 if(String(fresh.text||"")!==previous)throw new Error("Documentul Outline a fost editat între timp; actualizarea a fost oprită.");
 // Append retains the original provenance footer; do not add a second copy.
 let next=text;
 if($("mode").value==="append"){
  const match=text.match(/\n\n---\n\n### Sursă KB\n[\s\S]*$/);
  next=previous.trim()+"\n\n"+(match?text.slice(0,match.index):text).trim();
 }
 if(!next.trim())throw new Error("Conținutul rezultat este gol.");
 await outlineCall("documents.update",{id:doc.id,text:next});
 const final=finalOutlineLink(doc);
 const record={...cur,...state.mapped,status:status==="M"?"M":"P",kbPageId:state.kb.pageId,
  outlineId:doc.id,outlineUrl:final,updatedBy:state.user.username,lastUpdatedAt:new Date().toISOString()};
 try{await KBBridge.setProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId,record);state.mapped=record;}
 catch(e){log("Outline actualizat, dar nu am putut actualiza registrul din KB: "+e.message,"AVERTISMENT");}
 await storeSkippedReport(skipped,final,"actualizare");
 log(`UPDATE Outline complet: ${final}; ${reused.reused} fișiere reutilizate, ${newAssets.size} noi, ${skipped.length} omise (HTTP 404/410).`);
 note(`Documentul Outline existent a fost actualizat. KB rămâne ${status==="M"?"[M]":"în așteptarea finalizării [M]"}. Fișiere reutilizate: ${reused.reused}; noi: ${newAssets.size}; omise HTTP 404/410: ${skipped.length}.`);
 statusUI();
}
// Recovery for a document already written to Outline (P status), including
// older incomplete migrations where Content Property could not be saved.
// Reuses the document's existing media URLs and does not upload files again.
// The recovery engine distinguishes Outline file URLs from ordinary KB/Outline
// navigation links and requests manual disambiguation when labels collide.
function rebuildWithExistingMedia(preview,previous){
 return KBMediaRepair.build(preview,previous,{kbBase:state.kb.baseUrl,
  outlineBase:baseUrl($("outlineBase").value.trim()),choices:state.repairChoices});
}
function hideRepairChoices(){
 $("repairMappingPanel").hidden=true;$("repairMappingList").replaceChildren();$("continueRepair").dataset.action="repair";$("continueRepair").textContent="Continuă repararea după alegere";
}
function showRepairChoices(items){
 const root=$("repairMappingList");root.replaceChildren();
 for(const item of items){
  const wrap=document.createElement("div");wrap.className="repair-choice";
  const text=document.createElement("label");
  text.textContent=(item.image?"Imagine: ":"Fișier: ")+item.label+(item.filename?" (sursă: "+item.filename+")":"");
  const select=document.createElement("select");
  const empty=document.createElement("option");empty.value="";empty.textContent="Alege linkul deja încărcat în Outline";select.append(empty);
  for(const option of item.options){
   const opt=document.createElement("option");opt.value=option.url;opt.textContent=option.display;select.append(opt);
  }
  select.value=state.repairChoices.get(item.key)||"";
  select.addEventListener("change",()=>{
   if(select.value)state.repairChoices.set(item.key,select.value);else state.repairChoices.delete(item.key);
  });
  text.append(select);wrap.append(text);root.append(wrap);
 }
 $("repairMappingPanel").hidden=false;
}
async function repairContent(){
 if(!state.page)throw new Error("Nu este deschisă nicio pagină KB.");
 if(!$("reviewed").checked)throw new Error("Bifează «Am verificat informațiile» înainte de reparare.");
 const status=migrationState();
 if(["X","CONFLICT"].includes(status))return notifyLocked(status);
 const link=state.mapped?.outlineUrl||$("destination").value.trim();
 if(!link)throw new Error("Introdu linkul documentului Outline DEJA creat (nu al părintelui).");
 const dest=await outlineInfo(link);
 if(!dest?.id)throw new Error("Documentul Outline existent nu a fost identificat.");
 if(status==="M" && String(dest.id)!==String(state.mapped?.outlineId||""))
   throw new Error("Documentul ales nu corespunde celui înregistrat pentru pagina KB deja [M].");
 if(!confirm(status==="M"
   ?`Corectez TEXTUL documentului DEJA migrat «${dest.title}», păstrând URL-urile fișierelor și fără să modific marcajul [M] în KB?`
   :`Regenerez doar TEXTUL documentului Outline «${dest.title}», păstrând URL-urile fișierelor deja încărcate, apoi finalizez [M] în KB?`))return;
 await buildPreview();
 if(state.preview.criticalFindings.length)throw new Error("Conversie incompletă: "+state.preview.criticalFindings.join("; "));
 if(!state.preview.conv.codeMacroConverted && /<ac:structured-macro[^>]*ac:name=["'](?:code|noformat)["']/i.test(state.preview.sourceStorage))
   throw new Error("Au fost identificate macro-uri de cod în KB, dar nu au fost convertite. Oprit înainte de modificarea Outline.");
 // Choices are valid only for the exact Outline document revision inspected.
 if(state.repairDestId!==String(dest.id)||state.repairPrevious!==(dest.text||"")){
  state.repairChoices.clear();state.repairDestId=String(dest.id);state.repairPrevious=dest.text||"";
  hideRepairChoices();
 }
 const patched=rebuildWithExistingMedia(state.preview,dest.text||"");
 if(patched.ambiguities.length){
  showRepairChoices(patched.ambiguities);
  log(`Reparare în așteptare: ${patched.ambiguities.length} linkuri cu etichete identice necesită selectarea fișierului corect. Nicio modificare efectuată.`,"AVERTISMENT");
  note("Există linkuri cu același nume și destinații diferite. Alege fișierul corect în secțiunea «Asociere linkuri», apoi apasă «Continuă repararea». Nu am modificat Outline sau KB.",true);
  return;
 }
 hideRepairChoices();
 if(!patched.text.trim())throw new Error("Conținutul rezultat este gol.");
 const fresh=await outlineCall("documents.info",{id:dest.id});
 if(fresh.text!==dest.text)throw new Error("Documentul Outline a fost modificat între timp. Reia operația.");
 await outlineCall("documents.update",{id:dest.id,text:withNativeOutlineAttachments(patched.text)});
 const url=finalOutlineLink(dest);
 log(`Conținut Outline reparat: ${url}; ${patched.reused} referințe către fișiere existente reutilizate; fișiere încărcate: 0.`);
 if(status==="M"){
   $("destination").value=url;
   note("Linkurile și conținutul documentului Outline au fost corectate. Pagina KB rămâne [M]; atașamente reîncărcate: 0.");
   statusUI();
   return;
 }
 const mapping={...state.mapped,status:"P",kbPageId:state.kb.pageId,outlineId:dest.id,outlineUrl:url,
    migratedBy:state.user.username,migratedAt:state.mapped?.migratedAt||new Date().toISOString()};
 state.mapped=mapping;
 try{await KBBridge.setProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId,mapping);}
 catch(e){log("Registrul intermediar nu s-a actualizat: "+e.message,"AVERTISMENT");}
 if($("markKB").checked){
   try{await finishKBMigration(url,dest.id);}
   catch(e){$("finalizeKB").hidden=false;throw new Error("Outline reparat, dar [M] nu a fost confirmat în KB: "+e.message);}
   note("Codul a fost reparat în Outline, fișierele existente au fost reutilizate și KB este [M].");
 }else{
   $("finalizeKB").hidden=false;
   note("Codul a fost reparat în Outline. Apasă «Finalizează marcarea [M]» pentru KB.");
 }
 $("destination").value=url;
 statusUI();
}

async function exclude(){
 if(!state.page)throw new Error("Pagina KB nu a fost încă detectată.");
 if(notifyLocked(migrationState()))return;
 const why=$("excludeReason").value.trim();if(why.length<5)throw new Error("Introdu motivul excluderii (minimum 5 caractere).");
 if(!(await freshStatusCheck()).ok)return;
 if(!confirm(`Marchezi pagina «${state.page.title}» cu [X] și motivul: ${why}?`))return;
 const p=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 const iso=new Date().toISOString().slice(0,10),user=state.user.displayName||state.user.username;
 const newBody=KBConvert.markBlock("X",user,iso,why)+KBConvert.stripExistingBlock(p.body?.storage?.value||"");
 await KBBridge.updatePage(state.sourceTab,state.kb.baseUrl,state.kb.pageId,"[X] "+stripTitle(p.title),newBody,p.version.number);
 const mapping={status:"X",kbPageId:state.kb.pageId,excludedBy:state.user.username,excludedAt:new Date().toISOString(),reason:why};
 try{await KBBridge.setProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId,mapping);}catch(e){log("[X] salvat, dar Content Property a eșuat: "+e.message,"AVERTISMENT");}
 state.mapped=mapping;state.page=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);statusUI();
 note("Pagina KB a fost evaluată și marcată [X]. O nouă excludere sau migrare este blocată.");log("Exclus [X] motiv: "+why);
}
async function recoverCanonicalFileUrls(text){
 // Older migrations used signed /api/files.get URLs. Decode their key only
 // to locate a candidate attachment UUID; require a fresh redirect from the
 // authenticated Outline server with the exact same file key before reuse.
 const base=baseUrl($("outlineBase").value.trim()),token=$("outlineToken").value.trim();
 const matches=[...new Set(String(text||"").match(/https?:\/\/[^\s)<>"']+\/api\/files\.get\?[^\s)<>"']+/g)||[])];
 const replacements=new Map();
 for(const old of matches){
   const candidate=KBFileLinks.signedUrlCandidate(old,base);
   if(!candidate)continue;
   const canonical=new URL("api/attachments.redirect?id="+encodeURIComponent(candidate.id),base+"/").href;
   try{
     const res=await fetch(canonical,{method:"GET",redirect:"manual",cache:"no-store",
       headers:{Authorization:"Bearer "+token}});
     if(res.status<300||res.status>=400)continue;
     const location=res.headers.get("location");if(!location)continue;
     const resolved=KBFileLinks.signedUrlCandidate(new URL(location,base+"/").href,base);
     if(resolved?.key===candidate.key)replacements.set(old,canonical);
   }catch(_){/* Do not alter a URL when safe verification is unavailable. */}
 }
 const result=KBFileLinks.rewriteLegacyUrls(text,base,replacements);
 if(result.count)log(`Linkuri vechi files.get înlocuite cu ID-uri stabile Outline, după verificare: ${result.count}.`);
 if(matches.length&&!result.count)log("URL-uri vechi files.get detectate, dar nu au putut fi confirmate prin API; le păstrez nemodificate.","AVERTISMENT");
 return result.text;
}
async function fixAttachmentNames(){
 if(!state.page||!state.kb)throw new Error("Deschide pagina KB corespunzătoare documentului Outline.");
 const st=migrationState();
 if(st==="X"||st==="CONFLICT")throw new Error("Corectarea atașamentelor este blocată pentru paginile excluse sau în conflict.");
 const link=$("destination").value.trim()||state.mapped?.outlineUrl;
 if(!link)throw new Error("Introdu adresa documentului Outline existent.");
 if($("isParent").checked)throw new Error("Debifează «Părinte»: aceasta este o operație asupra documentului existent.");
 const doc=await outlineInfo(link);
 if(!doc?.id)throw new Error("Documentul Outline nu poate fi identificat.");
 if(state.mapped?.outlineId && String(doc.id)!==String(state.mapped.outlineId))
  throw new Error("ID-ul Outline nu corespunde paginii KB curente. Refuz actualizarea altui document.");
 const old=String(doc.text||"");
 const resolved=await recoverCanonicalFileUrls(old);
 const corrected=withNativeOutlineAttachments(resolved);
 if(corrected===old){note("Nu sunt linkuri către atașamente care necesită formatul nativ Outline sau lipsește dimensiunea lor.");return;}
 if(!confirm(`Actualizez NUMAI prezentarea linkurilor la fișiere din documentul Outline «${doc.title}»? Nu reîncarc atașamente, nu schimb [M] și nu modific linkurile către alte pagini.`))return;
 const fresh=await outlineCall("documents.info",{id:doc.id});
 if(String(fresh.text||"")!==old)throw new Error("Documentul Outline a fost modificat între timp; operația este anulată.");
 await outlineCall("documents.update",{id:doc.id,text:corrected});
 log(`Corecție format nume atașamente realizată pentru ${doc.title}.`);
 note("Linkurile fișierelor cu dimensiune cunoscută au fost convertite în formatul nativ Outline, fără upload și fără schimbarea paginii KB.");
}
async function fixLinks(){
 if(!state.kb)throw new Error("Citește o pagină KB, pentru a identifica serverul Confluence.");
 const link=$("destination").value.trim();if(!link)throw new Error("Introdu linkul documentului Outline de reparat.");
 const doc=await outlineInfo(link),text=doc.text||"";
 // Only canonical KB links are automatically redirected. Arbitrary external URLs are untouched.
 const pattern=/https?:\/\/[^\s)\]<>"']+\/pages\/viewpage\.action\?pageId=\d+(?:&amp;[a-zA-Z0-9=&]+)?/g;
 const matches=[...new Set(text.match(pattern)||[])];
 let changed=text;const actions=[];
 for(const m of matches){
  const pageId=hrefPageId(m.replace(/&amp;/g,"&"));if(!pageId)continue;
  try{const meta=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,pageId))?.value;
    if(meta?.status==="M"&&meta?.outlineUrl){changed=changed.split(m).join(meta.outlineUrl);actions.push(pageId+" → "+meta.outlineUrl);}
  }catch(e){log("Nu pot verifica pagina KB "+pageId+": "+e.message,"AVERTISMENT");}
 }
 if(!actions.length){note("Nu am găsit legături KB care pot fi înlocuite automat în acest document.");return;}
 if(!confirm(`Înlocuiesc ${actions.length} legături în «${doc.title}»?\n\n${actions.join("\n").slice(0,1500)}`))return;
 const fresh=await outlineInfo(link);if((fresh.text||"")!==text)throw new Error("Documentul Outline a fost modificat între timp; reia verificarea.");
 await outlineCall("documents.update",{id:doc.id,text:changed});
 log("Legături reparate: "+actions.length+" în "+doc.title);note("Legăturile către paginile migrate au fost actualizate în Outline.");
}
// Cross-collection audit: plan first, apply only after a separate user confirmation.
async function linksChanged(text,propertyCache){
 const pattern=/https?:\/\/[^\s)\]<>"']+\/pages\/viewpage\.action\?pageId=\d+(?:&amp;[a-zA-Z0-9=&]+)?/g;
 const candidates=[...new Set(text.match(pattern)||[])];
 let next=text;let fixed=0,remaining=0;
 const kbOrigin=new URL(state.kb.baseUrl).origin;
 for(const url of candidates){
  if(new URL(url.replace(/&amp;/g,"&")).origin!==kbOrigin)continue;
  const id=hrefPageId(url.replace(/&amp;/g,"&"));if(!id)continue;
  let record=propertyCache.get(id);
  if(record===undefined){
   try{record=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,id))?.value||null;}
   catch(_){record=null;}
   propertyCache.set(id,record);
  }
  if(record?.status==="M"&&record.outlineUrl){next=next.split(url).join(record.outlineUrl);fixed++;}
  else remaining++;
 }
 return {next,fixed,remaining};
}
async function auditCollection(){
 if(!state.kb)throw new Error("Încarcă mai întâi pagina KB pentru identificarea serverului.");
 const currentLink=$("destination").value.trim();if(!currentLink)throw new Error("Introdu linkul unui document din colecția Outline de auditat.");
 const baseDoc=await outlineInfo(currentLink);if(!baseDoc.collectionId)throw new Error("Colecția documentului nu a putut fi identificată.");
 const plan=[], propertyCache=new Map();let scanned=0,remaining=0,offset=0,hasMore=false;
 $("auditReport").hidden=false;$("auditReport").textContent="Se verifică documentele Outline accesibile utilizatorului...";
 for(let batch=0;batch<5;batch++){
  const arr=await outlineCall("documents.list",{collectionId:baseDoc.collectionId,limit:100,offset});
  const docs=Array.isArray(arr)?arr:(arr?.documents||[]);
  for(const entry of docs){
   scanned++;if(!entry?.id)continue;
   try{const doc=await outlineCall("documents.info",{id:entry.id});
    const text=doc.text||"";if(!text.includes("viewpage.action?pageId="))continue;
    const res=await linksChanged(text,propertyCache);remaining+=res.remaining;
    if(res.fixed)plan.push({id:doc.id,title:doc.title,before:text,after:res.next,fixes:res.fixed});
   }catch(e){log("Audit: nu am acces/nu pot citi "+(entry.title||entry.id)+": "+e.message,"AVERTISMENT");}
  }
  offset+=docs.length;
  if(docs.length<100){hasMore=false;break;}
  hasMore=true;
 }
 state.auditPlan=plan;
 const count=plan.reduce((n,p)=>n+p.fixes,0);
 $("auditReport").textContent=`Colecția: ${baseDoc.collectionId}\nDocumente analizate: ${scanned}\nDocumente cu corecții: ${plan.length}\nLinkuri care pot fi redirecționate către Outline: ${count}\nLinkuri rămase către KB: ${remaining}\n`+
    (hasMore?"Audit limitat la primele 500 documente; colecția poate conține mai multe.\n":"")+
    "\n"+plan.map(p=>`${p.fixes} × ${p.title}`).join("\n");
 $("applyAudit").hidden=!plan.length;
 log(`Audit colecție: ${scanned} documente, ${count} corecții posibile, ${remaining} legături încă în KB.`);
 note("Auditul este gata. Niciun document Outline nu a fost modificat.");
}
async function applyAudit(){
 const plan=state.auditPlan;
 if(!plan.length)throw new Error("Nu există corecții pregătite. Rulează auditul.");
 const n=plan.reduce((a,b)=>a+b.fixes,0);
 if(!confirm(`ATENȚIE: vor fi actualizate ${plan.length} documente Outline (${n} linkuri). Versiunile vor fi reverificate. Confirmi?`))return;
 let done=0,skipped=0;
 for(const item of plan){
  try{
   const current=await outlineCall("documents.info",{id:item.id});
   if((current.text||"")!==item.before){skipped++;log("Audit omis – document modificat între timp: "+item.title,"AVERTISMENT");continue;}
   await outlineCall("documents.update",{id:item.id,text:item.after});done++;
  }catch(e){skipped++;log("Audit eșuat: "+item.title+" – "+e.message,"AVERTISMENT");}
 }
 state.auditPlan=[];$("applyAudit").hidden=true;
 $("auditReport").textContent+=`\n\nRezultat aplicare: ${done} documente actualizate, ${skipped} omise/eșuate.`;
 note(`Actualizare audit: ${done} documente, ${skipped} omise/eșuate.`);
}
function bind(id,handler){$(id).addEventListener("click",async()=>{
 $(id).disabled=true;
 try{await handler();}
 catch(e){fail(e);}
 finally{$(id).disabled=false;if(id==="migrate"||id==="exclude")statusUI();}
});}
$("isParent").addEventListener("change",()=>{$("existingActions").hidden=$("isParent").checked;statusUI();});
for(const id of ["destination","isParent","mode","imageWidth","imageMode","includeOtherAttachments","skipUnavailableExtras"])
 $(id).addEventListener("change",()=>{state.preview=null;statusUI();});
bind("saveSettings",saveSettings);bind("testOutline",testOutline);
bind("loadKb",async()=>{
 const tabs=await chrome.tabs.query({active:true,currentWindow:true});
 if(tabs?.[0]?.id)state.sourceTab=tabs[0].id;
 await loadKb();
});
bind("previewCode",async()=>{
 if(!state.page)throw new Error('Deschide și încarcă mai întâi o pagină KB.');
 const raw=KBConvert.stripExistingBlock(state.page.body?.storage?.value||'');
 const preview=KBConvert.convert(raw,{sourceBase:state.kb.baseUrl,pageId:state.kb.pageId,
  spaceKey:state.page.space?.key,imageWidth:Number($("imageWidth").value)||832,
  imageMode:$("imageMode").value});
 const sections=[];
 const re=/^(`{3,})([^\n]*)\n([\s\S]*?)\n\1\s*$/gm;
 let m;
 while((m=re.exec(preview.text))!==null&&sections.length<30)
  sections.push(`[Bloc ${sections.length+1}${m[2].trim()?` · ${m[2].trim()}`:''}]\n${m[3]}`);
 const content=sections.join('\n\n---\n\n');
 $("codePreview").hidden=false;
 $("codePreview").textContent=content
  ?content.slice(0,14000)+(content.length>14000?'\n[Restul blocurilor a fost trunchiat în previzualizare.]':'')
  :'Nu au fost detectate blocuri de cod multiline. Verifică dacă pagina sursă folosește text normal sau cod inline.';
 const warnings=preview.warnings.filter(w=>/comenzi nginx|BLOCANT/i.test(w));
 if(warnings.length)$("codePreview").textContent+='\n\n[Atenție] '+warnings.join(' | ');
 note(`Previzualizare locală: ${sections.length} blocuri de cod multiline. Nicio modificare în Confluence/Outline.`);
});
bind("migrate",migration);bind("fixAttachmentNames",fixAttachmentNames);bind("updateExisting",updateExisting);bind("exclude",exclude);bind("repairContent",repairContent);bind("continueRepair",async()=>{$("continueRepair").dataset.action==="update"?await updateExisting():await repairContent();});bind("fixLinks",fixLinks);
bind("auditCollection",auditCollection);bind("applyAudit",applyAudit);
bind("permissionStorage",async()=>{
 if(!state.permissionOrigin)throw new Error("Nu este cunoscut domeniul storage.");
 if(!(await chrome.permissions.request({origins:[state.permissionOrigin]})))throw new Error("Permisiune refuzată.");
 $("permissionStorage").hidden=true;log("Domeniu storage autorizat: "+state.permissionOrigin);note("Poți relua migrarea.");
});
$("copyLog").addEventListener("click",async()=>{await navigator.clipboard.writeText(state.logs.join("\n"));note("Jurnal copiat.");});
$("exportLog").addEventListener("click",()=>{
 const data={extension:"KB-Outline Migrator",version:"0.4.5",kbPageId:state.kb?.pageId,log:state.logs};
 const u=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:"application/json"}));
 const a=document.createElement("a");a.href=u;a.download="kb-migration-log.json";a.click();setTimeout(()=>URL.revokeObjectURL(u),2000);
});
// Recovery only when Outline is saved but KB has not yet been marked [M].
bind("finalizeKB",async()=>{
 if(!state.mapped?.outlineUrl)throw new Error("Nu există destinație Outline în registru.");
 const curStatus=migrationState();
 if(curStatus!=="P"){notifyLocked(curStatus);return;}
 const p=await KBBridge.getPage(state.sourceTab,state.kb.baseUrl,state.kb.pageId);
 const cur=(await KBBridge.getProperty(state.sourceTab,state.kb.baseUrl,state.kb.pageId))?.value||null;
 if(migrationState(p,cur)!=="P"){state.page=p;state.mapped=cur;statusUI();notifyLocked(migrationState());return;}
 state.preview={sourceVersion:p.version.number};
 await finishKBMigration(state.mapped.outlineUrl,state.mapped.outlineId);
 $("finalizeKB").hidden=true;statusUI();note("Marcarea KB [M] a fost finalizată.");
});
async function initializePopup(){
 await restoreSettings();
 try{
  // Chrome's activeTab permission is granted when clicking the extension icon.
  const tabs=await chrome.tabs.query({active:true,currentWindow:true});
  if(!tabs?.[0]?.id)throw new Error("Nu am găsit fila activă.");
  state.sourceTab=tabs[0].id;
  await loadKb();
 }catch(e){fail(e);$("sourceInfo").textContent="Deschide o pagină Confluence KB autentificată și apasă din nou pictograma extensiei.";}
}
initializePopup().catch(fail);
