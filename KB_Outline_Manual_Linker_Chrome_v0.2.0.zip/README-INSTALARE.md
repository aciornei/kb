# KB → Outline Manual Linker v0.2.0

Extensie Chrome independentă pentru asocierea paginilor Confluence KB 6.11.2 cu documente deja migrate manual în Outline. Nu transferă conținut sau fișiere, nu modifică documente Outline. Modifică doar pagina KB după confirmarea utilizatorului.

## Instalare / upgrade

1. Dezarhivează `KB_Outline_Manual_Linker_Chrome_v0.2.0.zip` într-un director permanent.
2. În `chrome://extensions`, activează **Developer mode**.
3. Dacă ai v0.1.0 instalată, înlocuiește conținutul directorului extensiei cu folderul `KB-Outline-Manual-Linker` din noul ZIP, apoi apasă **Reload**. Alternativ: **Load unpacked** selectând folderul nou.
4. Deschide pagina KB într-un tab Chrome. Poți ține această pagină pe monitorul 2, iar tabul extensiei pe monitorul 1.
5. Apasă pictograma extensiei. Se deschide sau se reactivează **același tab** de lucru; nu se creează taburi duplicate la fiecare click.

## Conectare Outline

1. În tabul **Conectare Outline**, completează URL-ul de bază (de exemplu `https://wiki.example.ro`) și tokenul personal.
2. Apasă **Salvează și testează conexiunea**. Extensia folosește `auth.info`; NU depinde de un termen de căutare.
3. Permite accesul Chrome la domeniul Outline la prima utilizare. Tokenul poate fi `read` sau `write` dacă serverul permite citire și căutare cu acel scope; în mediul unde se folosește deja `write`, acesta este suficient dacă drepturile contului permit citirea documentelor.
4. Fără **Reține tokenul**, cheia este păstrată în `chrome.storage.session`; cu opțiunea bifată, este păstrată în `chrome.storage.local` în profilul Chrome (extensia nu o criptează separat).

## Alegere KB pe două monitoare

- Intră în tabul **Asociere** și apasă **Reîncarcă din KB**.
- Modul **Automat** caută pagini Confluence în toate ferestrele Chrome. Dacă ai apăsat recent pictograma de pe o pagină KB, aceasta are prioritate; altfel este preferată pagina KB activă.
- Dacă există mai multe pagini KB deschise, alege una din lista **Fila KB de citit** și apasă **Reîncarcă din KB**.
- Dacă Chrome cere permisiune sau afișează mesajul că nu poate accesa pagina KB, apasă **Permite acces KB**. Va solicita acces **doar la domeniul KB** selectat.
- `chrome://`, `chrome-extension://`, `about:` și taburile interne nu sunt surse KB valide.
- Pentru fiecare pagină, extensia afișează titlul, pageId-ul, space-ul, versiunea și numărul filei Chrome.

## Asociere manuală

1. Deschide și citește pagina KB, apoi **Reîncarcă din KB** în extensie.
2. Extensia completează căutarea Outline cu titlul KB. Apasă **Caută** (poți modifica termenul).
3. Deschide linkurile rezultate în taburi noi și verifică documentul corect.
4. Selectează exact unul dintre rezultate (radio) și bifează **Am deschis documentul Outline selectat...**.
5. Butonul **Marchează pagina KB cu [M]** se activează. Sub buton este afișat permanent motivul pentru care este disponibil sau blocat.
6. Confirmă ultima verificare a pageId-ului, titlului și URL-ului Outline.
7. Extensia scrie `[M]` în titlul KB, statusul Confluence, persoana conectată, data și linkul Outline; înregistrează și Content Property `outline-migrator` pentru KB Inventory Reporter. Fila KB se reîncarcă automat pentru afișarea noului titlu.

## Stări existente și false pozitive

- `[M]` sau `[X]` în **titlul KB**: marcarea este blocată, fără opțiune de suprascriere.
- Dacă există în Confluence doar o **Content Property** `outline-migrator` cu `M`/`X`/`P` dar fără prefix în titlu, extensia NU spune simplu „deja marcată”. Afișează separat starea titlului, proprietatea existentă și linkul vechi.
- În acest caz, pentru a corecta registrul sunt necesare **două confirmări**: verificarea documentului ales și bifa suplimentară de corectare.
- Un registru cu alt `kbPageId` sau un conflict între `[M]`/`[X]` și proprietate este blocat pentru intervenție manuală.
- Marcajele sunt informații citite de pe **serverul Confluence**, nu din istoricul stației sau al Chrome-ului utilizatorului.

## Jurnal

Tabul **Jurnal** conține pașii și mesajele de eroare și poate fi copiat. Tokenul Outline nu este scris în jurnal. Înainte de a trimite logul pentru suport, verifică dacă titlurile sau URL-urile sunt confidențiale.

## Compatibilitate

- Chrome Manifest V3.
- Necesită sesiune autenticată în Confluence KB și permisiuni de editare a paginii.
- Necesită acces Outline și token API cu permisiuni de căutare și informare document.
- Raportarea Excel din extensia KB Inventory citește `[M]` și antetul înscris de acest instrument.
- Testele locale simulate nu înlocuiesc testul pe serverele reale Confluence / Outline.
