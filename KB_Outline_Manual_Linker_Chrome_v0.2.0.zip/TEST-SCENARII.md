# Scenarii de test – Manual Linker v0.2.0

## Teste automatizate locale (simulare, fără servere reale)

1. Detectare Confluence: pagina activă într-o altă fereastră Chrome este identificată, iar `chrome://extensions` este exclusă.
2. Test Outline: `auth.info` funcționează când termenul de căutare este gol.
3. Căutare: `documents.search_titles` afișează radio și URL-ul documentului.
4. Confirmare: butonul `[M]` este inițial dezactivat și devine activ după selecție + bifă.
5. Confirmare API: se verifică `documents.info` pe ID înainte de marcare.
6. Scriere: `PUT /rest/api/content/{pageId}` adaugă `[M]`, bannerul, responsabilul, data și linkul Outline.
7. Registru vechi M fără prefix: afișează o neconcordanță și permite marcarea numai după confirmarea suplimentară.
8. Titlu `[M]`: marcarea rămâne blocată.
9. Proprietate cu alt `kbPageId`: conflict blocant, fără suprascriere.
10. Schimbarea filei KB invalidează rezultatul Outline anterior pentru a evita marcarea paginii greșite.

## Verificări în mediul real (de făcut de administrator)

1. O pagină KB neevaluată și un document Outline cu titlu identic.
2. Două pagini KB în ferestre Chrome diferite, pe două monitoare: navigare pe monitorul KB și **Reîncarcă din KB** pe monitorul extensiei.
3. O pagină KB fără prefix dar cu proprietate `outline-migrator` rămasă dintr-o operație veche.
4. O pagină deja `[M]` și una `[X]`: ambele trebuie blocate.
5. Testare conexiune în tabul **Conectare Outline** fără a încărca pagina KB.
6. După marcare, verifică actualizarea vizuală a Confluence, responsabilul, data și linkul Outline.
7. Reexportă KB Inventory: pagina trebuie să apară MIGRATĂ `[M]`.
8. Verifică un token Outline cu drepturi insuficiente și o pagină KB fără drept de editare: mesajul trebuie să explice eroarea, fără marcare falsă.
