"use strict";
/* Pure helpers: intentionally no Chrome APIs, network, or DOM dependencies. */
const KBLinkCore = (() => {
  const cleanTitle = s => String(s || "").replace(/^\s*\[(?:M|X|NM)\]\s*/i, "").trim();
  const normalize = s => cleanTitle(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[șş]/gi,"s").replace(/[țţ]/gi,"t").toLocaleLowerCase("ro").replace(/[^\p{L}\p{N}]+/gu," ").trim().replace(/\s+/g," ");
  function similarity(a,b) {
    const x=normalize(a),y=normalize(b);
    if(!x || !y) return 0;
    if(x===y)return 100;
    if(x.startsWith(y)||y.startsWith(x))return 80;
    const aa=new Set(x.split(" ")),bb=new Set(y.split(" "));
    let n=0;for(const w of aa)if(bb.has(w))n++;
    return Math.round(n/Math.max(aa.size,bb.size)*65);
  }
  function unwrapResults(body) {
    const data=body?.data??body;
    const arr=Array.isArray(data)?data:Array.isArray(data?.results)?data.results:Array.isArray(data?.documents)?data.documents:[];
    return arr.map(item=>{
      const d=item?.document??item?.data?.document??item;
      if(!d || typeof d!=="object")return null;
      const id=String(d.id||d.urlId||"").trim();
      const title=String(d.title||"").trim();
      if(!id || !title)return null;
      return {id,title,url:String(d.url||item?.url||""),collection:String(d.collection?.name||d.collectionName||item?.collection?.name||""),updatedAt:String(d.updatedAt||""),archived:!!d.archivedAt};
    }).filter(Boolean);
  }
  function linkFor(doc, outlineBase) {
    const base=new URL(outlineBase),href=doc.url?new URL(doc.url,base.href.replace(/\/$/,"")+"/"):new URL("doc/"+encodeURIComponent(doc.id),base.href.replace(/\/$/,"")+"/");
    if(href.origin!==base.origin || !["https:","http:"].includes(href.protocol))throw new Error("Documentul are un URL din afara serverului Outline configurat.");
    href.hash="";
    return href.href;
  }
  function esc(s) {return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");}
  function markBlock(user,date,url) {
    return `<ac:structured-macro ac:name="status" ac:schema-version="1"><ac:parameter ac:name="title">MIGRAT ÎN OUTLINE</ac:parameter><ac:parameter ac:name="colour">Green</ac:parameter></ac:structured-macro>`+
      `<p><strong>KB → Outline</strong> | Responsabil: ${esc(user)} | Data: ${esc(date)}</p>`+
      `<p><strong>Destinație Outline:</strong> <a href="${esc(url)}">${esc(url)}</a></p><hr />`;
  }
  function statusDetail(page, record) {
    const prefix=String(page?.title||"").match(/^\s*\[(M|X)\](?:\s|$)/i)?.[1]?.toUpperCase()||"";
    const rawStatus=String(record?.status||"").toUpperCase();
    const registry=["M","X","P"].includes(rawStatus)?rawStatus:"";
    const pageId=String(page?.id||"");
    const recordPageId=String(record?.kbPageId||"");
    const mismatchedPage=!!recordPageId && !!pageId && recordPageId!==pageId;
    const storage=String(page?.body?.storage?.value||"").slice(0,1800);
    const banner=storage.match(/^\s*<ac:structured-macro\b[^>]*ac:name=["']status["'][^>]*>[\s\S]{0,700}?<ac:parameter\s+ac:name=["']title["']>(MIGRAT ÎN OUTLINE|EXCLUS DIN MIGRARE)<\/ac:parameter>/i);
    const headerStatus=banner?.[1]?.toUpperCase().startsWith("MIGRAT")?"M":banner?"X":"";
    if(mismatchedPage)return {code:"CONFLICT",prefix,registry,headerStatus,blocked:true,override:false,reason:"Registrul outline-migrator indică ALT pageId ("+recordPageId+"). Nu se poate marca automat."};
    if(prefix && registry && registry!==prefix && registry!=="P")return {code:"CONFLICT",prefix,registry,headerStatus,blocked:true,override:false,reason:"Titlul ["+prefix+"] și registrul ("+registry+") nu corespund."};
    if(prefix)return {code:prefix,prefix,registry,headerStatus,blocked:true,override:false,reason:prefix==="M"?"Titlul are deja [M]; nu marcăm din nou.":"Titlul are deja [X]; pagina este exclusă."};
    if(registry || headerStatus) {
      const code=registry==="P"?"PENDING":"REVIEW_REGISTRY";
      return {code,prefix,registry,headerStatus,blocked:false,override:true,
        reason:"Titlul nu are [M]/[X], dar "+(registry?"registrul outline-migrator conține starea "+registry:"antetul din conținut indică "+headerStatus)+". Verifică și confirmă explicit corectarea."};
    }
    return {code:"",prefix,registry,headerStatus,blocked:false,override:false,reason:"Pagina nu are marcaj de migrare sau excludere."};
  }
  function status(page,record){ return statusDetail(page,record).code; }
  function stripExistingBlock(xml){
    return String(xml||"").replace(/^\s*<ac:structured-macro ac:name="status" ac:schema-version="1"><ac:parameter ac:name="title">(?:MIGRAT ÎN OUTLINE|EXCLUS DIN MIGRARE)<\/ac:parameter><ac:parameter ac:name="colour">(?:Green|Grey)<\/ac:parameter><\/ac:structured-macro><p><strong>KB → Outline<\/strong> \| Responsabil: [\s\S]*?<\/p><p><strong>(?:Destinație Outline|Motiv):<\/strong>[\s\S]*?<\/p><hr\s*\/>/,"");
  }
  function day(d){const z=new Date(d);if(!Number.isFinite(z.getTime()))throw Error("Data invalidă.");return `${z.getFullYear()}-${String(z.getMonth()+1).padStart(2,"0")}-${String(z.getDate()).padStart(2,"0")}`;}
  return {cleanTitle,normalize,similarity,unwrapResults,linkFor,markBlock,status,statusDetail,stripExistingBlock,day};
})();
if(typeof module!=="undefined"&&module.exports)module.exports=KBLinkCore;
