"use strict";
// Confluence calls run inside the KB tab, same-origin, with its existing session.
// The extension never reads or exports session cookies or password fields.
const KBBridge = (() => {
  async function execute(tabId, func, args = []) {
    const results = await chrome.scripting.executeScript({target:{tabId},world:"MAIN",func,args});
    const v = results?.[0]?.result;
    if (!v) throw new Error("Pagina Confluence nu a răspuns; verifică fila și permisiunile Chrome.");
    if (v.__error) throw new Error(v.__error);
    return v;
  }
  async function detect(tabId) {
    return execute(tabId, () => {
      const meta = (name) => document.querySelector(`meta[name="${name}"]`)?.content || "";
      const u = new URL(location.href);
      const pageId = u.searchParams.get("pageId") || meta("ajs-page-id") || meta("ajs-content-id") || document.querySelector("#pageId")?.value || "";
      const rawBase = meta("ajs-base-url");
      let ctx = "";
      if (rawBase) { try { const b = new URL(rawBase,location.href); if (b.origin===u.origin) ctx=b.pathname.replace(/\/$/,""); } catch(_){} }
      if (!rawBase) { const m=u.pathname.match(/^(.*?)(?:\/display\/|\/pages\/|\/rest\/api\/|\/viewpage\.action)/);if(m)ctx=m[1]; }
      return {pageId:/^\d+$/.test(String(pageId))?String(pageId):"",title:document.querySelector("#title-text")?.textContent?.trim()||document.title,
        baseUrl:u.origin+ctx,origin:u.origin,contextPath:ctx,url:u.href};
    });
  }
  async function request(tabId, base, path, method = "GET", data = null, binary = false, maxMB = 20) {
    return execute(tabId, async (baseUrl, requestPath, verb, payload, asBinary, maxSize) => {
      try {
        const b=new URL(baseUrl);
        const u=new URL(requestPath, baseUrl.endsWith("/")?baseUrl:baseUrl+"/");
        if (u.origin!==b.origin) throw new Error("Refuz adresă în afara domeniului KB.");
        const headers={Accept:asBinary?"*/*":"application/json"};
        if (payload!==null) headers["Content-Type"]="application/json";
        const res=await fetch(u.href,{method:verb,credentials:"same-origin",cache:"no-store",redirect:"follow",headers,body:payload===null?undefined:JSON.stringify(payload)});
        if (asBinary) {
          const len=Number(res.headers.get("content-length")||0);
          if(len>maxSize) throw new Error("Fișier mai mare decât limita ("+Math.round(len/1024/1024)+" MB).");
          if(!res.ok) throw new Error("Descărcare HTTP "+res.status);
          const type=res.headers.get("content-type")||"application/octet-stream";
          if(type.toLowerCase().includes("text/html")) throw new Error("KB a returnat HTML în locul fișierului (posibil login). ");
          const arr=new Uint8Array(await res.arrayBuffer());
          if(arr.byteLength>maxSize) throw new Error("Fișierul depășește limita de "+(maxSize/1048576)+" MB.");
          let str="";for(let i=0;i<arr.length;i+=32768)str+=String.fromCharCode(...arr.subarray(i,i+32768));
          return {ok:true,status:res.status,base64:btoa(str),size:arr.length,mime:type};
        }
        const ct=res.headers.get("content-type")||"";
        const txt=await res.text();
        if(!ct.toLowerCase().includes("json")) throw new Error("Răspuns ne-JSON "+res.status+" (login/redirecționare?)");
        let json;try{json=JSON.parse(txt);}catch(_){throw new Error("JSON invalid: "+txt.slice(0,130));}
        return {ok:res.ok,status:res.status,data:json};
      } catch(e) { return {__error:String(e.message||e)}; }
    },[base,path,method,data,binary,maxMB*1048576]);
  }
  function api(tabId, base, path, method="GET",data=null){return request(tabId,base,"rest/api/"+path,method,data);}
  async function getPage(tabId,base,id) {
    const r=await api(tabId,base,`content/${encodeURIComponent(id)}?expand=version,body.storage,space`);
    if(!r.ok)throw new Error("Citire pagină KB: HTTP "+r.status);
    return r.data;
  }
  async function getUser(tabId,base) {
    const r=await api(tabId,base,"user/current");
    if(!r.ok||!r.data?.username)throw new Error("Nu s-a identificat utilizatorul KB: "+r.status);
    return r.data;
  }
  // The rendered Confluence page has actual URLs for cross-page attachment
  // links. These are not included in /content/{currentPage}/child/attachment.
  async function getRenderedAttachmentLinks(tabId) {
    return execute(tabId, () => {
      const result=[];
      for(const a of document.querySelectorAll('a[href], img[src]')){
        try {
          const u=new URL(a.getAttribute('href')||a.getAttribute('src'),location.href);
          if(u.origin!==location.origin)continue;
          const m=u.pathname.match(/\/download\/attachments\/(\d+)\/([^/]+)$/i);
          if(!m)continue;
          let fileName='';
          try{fileName=decodeURIComponent(m[2]);}catch(_){fileName=m[2];}
          const id=a.getAttribute('data-linked-resource-container-id')||m[1];
          result.push({href:u.href,containerId:id,filename:a.getAttribute('data-linked-resource-default-alias')||fileName,
            displayedText:(a.textContent||'').trim().slice(0,300)});
        } catch(_) {}
      }
      return result;
    });
  }
  // Visible labels from the rendered Confluence document. Useful for legacy
  // links where storage contains only a resource title/filename, while the
  // rendered anchor has a custom label.
  async function getRenderedPageLinks(tabId) {
    return execute(tabId, () => {
      const area=document.querySelector('#main-content .wiki-content') ||
        document.querySelector('#main-content') || document.querySelector('#content .wiki-content') ||
        document.querySelector('.wiki-content');
      if(!area)return [];
      const result=[];
      for(const a of area.querySelectorAll('a[href]')){
        const label=(a.textContent||'').replace(/\s+/g,' ').trim();
        if(!label)continue;
        try{
          const url=new URL(a.getAttribute('href'),location.href);
          if(url.origin!==location.origin)continue;
          const id=a.getAttribute('data-linked-resource-id')||url.searchParams.get('pageId')||'';
          result.push({href:url.href,contentId:/^\d+$/.test(id)?id:'',label});
        }catch(_){}
      }
      return result;
    });
  }
  async function getAttachments(tabId,base,id) {
    let start=0;const all=[];
    for(let round=0;round<30;round++){
      const r=await api(tabId,base,`content/${id}/child/attachment?limit=100&start=${start}`);
      if(!r.ok)throw new Error("Atașamente KB: HTTP "+r.status);
      all.push(...(r.data.results||[]));
      if(!(r.data._links?.next) && (r.data.results||[]).length<100)break;
      start+=100;
    }
    return all;
  }
  async function getProperty(tabId,base,id,key="outline-migrator"){
    const r=await api(tabId,base,`content/${id}/property/${encodeURIComponent(key)}`);
    if(r.status===404)return null;
    if(!r.ok) throw new Error("Citire proprietate KB: "+r.status);
    return r.data;
  }
  async function setProperty(tabId,base,id,value,key="outline-migrator"){
    const old=await getProperty(tabId,base,id,key);
    const path=`content/${id}/property`+(old?`/${encodeURIComponent(key)}`:"");
    const payload=old?{key,value,version:{number:(old.version?.number||1)+1}}:{key,value};
    const r=await api(tabId,base,path,old?"PUT":"POST",payload);
    if(!r.ok)throw new Error("Salvare registru migrare (Content Property): HTTP "+r.status+" "+JSON.stringify(r.data).slice(0,180));
    return r.data;
  }
  async function updatePage(tabId,base,pageId,newTitle,newStorage,expectVersion) {
    const p=await getPage(tabId,base,pageId);
    if(expectVersion!==undefined && expectVersion!==null && p.version?.number!==expectVersion)
      throw new Error("Pagina KB a fost modificată între timp (versiune "+p.version?.number+" vs "+expectVersion+"). Reîncarcă pagina înainte de modificare.");
    const payload={id:String(pageId),type:"page",title:newTitle,space:{key:p.space.key},
      body:{storage:{value:newStorage,representation:"storage"}},version:{number:p.version.number+1,minorEdit:true,message:"KB → Outline Migrator"}};
    const r=await api(tabId,base,`content/${pageId}`,"PUT",payload);
    if(!r.ok)throw new Error("Actualizare Confluence: HTTP "+r.status+" "+JSON.stringify(r.data).slice(0,240));
    return r.data;
  }
  return {detect,request,api,getPage,getUser,getAttachments,getRenderedAttachmentLinks,getRenderedPageLinks,getProperty,setProperty,updatePage};
})();
