"use strict";
// Keep one full-page workspace. Never treat a chrome:// or extension:// tab as KB.
function potentialKb(url) {
  try {
    const u=new URL(url);
    return ["http:","https:"].includes(u.protocol) &&
      (/\/(?:display\/|pages\/viewpage\.action|pages\/|viewpage\.action|spaces\/)/i.test(u.pathname) || /(?:^|\.)kb\.|confluence/i.test(u.hostname));
  } catch (_) { return false; }
}
chrome.action.onClicked.addListener(async tab => {
  if (tab?.id && potentialKb(tab.url)) {
    await chrome.storage.session.set({preferredKBTabId:tab.id,preferredKBAt:Date.now()});
  }
  const url=chrome.runtime.getURL("match.html");
  const tabs=await chrome.tabs.query({});
  const found=tabs.find(t=>t.url?.startsWith(url));
  if(found) {
    await chrome.tabs.update(found.id,{active:true});
    await chrome.windows.update(found.windowId,{focused:true});
    chrome.runtime.sendMessage({type:"KB_TAB_CHANGED"}).catch(()=>{});
  } else {
    await chrome.tabs.create({url});
  }
});
