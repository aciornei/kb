"use strict";
const $=id=>document.getElementById(id);
const state={tabs:[],sourceTabId:0,kb:null,page:null,user:null,property:null,readVersion:0,
  base:"",token:"",connectionOk:false,results:[],selectedId:"",searchBase:"",searchQuery:"",mode:"",nextOffset:0,more:false,
  busy:false,searchBusy:false,logs:[],panel:"associate",kbOrigins:[],preferredKBTabId:0,preferredKBAt:0,preferClickedOnce:true,pendingPermissionTabId:0};

function log(message,level="INFO"){
  let clean=String(message);
  if(state.token)clean=clean.split(state.token).join("[TOKEN ASCUNS]");
  clean=clean.replace(/Bearer\s+[^\s]+/gi,"Bearer [TOKEN ASCUNS]");
  const line=`${new Date().toLocaleTimeString("ro-RO",{hour12:false})} [${level}] ${clean}`;
  state.logs.push(line);if(state.logs.length>600)state.logs.shift();
  $("log").textContent=state.logs.join("\n");$("log").scrollTop=$("log").scrollHeight;
  $("logCount").textContent=String(state.logs.length);
}
function notice(text,type=""){$("notice").textContent=String(text);$("notice").className="notice"+(type?" "+type:"");}
function showPanel(panel){
  if(!["associate","settings","journal"].includes(panel))panel="associate";
  state.panel=panel;
  for(const p of ["associate","settings","journal"]){
    $("panel"+p[0].toUpperCase()+p.slice(1)).hidden=p!==panel;
    const btn=document.querySelector(`.navtab[data-panel="${p}"]`);
    btn.classList.toggle("active",p===panel);btn.setAttribute("aria-selected",String(p===panel));
  }
}
function baseUrl(input){
  const u=new URL(String(input||"").trim());
  if(!["https:","http:"].includes(u.protocol)||u.username||u.password||u.search||u.hash)
    throw Error("Introdu URL-ul HTTP(S) al serverului Outline, fără date de autentificare, parametri sau ancore.");
  return u.origin+u.pathname.replace(/\/$/,"");
}
function originPattern(url){return new URL(url).origin+"/*";}
function httpUrl(url){try{return ["http:","https:"].includes(new URL(url).protocol);}catch(_){return false;}}
function isKbCandidate(tab){
  if(!httpUrl(tab.url))return false;
  const u=new URL(tab.url);
  if(state.base && u.origin===new URL(state.base).origin && u.pathname.startsWith(new URL(state.base).pathname+"/api"))return false;
  return /\/(?:display\/|pages\/viewpage\.action|viewpage\.action|spaces\/|pages\/)/i.test(u.pathname)
    || /(?:^|\.)kb\.|confluence/i.test(u.hostname)
    || state.kbOrigins.includes(u.origin)
    || (state.sourceTabId>0 && tab.id===state.sourceTabId);
}
function statusDetail(){return KBLinkCore.statusDetail(state.page,state.property?.value||null);}
function selectedDoc(){return state.results.find(d=>d.id===state.selectedId)||null;}
function markBlockReason(){
  const st=statusDetail();
  if(state.busy)return "Se efectuează o operație. Așteaptă finalizarea.";
  if(!state.page)return "Încarcă pagina KB din primul pas.";
  if(st.blocked)return st.reason;
  if(!selectedDoc())return "Selectează un document dintre rezultatele Outline.";
  if(!$("reviewed").checked)return "Bifează confirmarea după ce verifici documentul Outline.";
  if(st.override&&!$("allowOverride").checked)return "Bifează confirmarea suplimentară pentru registrul/antetul KB inconsistent.";
  let currentBase="";try{currentBase=baseUrl($("outlineBase").value);}catch(_){return "URL-ul Outline este invalid. Verifică setările.";}
  if(!state.searchBase||currentBase!==state.searchBase)return "Setările Outline au fost schimbate. Reia căutarea.";
  return "Pregătit: poți marca pagina KB cu [M].";
}
function updateActions(){
  const st=statusDetail(),box=$("kbStatus");
  box.hidden=!(st.code||st.reason&&st.code);
  if(!box.hidden){
    const record=state.property?.value;
    const details=record?.outlineUrl?"\nLink existent în registru: "+record.outlineUrl:"";
    box.textContent=st.reason+details+"\nStare titlu: "+(st.prefix||"fără prefix")+" · Registru: "+(st.registry||"absent")+" · Antet: "+(st.headerStatus||"absent");
  }
  $("overrideSection").hidden=!st.override;
  const reason=markBlockReason();$("markReason").textContent=reason;
  $("mark").disabled=reason!=="Pregătit: poți marca pagina KB cu [M].";
  $("search").disabled=state.searchBusy;
  $("more").disabled=state.searchBusy;
}
function resetSelection(){
  state.selectedId="";state.results=[];state.nextOffset=0;state.more=false;state.mode="";state.searchBase="";state.searchQuery="";
  $("reviewed").checked=false;$("allowOverride").checked=false;
  $("selectedInfo").textContent="Nu ai ales niciun document Outline.";
  $("results").replaceChildren();$("searchInfo").textContent="";$("more").hidden=true;
  updateActions();
}
async function restoreConfig(){
  const saved=await chrome.storage.local.get(["outlineBase","rememberToken","outlineToken","kbOrigins"]);
  const session=await chrome.storage.session.get(["outlineToken"]);
  $("outlineBase").value=saved.outlineBase||"";
  $("outlineToken").value=session.outlineToken||saved.outlineToken||"";
  $("rememberToken").checked=!!saved.rememberToken;
  state.token=$("outlineToken").value.trim();state.base=saved.outlineBase||"";
  state.kbOrigins=Array.isArray(saved.kbOrigins)?saved.kbOrigins.filter(httpUrl):[];
  updateConnectionSummary();
}
function updateConnectionSummary(){
  $("connectionSummary").textContent=state.base
    ? "Outline configurat: "+state.base+(state.connectionOk?" · conexiune verificată":" · testare necesară dacă ai schimbat tokenul")
    : "Serverul Outline nu este configurat. Intră în tabul «Conectare Outline».";
}
async function saveConfig(base,token){
  state.base=base;state.token=token;
  await chrome.storage.local.set({outlineBase:base,rememberToken:$("rememberToken").checked});
  await chrome.storage.session.set({outlineToken:token});
  if($("rememberToken").checked)await chrome.storage.local.set({outlineToken:token});
  else await chrome.storage.local.remove("outlineToken");
  updateConnectionSummary();
}
async function outlineCall(endpoint,data){
  const base=baseUrl($("outlineBase").value);
  const token=$("outlineToken").value.trim();
  if(!token)throw Error("Tokenul Outline lipsește. Intră în tabul «Conectare Outline».");
  if(!await chrome.permissions.contains({origins:[originPattern(base)]}))
    throw Error("Nu există permisiune pentru serverul Outline. Intră în «Conectare Outline» și testează conexiunea.");
  let response;
  try{response=await fetch(base+"/api/"+endpoint,{method:"POST",headers:{"Authorization":"Bearer "+token,"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(data||{}),cache:"no-store"});}
  catch(e){throw Error("Conectare Outline: "+String(e?.message||e));}
  const raw=await response.text();let obj;
  try{obj=JSON.parse(raw);}catch(_){const err=Error("Outline "+endpoint+": HTTP "+response.status+" (răspuns non-JSON: proxy/login?)");err.status=response.status;throw err;}
  if(!response.ok||obj.success===false||obj.ok===false){
    const err=Error("Outline "+endpoint+": HTTP "+response.status+" — "+String(obj.message||obj.error||"API error").slice(0,220));err.status=response.status;throw err;
  }
  return obj;
}
async function connect(){
  // Critical: request Chrome permission directly from the user's click.
  const base=baseUrl($("outlineBase").value),token=$("outlineToken").value.trim();
  if(!token)throw Error("Introdu tokenul personal Outline.");
  if(!await chrome.permissions.request({origins:[originPattern(base)]}))throw Error("Permisiunea Chrome pentru Outline a fost refuzată.");
  await saveConfig(base,token);state.connectionOk=false;
  $("connectionTest").textContent="Se verifică tokenul Outline prin auth.info…";
  try{
    const info=await outlineCall("auth.info",{});
    const user=info.data?.user||info.user||info.data||{};
    state.connectionOk=true;
    const name=user.name||user.email||user.username||"autentificat";
    $("connectionTest").textContent="Conexiune OK. Utilizator Outline: "+name;
    notice("Conexiunea Outline a fost verificată prin auth.info; poți începe căutarea.","ok");
    log("Outline conectat și verificat prin auth.info pentru "+name+" ("+base+").");
  }catch(e){$("connectionTest").textContent="Test eșuat: "+e.message;throw e;}
  finally{updateConnectionSummary();}
}
async function scanKbTabs(){
  const tabs=await chrome.tabs.query({});
  const allHttp=tabs.filter(t=>t.id&&httpUrl(t.url));
  let matches=allHttp.filter(isKbCandidate);
  if(!matches.length){
    // Custom Confluence routes: allow manual choice instead of silently using chrome://.
    const outlineOrigin=state.base?new URL(state.base).origin:"";
    matches=allHttp.filter(t=>new URL(t.url).origin!==outlineOrigin);
  }
  const saved=await chrome.storage.session.get(["preferredKBTabId","preferredKBAt"]);
  const preferred=Number(saved.preferredKBTabId||0);
  state.preferredKBTabId=preferred;state.preferredKBAt=Number(saved.preferredKBAt||0);
  matches.sort((a,b)=>(Number(b.active)-Number(a.active))*1000000000+(Number(b.id===preferred)-Number(a.id===preferred))*100000000+(Number(b.lastAccessed||0)-Number(a.lastAccessed||0)));
  state.tabs=matches;
  const sel=$("kbTabSelect"),old=sel.value;
  sel.replaceChildren(new Option("Automat – pagina KB activă dintre ferestrele Chrome","auto"));
  for(const t of matches){
    const label=(t.active?"● ":"")+(t.title||t.url||"Filă")+" · fila #"+t.id;
    sel.add(new Option(label.slice(0,200),"tab:"+t.id));
  }
  if([...sel.options].some(o=>o.value===old))sel.value=old;
  else sel.value="auto";
  if(!matches.length)log("Nu am găsit file HTTP(S) potențial KB. Deschide pagina Confluence și actualizează lista.","AVERTISMENT");
  else log("File KB candidate: "+matches.length+"; modul de selecție: "+sel.value);
  return matches;
}
function chooseKbTab(){
  const value=$("kbTabSelect").value;
  if(value.startsWith("tab:"))return state.tabs.find(x=>x.id===Number(value.slice(4)))||null;
  // A recent click on the extension icon on a KB tab takes priority.
  // Otherwise the active KB tab in another Chrome window wins.
  const recentClick=Date.now()-state.preferredKBAt<12000 && state.preferredKBAt<=Date.now();
  const source=recentClick&&state.preferClickedOnce?state.tabs.find(t=>t.id===state.preferredKBTabId):null;
  return source||state.tabs.find(t=>t.active)||state.tabs[0]||null;
}
async function requestKbPermission(tab){
  if(!tab||!httpUrl(tab.url))throw Error("Deschide o pagină Confluence HTTP(S) și selectează fila corectă.");
  const pattern=originPattern(tab.url);
  if(!await chrome.permissions.request({origins:[pattern]}))throw Error("Permisiunea de acces la domeniul KB a fost refuzată.");
  notice("Acces KB acordat. Apasă «Reîncarcă din KB». ","ok");
  log("Acces la sursa KB acordat pentru domeniul "+new URL(tab.url).origin);
}
async function loadKb(tab){
  if(!tab||!httpUrl(tab.url))throw Error("Nu există o filă KB validă. Nu se pot citi pagini chrome://.");
  const tabId=tab.id;
  state.pendingPermissionTabId=tabId;
  let kb;
  try{kb=await KBBridge.detect(tabId);}
  catch(e){
    if(/Cannot access|permission|host|chrome:\/\//i.test(String(e.message||e)))
      throw Error("Chrome nu are permisiune pentru fila KB «"+(tab.title||tab.url)+"». Apasă «Permite acces KB», apoi «Reîncarcă din KB». ");
    throw e;
  }
  if(!kb.pageId)throw Error("Fila aleasă nu conține un pageId Confluence. Alege din listă pagina KB deschisă, nu tabul Outline.");
  const page=await KBBridge.getPage(tabId,kb.baseUrl,kb.pageId);
  const user=await KBBridge.getUser(tabId,kb.baseUrl);
  const property=await KBBridge.getProperty(tabId,kb.baseUrl,kb.pageId);
  if(String(page.id)!==String(kb.pageId))throw Error("API-ul KB a returnat alt pageId. Reîncarcă pagina sursă.");
  state.pendingPermissionTabId=0;
  state.sourceTabId=tabId;state.kb=kb;state.page=page;state.user=user;state.property=property;state.readVersion=Number(page.version?.number||0);
  $("kbTitle").textContent=page.title;
  const kbLink=kb.baseUrl.replace(/\/$/,"")+"/pages/viewpage.action?pageId="+encodeURIComponent(kb.pageId);
  const a=document.createElement("a");a.href=kbLink;a.target="_blank";a.rel="noopener noreferrer";a.textContent="Deschide KB (pageId "+kb.pageId+")";
  $("kbMeta").replaceChildren(a,document.createTextNode(" · Space "+(page.space?.key||"?")+" · versiune "+state.readVersion+" · fila Chrome #"+tabId));
  $("responsible").textContent="Confirmă: "+(user.displayName||user.username)+" ("+user.username+") · Data: "+KBLinkCore.day(new Date());
  $("query").value=KBLinkCore.cleanTitle(page.title);
  resetSelection();updateActions();
  const origin=new URL(kb.baseUrl).origin;
  if(!state.kbOrigins.includes(origin)){
    state.kbOrigins.push(origin);
    state.kbOrigins=state.kbOrigins.slice(-20);
    await chrome.storage.local.set({kbOrigins:state.kbOrigins});
  }
  const st=statusDetail();
  notice(st.code?"KB citit: "+page.title+". ATENȚIE: "+st.reason:"KB citit: "+page.title+". Poți căuta în Outline.",st.blocked?"error":"ok");
  log("KB citit din fila #"+tabId+": pageId="+kb.pageId+"; titlu «"+page.title+"»; stare="+(st.code||"NEEVALUAT")+"; titlu-prefix="+(st.prefix||"absent")+"; registru="+(st.registry||"absent")+"; utilizator="+user.username);
}
async function refreshFromKb(){
  await scanKbTabs();
  const tab=chooseKbTab();
  if(!tab)throw Error("Nu am găsit fila KB. Deschide pagina Confluence pe celălalt monitor și apasă «Actualizează lista».");
  await loadKb(tab);
  if(state.base&&$("outlineToken").value.trim()&&await chrome.permissions.contains({origins:[originPattern(state.base)]})){
    if($("query").value.trim().length>=2)await runSearch(false);
  }
}
function renderResults(){
  const root=$("results");root.replaceChildren();
  if(!state.results.length){const empty=document.createElement("div");empty.className="empty";empty.textContent="Nu există rezultate. Încearcă un termen mai scurt sau alt titlu.";root.append(empty);}
  for(const [i,doc] of state.results.entries()){
    const tile=document.createElement("div");tile.className="result";
    const head=document.createElement("div");head.className="result-head";
    const radio=document.createElement("input");radio.type="radio";radio.name="selectedDocument";radio.value=doc.id;radio.id="doc"+i;radio.checked=state.selectedId===doc.id;
    radio.addEventListener("change",()=>selectResult(doc.id));
    const content=document.createElement("div");content.className="result-content";
    const title=document.createElement("label");title.className="result-title";title.htmlFor=radio.id;title.textContent=doc.title;
    const meta=document.createElement("div");meta.className="result-meta";
    const info=[];if(doc.collection)info.push("Colecție: "+doc.collection);if(doc.updatedAt)info.push("Modificat: "+doc.updatedAt.slice(0,10));if(doc.archived)info.push("Arhivat");meta.textContent=info.join(" · ")||"Document în Outline";
    const url=document.createElement("div");url.className="result-url";const a=document.createElement("a");
    try{a.href=KBLinkCore.linkFor(doc,state.base);a.textContent=a.href;a.target="_blank";a.rel="noopener noreferrer";}
    catch(e){a.textContent="URL invalid: "+e.message;radio.disabled=true;}
    url.append(a);content.append(title,meta,url);
    const score=KBLinkCore.similarity(state.page?.title||state.searchQuery,doc.title);
    const badge=document.createElement("span");badge.className="match-badge"+(score<80?" partial":"");badge.textContent=score===100?"Titlu identic":score>=80?"Titlu apropiat":"De verificat";
    head.append(radio,content,badge);tile.append(head);root.append(tile);
  }
  $("more").hidden=!state.more;updateActions();
}
function selectResult(id){
  state.selectedId=id;$("reviewed").checked=false;
  for(const radio of document.querySelectorAll('input[name="selectedDocument"]'))radio.checked=radio.value===id;
  const doc=selectedDoc();if(!doc){$("selectedInfo").textContent="Nu ai ales niciun document Outline.";updateActions();return;}
  const title=document.createElement("strong");title.textContent=doc.title;
  const line=document.createElement("div");line.textContent="ID document: "+doc.id;
  const a=document.createElement("a");a.href=KBLinkCore.linkFor(doc,state.base);a.target="_blank";a.rel="noopener noreferrer";a.textContent=a.href;
  $("selectedInfo").replaceChildren(title,line,a);
  log("Document Outline selectat: "+doc.id+" / "+doc.title);
  updateActions();
}
async function runSearch(append=false){
  if(state.searchBusy)return;
  const query=$("query").value.trim();if(query.length<2)throw Error("Introdu cel puțin 2 caractere pentru căutare.");
  const base=baseUrl($("outlineBase").value);
  state.searchBusy=true;updateActions();
  try{
    if(!append){
      state.results=[];state.selectedId="";state.nextOffset=0;state.more=false;state.mode="";state.searchBase=base;state.searchQuery=query;
      $("reviewed").checked=false;$("selectedInfo").textContent="Nu ai ales niciun document Outline.";
    }
    if(append&&(query!==state.searchQuery||base!==state.searchBase))throw Error("Termenul sau serverul a fost modificat. Reia căutarea.");
    const offset=state.nextOffset,limit=50;let op=state.mode||"documents.search_titles",res;
    try{res=await outlineCall(op,{query:state.searchQuery,offset,limit});}
    catch(e){if(!state.mode&&[400,404,405,422].includes(e.status)){
      log("documents.search_titles indisponibil, încerc documents.search.","AVERTISMENT");op="documents.search";res=await outlineCall(op,{query:state.searchQuery,offset,limit});
    }else throw e;}
    state.mode=op;const found=KBLinkCore.unwrapResults(res),seen=new Set(state.results.map(x=>x.id));
    for(const doc of found)if(!seen.has(doc.id)){seen.add(doc.id);state.results.push(doc);}
    state.results.sort((a,b)=>KBLinkCore.similarity(state.page?.title||state.searchQuery,b.title)-KBLinkCore.similarity(state.page?.title||state.searchQuery,a.title)||a.title.localeCompare(b.title,"ro"));
    state.nextOffset=offset+found.length;
    const total=Number(res.pagination?.total??res.data?.pagination?.total);
    state.more=Number.isFinite(total)?state.nextOffset<total:found.length===limit;
    $("searchInfo").textContent=state.results.length+" rezultate · "+op+(state.more?" · Mai există rezultate":" · Sfârșitul listei");
    renderResults();
    notice(state.results.length?"Selectează un rezultat Outline și verifică-l. Butonul de marcare se activează după confirmare.":"Niciun rezultat pentru acest titlu. Poți modifica termenul de căutare.");
    log("Căutare Outline «"+query+"»: "+found.length+" rezultate prin "+op+" (offset "+offset+").");
  }finally{state.searchBusy=false;updateActions();}
}
async function markPage(){
  if(state.busy)return;
  if(markBlockReason()!=="Pregătit: poți marca pagina KB cu [M].")throw Error(markBlockReason());
  const chosen=selectedDoc();const targetTabId=state.sourceTabId,original=state.kb,loaded=state.page;
  state.busy=true;updateActions();
  try{
    const info=await outlineCall("documents.info",{id:chosen.id});
    const doc=info.data?.document??info.data??info.document??info;
    if(String(doc?.id||"")!==chosen.id)throw Error("Identificatorul Outline nu corespunde celui selectat.");
    if(String(doc.title||"")!==chosen.title)throw Error("Documentul Outline a fost redenumit. Reia căutarea.");
    const outlineUrl=KBLinkCore.linkFor(doc,state.base);
    const visible=await KBBridge.detect(targetTabId);
    if(visible.pageId!==original.pageId||visible.baseUrl!==original.baseUrl)
      throw Error("Fila KB a fost navigată către altă pagină. Apasă «Reîncarcă din KB». ");
    const current=await KBBridge.getPage(targetTabId,original.baseUrl,original.pageId);
    const nowProperty=await KBBridge.getProperty(targetTabId,original.baseUrl,original.pageId);
    const currentState=KBLinkCore.statusDetail(current,nowProperty?.value||null);
    if(currentState.blocked)throw Error("Starea KB s-a schimbat: "+currentState.reason);
    if(currentState.override&&!$("allowOverride").checked)throw Error("Există registru/antet incomplet. Confirmă explicit corectarea lui.");
    if(current.version?.number!==loaded.version?.number||current.title!==loaded.title||current.body?.storage?.value!==loaded.body?.storage?.value)
      throw Error("Pagina KB a fost modificată de altcineva între timp. Apasă «Reîncarcă din KB». ");
    const username=state.user.displayName||state.user.username,stamp=new Date(),iso=KBLinkCore.day(stamp);
    const prev=nowProperty?.value||null;
    const oldDetail=currentState.override?"\nATENȚIE: registrul vechi ("+(currentState.registry||"absent")+") va fi corectat."+(prev?.outlineUrl?"\nLink vechi: "+prev.outlineUrl:""):"";
    const msg="Pagina KB: "+current.title+"\npageId: "+original.pageId+"\nOutline: "+doc.title+"\n"+outlineUrl+"\nResponsabil: "+username+"\nData: "+iso+oldDetail+"\n\nConfirmi marcarea [M] în KB?";
    if(!window.confirm(msg)){log("Utilizatorul a anulat marcarea [M].");return;}
    const oldBody=String(current.body?.storage?.value||""),stripped=KBLinkCore.stripExistingBlock(oldBody);
    if(currentState.headerStatus&&stripped===oldBody)throw Error("Există deja un antet de migrare/excludere în KB într-un format necunoscut. Pentru siguranță, nu adaug un antet dublu; verifică pagina manual.");
    const newBody=KBLinkCore.markBlock(username,iso,outlineUrl)+stripped;
    const newTitle="[M] "+KBLinkCore.cleanTitle(current.title);
    log("Actualizez KB pageId="+original.pageId+" versiunea="+(current.version.number+1)+"; Outline ID="+doc.id);
    await KBBridge.updatePage(targetTabId,original.baseUrl,original.pageId,newTitle,newBody,current.version.number);
    const recheck=await KBBridge.getPage(targetTabId,original.baseUrl,original.pageId);
    if(recheck.title!==newTitle)throw Error("Pagina KB a fost actualizată, dar prefixul [M] nu este confirmat prin API. Verifică istoricul.");
    const when=new Date().toISOString();
    const newRecord={status:"M",kbPageId:String(original.pageId),outlineId:doc.id,outlineUrl,
      migratedBy:state.user.username,migratedAt:when,validatedAt:when,method:"manual-association"};
    let warning="";
    try{await KBBridge.setProperty(targetTabId,original.baseUrl,original.pageId,newRecord);}
    catch(e){warning="Content Property outline-migrator nu s-a putut salva: "+e.message;log(warning,"AVERTISMENT");}
    state.page=recheck;state.property=warning?nowProperty:{value:newRecord};state.readVersion=recheck.version.number;
    $("kbTitle").textContent=recheck.title;$("reviewed").checked=false;$("allowOverride").checked=false;updateActions();
    notice("Pagina KB a fost marcată [M].\nLink Outline: "+outlineUrl+(warning?"\nAVERTISMENT: "+warning:""),warning?"error":"ok");
    log("[M] confirmat în KB pageId="+original.pageId+"; Outline document "+doc.id);
    try{await chrome.tabs.reload(targetTabId);}catch(e){log("Reîncărcarea vizuală a tabului KB nu a reușit: "+e.message,"AVERTISMENT");}
  }finally{state.busy=false;updateActions();}
}
function handle(fn){return async()=>{try{await fn();}catch(e){const msg=String(e?.message||e);notice(msg,"error");log(msg,"EROARE");updateActions();}};}

for(const tab of document.querySelectorAll(".navtab[data-panel]"))tab.addEventListener("click",()=>showPanel(tab.dataset.panel));
$("openSettings").addEventListener("click",()=>showPanel("settings"));
$("returnAssociate").addEventListener("click",()=>showPanel("associate"));
$("scanTabs").addEventListener("click",handle(async()=>{await scanKbTabs();notice("Lista filelor KB a fost actualizată.","ok");}));
$("refresh").addEventListener("click",handle(refreshFromKb));
$("grantKb").addEventListener("click",handle(async()=>{
  // Permission request in direct user action: no await before prompt.
  const manual=$("kbTabSelect").value.startsWith("tab:");
  const tab=(!manual&&state.pendingPermissionTabId?state.tabs.find(t=>t.id===state.pendingPermissionTabId):null)||chooseKbTab();
  clearKbState();
  await requestKbPermission(tab);
  await loadKb(tab);
}));
$("kbTabSelect").addEventListener("change",()=>{state.pendingPermissionTabId=0;clearKbState();notice("Fila sursă a fost schimbată. Apasă «Reîncarcă din KB» pentru a confirma pageId-ul înainte de marcare.");});
$("connect").addEventListener("click",handle(connect));
$("search").addEventListener("click",handle(()=>runSearch(false)));
$("more").addEventListener("click",handle(()=>runSearch(true)));
$("mark").addEventListener("click",handle(markPage));
$("reviewed").addEventListener("change",updateActions);
$("allowOverride").addEventListener("change",updateActions);
$("query").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();$("search").click();}});
$("outlineBase").addEventListener("input",()=>{state.connectionOk=false;updateActions();});
$("outlineToken").addEventListener("input",()=>{state.connectionOk=false;updateActions();});
$("copyLog").addEventListener("click",handle(async()=>{await navigator.clipboard.writeText(state.logs.join("\n"));notice("Jurnal copiat (fără tokenuri).","ok");}));
$("clearLog").addEventListener("click",()=>{state.logs=[];$("log").textContent="";$("logCount").textContent="0";notice("Jurnal curățat.");});
chrome.runtime.onMessage.addListener(message=>{
  if(message?.type==="KB_TAB_CHANGED"){
    state.preferClickedOnce=true;
    log("Pagina KB din care ai apăsat pictograma extensiei s-a schimbat. Apasă «Reîncarcă din KB».");
    notice("Ai activat extensia din altă filă KB. Apasă «Reîncarcă din KB» pentru actualizare.");
  }
});
handle(async()=>{
  await restoreConfig();
  const tabs=await scanKbTabs();
  const target=chooseKbTab();
  state.preferClickedOnce=false;
  if(target){
    try{await loadKb(target);}catch(e){
      notice("Alege pagina KB și apasă «Permite acces KB» dacă este necesar. "+e.message);
      log("Încărcare automată KB indisponibilă: "+e.message,"AVERTISMENT");
    }
  } else notice("Deschide pagina KB în Chrome (pe oricare monitor), apoi apasă «Reîncarcă din KB». ");
  updateActions();
})();
