# KB → Outline Migrator v0.4.4

Extensie Chrome locală pentru Confluence 6.11.2 → Outline, independentă de VM-DOC.

## Instalare

1. Dezarhivează ZIP-ul într-un director permanent.
2. Deschide `chrome://extensions`, activează **Developer mode**, alege **Load unpacked** și selectează directorul `KB-Outline-Migrator` care conține `manifest.json`.
3. Dacă actualizezi versiunea 0.4.0, suprascrie fișierele extensiei, apoi apasă **Reload** în `chrome://extensions`.
4. Deschide pagina Confluence autentificată, apoi pictograma extensiei.
5. La **Configurări**, setează domeniul Outline și tokenul personal și folosește **Testează Outline**.

## Migrare nouă

- Dacă linkul Outline este un document-părinte, bifează **Părinte** și apasă **Migrează în Outline**.
- Dacă nu este părinte, debifează **Părinte**: pentru paginile nemigrate se actualizează documentul indicat, după confirmare.
- **Am verificat informațiile** rămâne o confirmare obligatorie; detecția de posibile credențiale este doar informativă după confirmare.
- Pagini `[M]` / `[X]` nu pot fi migrate sau excluse din nou.

## Actualizarea unei pagini deja `[M]`

1. Intră în pagina originală KB `[M]`.
2. Extensia încarcă automat asocierea existentă, dacă există Content Property în Confluence.
3. În tabul **Migrare**, introdu URL-ul **documentului existent** din Outline, nu pe cel al părintelui.
4. Debifează **Părinte** și selectează modul **Înlocuiește** (implicit) sau **Adaugă la sfârșit**.
5. Bifează **Am verificat informațiile** și apasă **Actualizează în Outline**.
6. Confirmă documentul și verifică noul conținut în Outline.

Acest flux NU creează document nou, NU aplică din nou `[M]` în KB și refuză alt `documentId` decât cel deja asociat. Dacă registrul lipsește, verifică backlinkul original către `pageId` înainte de actualizare. Modul **Adaugă la sfârșit** adaugă conținutul complet, deci poate duplica textul; pentru sincronizare normală folosește **Înlocuiește**.

## Numele originale ale fișierelor în Outline (v0.4.2)

- La încărcare se transmite către Outline **numele original din Confluence** prin `attachments.create(name=...)` și prin multipart.
- Documentul folosește **URL-ul canonic stabil** `/api/attachments.redirect?id=...`, dacă Outline returnează ID-ul atașamentului, nu linkul brut `/api/files.get?sig=...`.
- Linkurile către fișiere sunt scrise în formatul nativ Outline **`[nume sau text vizibil dimensiuneInBytes](URL)`**. În cazul linkurilor din text, eticheta personalizată din KB se păstrează. Imaginile inline rămân imagini.
- Pentru o pagină **deja migrată [M]**, deschide pagina KB, introdu linkul documentului Outline, debifează **Părinte**, apoi în tabul **Legături** apasă **Corectează numele atașamentelor în Outline**. Nu se reîncarcă fișiere și nu se schimbă marcajul [M].
- Înainte de actualizarea documentului existent, sunt verificate ID-ul, confirmarea utilizatorului și eventualele modificări între timp. Linkurile `files.get` vechi sunt înlocuite cu `attachments.redirect` **doar dacă identitatea fișierului poate fi validată prin API-ul Outline**.
- Pentru linkuri vechi unde nu se poate verifica aceeași identitate, adresa este păstrată. Dimensiunile cunoscute din KB sunt folosite pentru afișarea nativă în Outline.
- **Diagnostic:** dacă, după corecție, Chrome salvează în continuare fișierul cu numele `files.get`, deschide în DevTools → Network răspunsul de descărcare și verifică `Content-Disposition`. Numele la descărcare este decis de serverul Outline/storage (și eventual reverse proxy), nu de textul Markdown. Fără acest header corect, extensia singură nu poate garanta numele fișierului descărcat.

## Pagini cu multe atașamente

- Extensia afișează acum **numele fișierului și calea KB** la fiecare încercare de descărcare; nu include query-stringuri semnate în jurnal.
- Dacă un link de download cu `?version=` returnează 404, încearcă și varianta fără parametri și adresa canonică, când sunt diferite.
- După fiecare upload reușit, salvează într-un cache **local** URL-ul stabil al fișierului, corelat cu versiunea atașamentului și serverul Outline. La o nouă încercare, îl reutilizează, fără upload repetat. URL-urile de descărcare temporare/semnate NU se salvează local.
- Bifa **„Dacă un fișier KB dă HTTP 404/410 ..., îl omit și îl raportez”** permite să omiți atât atașamentele suplimentare, cât și cele utilizate în text, **numai** pentru un răspuns HTTP 404/410 de la Confluence. Este bifată implicit, dar o poți debifa pentru control strict.
- Linkurile fișierelor omise sunt înlocuite la poziția lor în Outline cu **„Fișier neimportat (HTTP 404/410)”**, fără URL invalid; apare și o secțiune **„Fișiere indisponibile la migrare”** cu numele și pageId-ul KB. Jurnalul și popupul afișează lista, iar ultima listă este salvată în profilul Chrome și afișată la redeschiderea paginii.
- O pagină poate fi marcată `[M]` după finalizarea importului cu fișierele 404/410 omise, fiindcă omiterea a fost aprobată explicit. Marcarea nu înseamnă că fișierele respective au fost transferate; detaliile sunt în document și în raport.
- HTTP 401/403, erori de rețea/CORS, depășirea limitelor, upload 404 în Outline și alte erori neidentificate rămân **blocante**. Fișierele încărcate deja sunt reutilizate la retry.
- Dimensiunea maximă implicită pentru citirea unui fișier KB este **20 MB**. O depășire a limitei rămâne eroare și nu este omisă automat.

## Siguranță

- Tokenul Outline este individual; KB folosește sesiunea utilizatorului autentificat în Confluence.
- Reutilizarea atașamentelor deja existente este conservatoare. Dacă două URL-uri sunt posibile, extensia te întreabă pe care îl folosești; nu ghicește.
- O operație de actualizare verifică textul Outline din nou înainte de `documents.update`, ca să nu suprascrie editările simultane.
- **Nu închide popupul** până se termină. Uploadurile deja încheiate cu URL-uri stabile pot fi reluate după redeschidere.
- Cache-ul este local profilului Chrome (`chrome.storage.local`), nu sincronizat. Nu conține tokenul KB, dar conține URL-uri interne de atașamente. Poate fi șters prin ștergerea datelor extensiei.
- Înainte de actualizare, verifică dacă documentul Outline are modificări făcute direct în wiki: modul Înlocuiește le va suprascrie după confirmare.

## Test rapid pentru cele două linkuri 404

1. Actualizează v0.4.0 cu v0.4.2 și apasă Reload în `chrome://extensions`.
2. Deschide pagina KB și verifică bifa **omitere 404/410**, apoi **Am verificat**.
3. Apasă **Migrează în Outline** (sau **Actualizează în Outline**, dacă pagina este deja `[M]` și „Părinte” este debifat).
4. Verifică raportul din popup/Jurnal: trebuie să apară numele celor două fișiere, de exemplu `OpenIDConnectClient.php`.
5. În Outline, fișierele lipsă vor fi afișate ca indisponibile, iar celelalte atașamente vor fi păstrate. Dacă salvarea și marcarea `[M]` au succes, verifică și documentul rezultat.

## Limitări / de validat pe infrastructura ta

Confluence 6.11.2 și implementarea storage din Outline pot avea diferențe. Testele locale acoperă clasificarea fișierelor, recuperarea după 404 și corectitudinea țintei la update. Nu s-au executat apeluri reale pe serverele tale. Dacă un fișier returnează 404 în toate variantele, poate fi șters / inaccesibil ori conținutul său poate lipsi din storage; verifică fișierul și drepturile în Confluence.


## Noutăți v0.4.2 – formatarea documentelor

- Escape corect pentru `#`, `*`, `_` și alte caractere Markdown din textul normal Confluence. Comenzile shell recunoscute (`#tar`, `#chmod`, `#./installer`, `#./bduitool`, `#systemctl` etc.) sunt tratate ca text de cod, nu ca titluri/liste.
- Bold și italic provenite din markup XHTML sunt păstrate; blocurile de cod `code` și `noformat` păstrează liniile și indentarea.
- Listele Confluence de taskuri (`ac:task-list`) sunt transpuse ca liste bifabile în Markdown, fără clonarea marcajelor de task în text.
- Macro-urile Confluence `view-file` (PDF încorporat) sunt convertite la linkuri către atașamentul importat în Outline, în loc să afișeze eticheta `[Macro Confluence de verificat: view-file]`. Prevualizarea PDF încorporată Confluence nu poate fi reprodusă fidel prin simplu Markdown.
- Documentele `[M]` pot fi **actualizate** în Outline: deschide pagina sursă KB, introdu URL-ul **documentului existent**, debifează `Părinte`, bifează `Am verificat` și folosește butonul `Actualizează în Outline`.
- Pentru o pagină deja `[M]`, nu se modifică din nou marcajul Confluence și nu se creează o subpagină nouă.

### Atenție înainte de actualizare

Operația `Înlocuiește conținutul` rescrie textul documentului din Outline. Dacă a fost editat manual după import, salvează/confirmă conținutul înainte de actualizare. Inspectează formatarea, macro-urile convertite, imaginile, linkurile și documentele PDF după test.

Păstrează această versiune drept pilot până când verificăm rezultatul pe instanța ta de Outline.

## Actualizare v0.4.3 – marcaje `**` izolate

- Convertorul nu mai generează delimitatori Markdown `**`/`*` pentru elemente bold/italic fără text.
- În cazul unui `<strong>` care conține mai multe paragrafe, aplică bold pe liniile cu text, nu pe linii goale.
- Elimină marcajele orfane `**` / `*` din afara blocurilor de cod. Codul și caracterele literale escapate rămân nemodificate.
- Pentru o pagină deja migrată în Outline: deschide pagina KB, introdu linkul documentului EXISTENT, lasă Părinte debifat, verifică informațiile, apoi Actualizează în Outline. **Actualizarea înlocuiește conținutul existent**; nu o executa dacă există modificări manuale pe care vrei să le păstrezi.
- Corecția nu șterge automat `**` din paginile Outline existente: se aplică numai la o conversie/migrare/actualizare făcută cu noua versiune.

## v0.4.4 – păstrarea liniilor din cod (Upgrade nginx)

- Comenzile din Confluence `<code>` separate prin `<br/>` sau în mai multe elemente `<code>` dintr-un singur paragraf se transformă într-un bloc Markdown multiline, nu într-o singură linie lipită.
- `<pre>` păstrează newline-urile și liniile libere; macro-urile `code`/`noformat` rămân compatibile; codul inline de un singur rând rămâne inline. Nu presupunem că toate blocurile sunt Bash (evităm colorarea arbitrară SQL/JSON).
- Se evită alterarea liniei din cod chiar dacă ea conține delimitatori Markdown sau backtickuri literale.
- Testat local pe exemple de structură XHTML echivalente cu cea din capturile „Upgrade nginx”; testul real pe serverele KB/Outline rămâne de făcut.
- **Pentru a corecta un document deja `[M]`**, deschide pagina KB, introdu URL-ul documentului EXISTENT în Outline, debifează Părinte, confirmă și apasă „Actualizează în Outline”. Nu crea o pagină nouă. Operația înlocuiește conținutul existent; salvează modificările manuale înainte.
