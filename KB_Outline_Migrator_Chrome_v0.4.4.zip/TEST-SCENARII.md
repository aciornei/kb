# Teste pilot – KB → Outline Migrator 0.4.2

1. **Pagină KB nouă fără fișiere:** Creează document copil; verifică `[M]` în KB după confirmare.
2. **Pagină `[M]` actualizată:** Intră pe pagina KB, confirmă URL-ul Outline, debifează Părinte, alege Înlocuiește și apasă Actualizează. Verifică: același ID Outline, conținut nou, titlu KB `[M]` neschimbat.
3. **Document Outline greșit:** Încearcă alt ID de document la update; trebuie refuzat înainte de orice modificare.
4. **19 atașamente, două HTTP 404:** Cu bifa de omiterea 404/410 activă, operația continuă; PDF-urile/fișierele valide se transferă, iar cele două omise apar în raport și în Outline, fără linkuri invalide. Reîncercarea reutilizează uploadurile reușite.
5. **Fișier opțional 404:** Cu bifa activă, fișierul este omis și raportat.
6. **Fișier referit în text 404:** Cu bifa activă, textul linkului rămâne vizibil cu mențiunea „neimportat”, fără URL invalid; cu bifa inactivă, operația se oprește.
7. **Outline 404 la upload / KB 401/403:** Nu trebuie omise; operația se oprește.
8. **Două fișiere cu același titlu:** La update, dacă nu poate determina URL-ul corect, cere selecție manuală în loc să ghicească.
9. **Conținut modificat simultan:** Dacă Outline s-a modificat după citire, extensia refuză suprascrierea.
10. **Tab, popup, sesiune:** Extensia trebuie să preia pagina Confluence activă și să nu ceară credențialele KB separat.

Pentru depanare folosește tabul Jurnal și include **numele fișierului, codul HTTP și calea fără query-string**; nu trimite tokenuri sau URL-uri semnate.

## Teste suplimentare – numele fișierelor

11. Migrează un PDF și verifică Markdown-ul nativ `[nume.pdf dimensiune](https://wiki.../api/attachments.redirect?id=...)` și numele afișat.
12. Un link custom „Kerberos auth” trebuie să păstreze textul, fără să fie redenumit `files.get`.
13. Un document deja `[M]`: butonul **Corectează numele atașamentelor în Outline**, fără upload, fără modificări în Confluence.
14. Dacă un link `files.get?sig=...` nu poate fi corelat/verificat, nu îl rescrie automat.
15. După descărcare, verifică `Content-Disposition` dacă browserul salvează în continuare `files.get`.
16. Imaginile inline, linkurile externe și blocurile de cod rămân intacte.

## Regresii formatare v0.4.2

17. `#tar -xvf`, `#chmod +x installer`, `#./installer`, `#./bduitool` din paragrafe Confluence nu devin titluri Markdown.
18. Textul cu `_`, `*`, `[` și `#` apare literal; textul de comandă nu schimbă mărimea fontului.
19. Bold/italic XHTML se păstrează; textul care conține literalmente `**` nu își schimbă intenționat semnificația.
20. Macro `view-file` cu PDF inserat devine link către PDF migrat; nu mai apare mesajul generic `Macro ... view-file`.
21. `ac:task-list` devine `- [x]` / `- [ ]`, pe linii separate.
22. Un `<li>` cu macro `code` își păstrează blocul de cod, cu spațiul și indentarea cerute în Markdown.
23. Actualizare document deja `[M]` cu Părinte debifat: același document Outline, fără dublarea fișierelor, fără rescriere a marcajului KB.
24. Verifică vizual exemplul „Antivirus BitDefender”: comenzi shell, text evidențiat, macro PDF, listă și anexe.

## v0.4.3 – marcaje Markdown orfane

1. `<p><strong><br /></strong></p>` nu produce o linie `**` în Outline.
2. `<strong><p>Primul paragraf</p><p>Al doilea</p></strong>` se convertește în două paragrafe bold, nu în `**` izolate.
3. `<p><strong>Text</strong> și <em>italic</em></p>` se păstrează formatat.
4. Într-un macro `code` Confluence, liniile cu `**` sau `#` rămân identice.
5. Paginile deja `[M]` trebuie actualizate explicit pe documentul existent; nu se modifică automat.

## v0.4.4 – regresii cod multiline

1. `<p><code>ls -l ...<br/>grep -R ...<br/>grep -R ...</code></p>` are 3 comenzi separate în Markdown.
2. `<p><code>ls ...</code><br/><code>grep ...</code></p>` are 2 comenzi separate.
3. `<pre><code>prima\na doua\n\na patra</code></pre>` păstrează linia liberă.
4. `<p>Folosește <code>nginx -t</code> înainte</p>` rămâne cod inline.
5. Macro `code` Confluence și cod cu backtickuri literale nu se corup.
6. Actualizează documentul `[M]` „Upgrade nginx” cu Părinte debifat, verifică fiecare linie `ls`/`grep` în Outline și faptul că documentul nu se dublează.
