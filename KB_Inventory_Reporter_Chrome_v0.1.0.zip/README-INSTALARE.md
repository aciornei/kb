# KB Inventory & Migration Report — Chrome v0.1.0

## Scop
Extensie Chrome SEPARATĂ de KB → Outline Migrator. Exportă **TOATE paginile accesibile** dintr-un Space Confluence 6.11.2 într-un fișier `.xlsx`, organizate ierarhic.

- `[M]`: migrată (citește responsabilul, data, linkul Outline din **primele paragrafe** din KB).
- `[X]`: exclusă (citește responsabilul, data și motivul).
- Fără prefix: neevaluată, dar inclusă în raport.
- Metadate lipsă, conflict de prefix/status sau eșec la citire: păstrate și semnalate în „Verificări”.

## Instalare
1. Extrage arhiva într-un director permanent.
2. Chrome → `chrome://extensions` → activează **Developer mode** → **Load unpacked**.
3. Selectează folderul `KB-Inventory-Reporter`, unde se află `manifest.json`.
4. Deschide o pagină Confluence KB și autentifică-te cu contul tău.
5. Apasă pictograma extensiei și **Deschide inventarul**.
6. În noua filă de raport, selectează `Space key` și `Toate paginile din Space` (implicit) sau doar subarborele paginii curente.
7. Apasă **Scanează toate paginile**, apoi **Descarcă Excel (.xlsx)**.

## Excel
- **Sumar**: indicatori M/X/neevaluat/neconcordanțe, domeniu, data raportului.
- **Arbore KB**: ierarhia, cu ramuri repliabile `+/-`, legături către KB și Outline, responsabil, dată și motiv.
- **Verificări**: pagini cu informații incomplete sau în conflict.

## Cum funcționează autentificarea
Extensia folosește exclusiv **sesiunea Confluence deja activă** în fila KB pentru autorizarea apelurilor REST. Nu cere parole sau tokenuri. **Nu folosește istoricul local al migratorului sau date stocate în Chrome**. Statusurile sunt citite direct din titlul și primele paragrafe ale fiecărei pagini Confluence, la fiecare export.

Nu este nevoie să deschizi fiecare pagină KB într-o filă: extensia le accesează prin REST API, cu sesiunea existentă. Fila KB trebuie să rămână deschisă până la finalizarea scanării; fila cu raportul trebuie să rămână și ea deschisă. Se poate deschide o singură filă de raport, nu sute de taburi KB.

**Limitare importantă:** utilizatorul vede doar paginile pe care are drept de `view` în Confluence. Paginile inaccesibile prin restricții nu pot fi inventariate de acel utilizator; folosește un cont cu drepturile necesare pentru raportarea întregului Space.

## Date sursă
Migratorul existent v0.4.3 scrie un macro Status și apoi în primele paragrafe:
- `KB → Outline | Responsabil: ... | Data: YYYY-MM-DD`
- `Destinație Outline: URL` sau `Motiv: text`

Raportul citește aceste date de pe server, nu data ultimei modificări. Dacă cineva a marcat manual `[M]` sau `[X]` fără a pune blocul standard, raportul păstrează statusul, dar arată metadatele lipsă.

## Confidențialitate și tehnic
- **Doar operații GET**, fără modificări în Confluence sau Outline.
- Nu salvează cookie-uri, parole, tokenuri, corpuri de pagini sau rapoarte în storage-ul extensiei.
- Excelul este generat local, fără servicii externe/CDN.
- Apelurile de citire sunt efectuate pe originul Confluence, cu sesiunea autenticată a filei KB.
- Rapoartele au hyperlinkuri reale; textul din pagini nu este transformat în formule Excel (protecție contra formula injection).
- Paginile din trash/draft și cele la care utilizatorul nu are drept de citire nu sunt incluse.
