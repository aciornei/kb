'use strict';
const msg=document.querySelector('#message');
document.querySelector('#open').addEventListener('click', async()=>{
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id || !/^https?:/.test(tab.url||''))throw new Error('Deschide o pagină Confluence KB înainte de raportare.');
    // activeTab grants access to this Confluence tab when the action is opened.
    await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>document.title});
    await chrome.tabs.create({url:chrome.runtime.getURL('report.html')+'?sourceTab='+encodeURIComponent(tab.id)});
    window.close();
  }catch(e){msg.textContent='Eroare: '+(e.message||e);}
});
