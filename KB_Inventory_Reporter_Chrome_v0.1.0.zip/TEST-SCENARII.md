# Teste recomandate — KB Inventory v0.1.0

1. **Titluri fără prefix**: o pagină fără `[M]`/`[X]` apare obligatoriu ca `NEEVALUATĂ`.
2. **Pagini `[M]`**: apar cu responsabil, dată și link Outline preluate din primele paragrafe Confluence.
3. **Pagini `[X]`**: apar cu responsabil, dată și motivul excluderii.
4. **Metadate lipsă**: pagina rămâne în arbore, în `Verificări` apare problema.
5. **Ierarhie**: subpaginile sunt sub părinte și se pot restrânge în Excel cu `+/-`.
6. **Întreg Space**: raportul nu filtrează paginile după prefix; totalul se compară cu pagina Space din KB.
7. **Subarbore**: exportă doar pagina curentă și subpaginile, fără frați.
8. **Restricții KB**: o pagină interzisă contului nu poate fi exportată; se verifică cu utilizator cu drepturi corespunzătoare.
9. **Pagina modificată manual**: `[M]` sau `[X]` fără banner rămâne inclusă, metadatele lipsă se semnalează.
10. **Actualizare stare**: dacă un coleg migrează o pagină pe alt computer, la un nou export starea sa se schimbă fără să reinstalezi extensia (datele sunt citite de pe server).
11. **Securitate**: exportul nu modifică Confluence; linkurile nu devin formule Excel; nu se salvează tokenuri sau cookie-uri.
12. **Paginare**: Space cu peste 100 de pagini; verifică absența paginilor omise sau duplicate.
