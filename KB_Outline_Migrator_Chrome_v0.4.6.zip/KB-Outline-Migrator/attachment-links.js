"use strict";
// Outline's native file-card Markdown format is: [visible title sizeInBytes](url).
// Keep displayed labels from Confluence; never infer a file name from files.get.
const KBFileLinks = (() => {
  function safeBase(base) { return new URL(String(base).replace(/\/$/,"")+"/"); }
  function parsedUrl(value,base) {
    try {return new URL(value,safeBase(base));} catch (_) {return null;}
  }
  function isFileLink(raw,base) {
    const u=parsedUrl(raw,base),b=safeBase(base);
    return !!(u && u.origin===b.origin && /\/api\/(?:attachments\.redirect|files\.get)\/?$/i.test(u.pathname));
  }
  function attachmentId(up) {
    const uuid=/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    const id=String(up?.attachment?.id||"");
    if(uuid.test(id))return id;
    const href=up?.attachment?.url||up?.attachment?.downloadUrl||"";
    try{const i=new URL(href,"https://outline.invalid").searchParams.get("id");return uuid.test(i||"")?i:null;}catch(_){return null;}
  }
  function canonicalUploadedUrl(up,base) {
    const id=attachmentId(up);
    if(id) return {url:new URL("api/attachments.redirect?id="+encodeURIComponent(id),safeBase(base)).href,id};
    const raw=up?.attachment?.url||up?.attachment?.downloadUrl;
    if(!raw)throw new Error("Outline nu a returnat un URL pentru atașament.");
    return {url:new URL(raw,safeBase(base)).href,id:null};
  }
  function norm(s){return String(s||"").normalize("NFC").trim().toLocaleLowerCase();}
  function cleanLabel(label){return String(label||"").replace(/\\([\\\[\]])/g,"$1").replace(/\s+\d+$/," ").trim();}
  function format(text,{base,sizeByUrl=new Map(),sizesByFilename=new Map()}={}) {
    const lines=String(text||"").split("\n");let fenced=false,changed=0;
    const result=lines.map(line=>{
      if(/^\s{0,3}(?:`{3,}|~{3,})/.test(line)){fenced=!fenced;return line;}
      if(fenced)return line;
      return line.replace(/(?<!!)\[((?:\\.|[^\]\\\n])*)\]\(([^)\n]+)\)/g,(whole,label,rawUrl)=>{
        if(!isFileLink(rawUrl,base))return whole;
        const parsed=parsedUrl(rawUrl,base);
        const key=parsed.href;
        let bytes=Number(sizeByUrl.get(key));
        const visible=cleanLabel(label);
        if(!Number.isFinite(bytes)||bytes<0){bytes=Number(sizesByFilename.get(norm(visible)));}
        if(!Number.isSafeInteger(bytes)||bytes<0)return whole;
        // Outline detects the file attachment by the numeric suffix. Avoid
        // accumulating file sizes across repeated updates.
        const oldMatch=String(label).match(/\s+(\d+)$/);
        // Do not mistake a legitimate title ending in a year or number
        // (e.g. "Keycloak 2026") for an Outline size suffix.
        const escapedLabel=oldMatch&&Number(oldMatch[1])===bytes?label.slice(0,oldMatch.index):label;
        const updated=`[${escapedLabel} ${bytes}](${rawUrl})`;
        if(updated!==whole)changed++;
        return updated;
      });
    });
    return {text:result.join("\n"),changed};
  }
  function sourceSizes(attachments){
    const result=new Map();
    for(const a of attachments||[]){
      const size=Number(a.extensions?.fileSize);
      if(Number.isSafeInteger(size)&&size>=0)result.set(norm(a.title),size);
    }
    return result;
  }
  // An older Outline installation may put a signed /api/files.get URL in
  // the document. Its JWT is decoded only to find a *candidate* id, which
  // MUST subsequently be verified with the Outline API before rewriting.
  function signedUrlCandidate(raw,base){
    const u=parsedUrl(raw,base),b=safeBase(base);
    if(!u||u.origin!==b.origin||!/\/api\/files\.get\/?$/i.test(u.pathname))return null;
    const sig=u.searchParams.get("sig");if(!sig)return null;
    try{
      const part=sig.split(".")[1];if(!part)return null;
      const safe=part.replace(/-/g,"+").replace(/_/g,"/");
      const json=JSON.parse(atob(safe+"=".repeat((4-safe.length%4)%4)));
      const key=String(json.key||"");
      const m=key.match(/^uploads\/[^/]+\/([0-9a-f-]{36})\/([^/]+)$/i);
      if(!m||!(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i).test(m[1]))return null;
      return {id:m[1],key};
    }catch(_){return null;}
  }
  function rewriteLegacyUrls(text,base,byUrl){
    let count=0,fenced=false;
    const lines=String(text||"").split("\n").map(line=>{
      if(/^\s{0,3}(?:`{3,}|~{3,})/.test(line)){fenced=!fenced;return line;}
      if(fenced)return line;
      return line.replace(/(?<!!)\[((?:\\.|[^\]\\\n])*)\]\(([^)\n]+)\)/g,(full,label,url)=>{
        const target=byUrl.get(url);
        if(!target)return full;
        count++;
        return `[${label}](${target})`;
      });
    });
    return {text:lines.join("\n"),count};
  }
  return {isFileLink,canonicalUploadedUrl,attachmentId,format,sourceSizes,signedUrlCandidate,rewriteLegacyUrls};
})();
