"use strict";
// Recovery-only logic: reuse the URLs of files already uploaded to Outline.
// Never upload, guess a missing URL, or rewrite a source attachment.
const KBMediaRepair = (() => {
  function norm(s){return String(s||"").normalize("NFC").trim().toLocaleLowerCase();}
  function unescapeLabel(s){return String(s||"").replace(/\\([\\\[\]])/g,"$1");}
  function safeUrl(raw){
    try{const u=new URL(raw);return ["http:","https:"].includes(u.protocol)?u:null;}catch(_){return null;}
  }
  function isNavigation(url,kbBase,outlineBase){
    const u=safeUrl(url);if(!u)return true;
    try{
      const kb=new URL(kbBase),ol=new URL(outlineBase);
      const kbCtx=kb.pathname.replace(/\/$/,"");
      // KB links to *pages* are not files, and must not be mistaken for media.
      if(u.origin===kb.origin && (u.pathname.startsWith(kbCtx+"/display/") ||
         u.pathname.startsWith(kbCtx+"/download/attachments/") ||
         u.pathname===kbCtx+"/pages/viewpage.action" ||u.pathname===kbCtx+"/viewpage.action"))return true;
      // Outline document links are not attachments either.
      if(u.origin===ol.origin && /\/(?:doc|d|collection)\//i.test(u.pathname))return true;
    }catch(_){}
    return false;
  }
  function originalLinks(text,kbBase,outlineBase){
    const result=[];
    const pattern=/(!?)\[([^\]\n]*(?:\\.[^\]\n]*)*)\]\((https?:\/\/[^)\n]+)\)/g;
    let m;
    while((m=pattern.exec(text))){
      if(!isNavigation(m[3],kbBase,outlineBase))
        result.push({image:!!m[1],label:norm(unescapeLabel(m[2]).replace(/\s+\d+$/,"")),url:m[3]});
    }
    const image=/<img\b[^>]*>/gi;
    while((m=image.exec(text))){
      const src=m[0].match(/\bsrc=["']([^"']+)["']/i)?.[1];
      const alt=m[0].match(/\balt=["']([^"']+)["']/i)?.[1];
      if(src&&alt&&!isNavigation(src,kbBase,outlineBase))
        result.push({image:true,label:norm(alt),url:src});
    }
    return result;
  }
  function fileNameForToken(token,preview){
    const local=String(token||"").match(/^\[UPLOAD:(.*)\]$/);
    if(local)return local[1];
    for(const item of preview.remoteUploads?.values?.()||[]){if(item.marker===token)return item.title;}
    return "";
  }
  function isFilenameInUrl(url,filename){
    if(!filename)return false;
    const u=safeUrl(url);if(!u)return false;
    let pathname=u.pathname;
    try{pathname=decodeURIComponent(pathname);}catch(_){}
    return pathname.toLocaleLowerCase().includes(filename.toLocaleLowerCase());
  }
  function displayUrl(url){
    const u=safeUrl(url);
    if(!u)return "Adresă invalidă";
    // Never expose pre-signed query strings or userinfo in the popup.
    let p=u.pathname;try{p=decodeURIComponent(p);}catch(_){}
    const attachmentId=u.searchParams.get("id")||u.searchParams.get("attachmentId");
    const suffix=attachmentId&&/^[a-zA-Z0-9_-]{1,100}$/.test(attachmentId)
      ?" · id="+(attachmentId.length>30?attachmentId.slice(0,14)+"…"+attachmentId.slice(-10):attachmentId):"";
    return u.hostname+(p.length>98?"/…"+p.slice(-92):p)+suffix;
  }
  function build(preview,existing,{kbBase,outlineBase,choices,allowMissing=false}={}){
    const original=String(existing||"");
    const candidates=originalLinks(original,kbBase||"",outlineBase||"");
    const missing=[],missingEntries=[],ambiguities=[],used=[];
    const occurrences=new Map();
    function find(label,image,sourceName,marker){
      const lookup=norm(label),group=`${image?"img":"file"}:${lookup}`;
      const occurrence=occurrences.get(group)||0;occurrences.set(group,occurrence+1);
      const key=group+":"+occurrence;
      const sameType=candidates.filter(c=>c.image===image);
      const possible=[...new Set(sameType.filter(c=>c.label===lookup).map(c=>c.url))];
      // The migrated document may have an INCORRECT link label (the bug being
      // repaired). Do not require that bad label to recover its attachment URL.
      // Prefer an exact filename in the existing URL; otherwise, show ALL
      // file URLs of the same type for explicit user selection.
      const allUrls=[...new Set(sameType.map(c=>c.url))];
      const fileMatches=sourceName?allUrls.filter(url=>isFilenameInUrl(url,sourceName)):[];
      // During an UPDATE do not silently select an unrelated attachment merely
      // because it is the only file in the previous document. A new filename
      // without an exact match must be uploaded, or explicitly mapped.
      const urls=fileMatches.length===1?fileMatches:possible.length?possible:(allowMissing?[]:allUrls);
      let selected=urls.length===1?urls[0]:null;
      const fromUser=choices?.get?.(key);
      if(!selected && fromUser && urls.includes(fromUser))selected=fromUser;
      if(!selected){
        if(!urls.length){missing.push(`${label} (nu există fișier încărcat în Outline)`);missingEntries.push({key,label,image,filename:sourceName,marker});}
        else ambiguities.push({key,label,image,filename:sourceName,options:urls.map(url=>({url,display:(sameType.find(c=>c.url===url)?.label||'Fișier')+' · '+displayUrl(url)}))});
        return null;
      }
      used.push({key,label,url:selected});
      return selected;
    }
    let result=preview.text;
    const pending=/(!?)\[([^\]\n]*(?:\\.[^\]\n]*)*)\]\((\[UPLOAD:[^\]\n]+\]|KBMIGR_REMOTE_FILE_\d+_END)\)/g;
    result=result.replace(pending,(whole,im,label,marker)=>{
      const url=find(unescapeLabel(label),!!im,fileNameForToken(marker,preview),marker);
      return url?`${im}[${label}](${url})`:whole;
    });
    // Experimental HTML-width mode.
    result=result.replace(/<img\b[^>]*>/gi,whole=>{
      if(!/\[UPLOAD:|KBMIGR_REMOTE_FILE_/.test(whole))return whole;
      const alt=whole.match(/\balt=["']([^"']+)["']/i)?.[1]||"";
      const marker=whole.match(/\bsrc=["']([^"']+)["']/i)?.[1]||"";
      const url=find(alt,true,fileNameForToken(marker,preview),marker);
      return url?whole.replace(/\bsrc=["'][^"']+["']/i,'src="'+url.replace(/"/g,"&quot;")+'"'):whole;
    });
    // Never update Outline when a referenced asset cannot be identified.
    if(missing.length&&!allowMissing)throw new Error("Nu pot identifica toate fișierele existente în Outline: "+[...new Set(missing)].join(", ")+". Documentul nu a fost modificat.");
    if(ambiguities.length)return {text:null,reused:used.length,ambiguities,missing:missingEntries};
    if(!allowMissing && /\[UPLOAD:|KBMIGR_REMOTE_FILE_\d+_END/.test(result))
      throw new Error("Au rămas referințe de fișiere nerezolvate. Documentul nu a fost modificat.");
    return {text:result,reused:used.length,ambiguities:[],missing:missingEntries};
  }
  return {build,displayUrl,originalLinks};
})();
