# Proceduri operaționale — Keycloak / Active Directory / Kerberos

| Metadate | Valoare |
|---|---|
| Serviciu | Keycloak — Identity & SSO |
| Secțiune ITIL propusă | 05 — Proceduri / Runbooks |
| Platformă | Keycloak 26.6.2, instalare Linux nativă, `systemd` |
| Realm administrat | `AD` |
| Integrare | Active Directory prin LDAP Federation (`READ_ONLY`) și Kerberos/SPNEGO |
| Stare | Proceduri documentate; particularitățile se validează în mediul curent |
| Revizie | 1.0 — 13.11.2026 |
| Clasificare | Intern — administrare IT |

## Scop

Acest set reunește comenzile și verificările folosite pentru administrarea Keycloak și diagnosticarea atributului `KERBEROS_PRINCIPAL`, după schimbări de nume în Active Directory.

## Proceduri

1. [P-KC-01 — Autentificare în CLI cu kcadm.sh](./01-Logare-CLI-kcadm.md)
2. [P-KC-02 — Invalidarea cache-ului utilizatorilor](./02-Stergere-cache-utilizatori.md)
3. [P-KC-03 — Verificarea și administrarea mapperului principal Kerberos](./03-Mapper-Kerberos-LDAP.md)
4. [P-KC-04 — Diferențe de capitalizare între UPN și KERBEROS_PRINCIPAL](./04-Kerberos-majuscule-minuscule.md)

## Date stabile ale mediului

- Director aplicație: `/opt/keycloak`
- CLI: `/opt/keycloak/bin/kcadm.sh`
- Realm Keycloak: `AD`
- Kerberos realm: `STS.NEST` (valoare de configurare distinctă de sufixul UPN din AD)
- Atribut LDAP pentru principal: `userPrincipalName`
- Keytab-ul și secretele nu se înscriu în documentație; acestea sunt păstrate numai în sistemele autorizate.

## Principii de operare

- Se verifică mai întâi datele din AD și Keycloak; apoi se intervine.
- Comenzile de citire sunt separate de operațiile care modifică configurația sau sincronizează utilizatori.
- Backupul VM-ului SSO **nu include baza Keycloak**, găzduită pe alt server. Înainte de modificări de configurare semnificative sau Full Sync se verifică și backupul bazei externe.
- Nu se elimină conturi și nu se modifică direct baza de date pentru simple diferențe de capitalizare.
- Linkurile dintre paginile `.md` sunt relative; după import în Outline, dacă nu sunt rezolvate, se înlocuiesc cu linkurile directe către documentele create (preferabil cu PageId).

## Referințe oficiale

- [Keycloak — Server Administration Guide (26.6)](https://www.keycloak.org/docs/26.6.4/server_admin/)
- [Keycloak — sursa mapperului în 26.6.2](https://github.com/keycloak/keycloak/blob/26.6.2/federation/ldap/src/main/java/org/keycloak/storage/ldap/mappers/KerberosPrincipalAttributeMapper.java)
- [Outline — importul documentelor Markdown](https://docs.getoutline.com/s/guide/doc/import-D2ZvLqz411)
