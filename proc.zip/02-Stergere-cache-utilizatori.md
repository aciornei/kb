# P-KC-02 — Golirea cache-ului de utilizatori în Keycloak

| Metadate | Valoare |
|---|---|
| Serviciu | Keycloak — Identity & SSO |
| Încadrare | 05 — Proceduri / Runbooks |
| Scop | Invalidarea cache-ului utilizatorilor pentru realm-ul `AD` |
| Versiune de referință | 26.6.2 |
| Revizie | 1.0 — 13.11.2026 |
| Impact | Recomandat în fereastră controlată dacă sistemul este foarte solicitat; poate crește temporar interogările LDAP / DB |

## Când se utilizează

- Datele vizibile în Keycloak diferă de valorile **corecte deja persistate** în baza de date.
- După o intervenție excepțională și controlată care a ocolit mecanismele Keycloak.
- La diagnosticarea diferențelor dintre consola de administrare, cache și baza externă.

**Limitare importantă:** invalidarea cache-ului **nu corectează** o valoare greșită din baza Keycloak și **nu forțează automat o sincronizare completă LDAP**.

## Procedură

**1. Autentificare** — conform [P-KC-01 — CLI](./01-Logare-CLI-kcadm.md):

```bash
/opt/keycloak/bin/kcadm.sh config credentials \
  --server https://sso.exemplu.ro \
  --realm master \
  --user admin
```

**2. Invalidarea cache-ului utilizatorilor din realm-ul AD**

```bash
/opt/keycloak/bin/kcadm.sh create clear-user-cache \
  -r AD \
  -s realm=AD
```

**3. Verificarea rezultatului**

- Dacă operația se încheie fără eroare, reîncărcați profilul unui utilizator afectat în Keycloak Admin Console.
- Comparați, după caz, valoarea `KERBEROS_PRINCIPAL` din interfață cu baza de date și `userPrincipalName` din AD.
- Nu este necesară repornirea serviciului `keycloak` pentru această operație.

## Comenzi înrudite — doar în cazul potrivit

```bash
# Cache-ul metadatelor de realm
/opt/keycloak/bin/kcadm.sh create clear-realm-cache -r AD -s realm=AD

# Cache-ul cheilor
/opt/keycloak/bin/kcadm.sh create clear-keys-cache -r AD -s realm=AD
```

Acestea sunt operații **distincte**, nu se execută de rutină împreună cu `clear-user-cache`.

## Diagnostic diferență persistentă în DB

Dacă atributul greșit persistă în DB, investigați sursa și mapperul conform [P-KC-03](./03-Mapper-Kerberos-LDAP.md), apoi verificați cazul conform [P-KC-04](./04-Kerberos-majuscule-minuscule.md). O invalidare de cache nu înlocuiește verificarea mapperului.

## Securitate și revenire

Comanda nu șterge utilizatori, nu modifică AD și nu rescrie permanent datele. Cache-ul va fi repopulat la cereri noi. Dacă problema persistă, nu repetați golirea cache-ului în buclă; diagnosticați sursa valorii.

## Proceduri conexe

- [P-KC-01 — CLI](./01-Logare-CLI-kcadm.md)
- [P-KC-03 — Mapper Kerberos](./03-Mapper-Kerberos-LDAP.md)
- [P-KC-04 — Litere mari/mici](./04-Kerberos-majuscule-minuscule.md)
- [Înapoi la index](./00-Index-proceduri-administrare-Keycloak.md)

## Referință

[Keycloak — Server Administration Guide, Flushing the caches](https://www.keycloak.org/docs/26.6.4/server_admin/)
