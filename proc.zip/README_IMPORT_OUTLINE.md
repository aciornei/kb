# Pachet Markdown — Proceduri Keycloak

Conține o pagină-index și patru proceduri gata de importat în Outline. Nu este un export JSON nativ Outline; linkurile între fișiere sunt relative și trebuie testate după import.

## Poziționare recomandată

**Keycloak – Identity & SSO → 05 Proceduri / Runbooks → Administrare Keycloak / Kerberos**

În directorul nou, creați mai întâi pagina `00-Index-proceduri-administrare-Keycloak.md`, apoi importați cele patru pagini. O alternativă este importul împreună, după extragerea ZIP-ului, din meniul de import Markdown permis de instanța Outline.

## Referințe între pagini

Fișierele folosesc linkuri de tipul `[P-KC-01](./01-Logare-CLI-kcadm.md)`. Dacă importul nu le convertește automat în linkuri interne, deschideți fiecare pagină și înlocuiți aceste adrese cu URL-urile interne Outline (de preferat cele cu PageId).

Paginile conțin metadate, validări, avertismente, proceduri conexe și referințe tehnice. Nu conțin secrete, chei sau parole.

## Atenționări

- Înlocuiți URL-urile, UUID-urile și DC-urile fictive înainte de execuție.
- Backupul VM-ului Keycloak nu protejează automat baza Keycloak aflată pe alt server.
- Scripturile de configurare sunt pentru Keycloak 26.6.2, realm `AD`, LDAP read-only, Kerberos realm `STS.NEST`.
- Operațiile de scriere (`create components`, Full Sync, delete) trebuie aprobate și testate.

## Surse generale

- https://www.keycloak.org/docs/26.6.4/server_admin/
- https://docs.getoutline.com/s/guide/doc/import-D2ZvLqz411
