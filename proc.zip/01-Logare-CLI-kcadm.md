# P-KC-01 — Autentificare în Command Line cu kcadm.sh

| Metadate | Valoare |
|---|---|
| Serviciu | Keycloak — Identity & SSO |
| Încadrare | 05 — Proceduri / Runbooks |
| Scop | Autentificarea administrativă și verificarea accesului la Admin REST API |
| Versiune de referință | 26.6.2 |
| Revizie | 1.0 — 13.11.2026 |
| Risc | Scăzut pentru comenzile din această pagină |

## Condiții preliminare

- Acces shell pe serverul Linux unde este instalat Keycloak în `/opt/keycloak`.
- `jq` instalat pentru afișarea JSON, dacă se folosesc exemplele filtrate.
- Cont cu permisiuni administrative pentru realm-ul `AD` (ex.: administrator din `master`).
- URL-ul public HTTPS al serverului SSO cunoscut.

## Procedură

**1. Autentificare în `master`**

```bash
/opt/keycloak/bin/kcadm.sh config credentials \
  --server https://sso.exemplu.ro \
  --realm master \
  --user admin
```

Înlocuiți `https://sso.exemplu.ro` și `admin` cu valorile reale. Parola se introduce la prompt; **nu se scrie în comandă**, fișier de shell sau în Outline.

**2. Verificarea sesiunii**

```bash
/opt/keycloak/bin/kcadm.sh get realms/AD \
  --fields realm,enabled
```

Rezultat așteptat, similar cu:

```json
{"realm":"AD","enabled":true}
```

**3. Identificarea providerului LDAP**

```bash
/opt/keycloak/bin/kcadm.sh get components -r AD \
  -q type=org.keycloak.storage.UserStorageProvider | \
  jq -r '.[] | select(.providerId == "ldap") | [.id, .name] | @tsv'
```

Păstrați ID-ul providerului pentru procedura [P-KC-03 — Mapper Kerberos](./03-Mapper-Kerberos-LDAP.md). Acesta este un UUID, diferit de numele vizibil al providerului.

## Probleme frecvente

| Mesaj | Cauză / rezolvare |
|---|---|
| `no server specified use --server or kcadm.sh config credentials` | Nu există o sesiune `kcadm` configurată pentru utilizatorul Linux curent; executați pasul 1 |
| `401 Unauthorized` | Credențiale invalide sau sesiune expirată; reautentificați-vă |
| `403 Forbidden` | Contul există, dar nu are drepturile administrative necesare |
| `jq: command not found` | Instalați `jq` sau folosiți ieșirea JSON nefiltrată |
| `No such file or directory` | Verificați calea `/opt/keycloak/bin/kcadm.sh` |

## Securitate și operare

`kcadm.sh` salvează implicit tokenurile de acces în `$HOME/.keycloak/kcadm.config`. Accesul la fișier trebuie restricționat. Evitați folosirea inutilă a `sudo` sau `root`, deoarece configurația este separată per utilizator Linux.

Comenzile `get` nu schimbă datele. Comenzile `create`, `update`, `delete` pot face schimbări și necesită aprobare operațională.

## Verificare finală

- Comanda `get realms/AD` returnează `realm=AD`.
- Comanda pentru providerii LDAP returnează unul sau mai multe ID-uri, dacă există provider LDAP configurat.

## Proceduri conexe

- [P-KC-02 — Golire cache utilizatori](./02-Stergere-cache-utilizatori.md)
- [P-KC-03 — Mapper Kerberos](./03-Mapper-Kerberos-LDAP.md)
- [Înapoi la index](./00-Index-proceduri-administrare-Keycloak.md)

## Referință

[Keycloak — Server Administration Guide, Admin CLI](https://www.keycloak.org/docs/26.6.4/server_admin/)
