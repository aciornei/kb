# P-KC-04 — Diferențe de litere mari/mici în KERBEROS_PRINCIPAL

| Metadate | Valoare |
|---|---|
| Serviciu | Keycloak — Identity & SSO |
| Încadrare | 05 — Proceduri / Runbooks |
| Scop | Separarea diferențelor de capitalizare de diferențele reale de UPN |
| Versiune de referință | 26.6.2 |
| Revizie | 1.0 — 13.11.2026 |
| Risc | Scăzut — interogări doar de citire |

## Context și concluzie operațională

În infrastructura curentă sunt întâlnite următoarele valori:

| Câmp | Exemplu |
|---|---|
| Kerberos realm în configurația Keycloak | `STS.NEST` |
| `userPrincipalName` în AD | `ion.popescu@sts.nest` |
| `KERBEROS_PRINCIPAL` în Keycloak | `ion.popescu@STS.NEST` **sau** `ion.popescu@sts.nest` |

**Simpla capitalizare a sufixului nu indică o eroare de autentificare.** Realm-ul Kerberos configurat la nivel de provider se păstrează ca `STS.NEST`; nu se schimbă în minuscule pentru a cosmetiza raportul.

În Keycloak 26.6.2 există cel puțin două căi distincte de scriere a atributului: mapperul LDAP copiază valoarea `userPrincipalName`, iar rutina de import construiește un obiect Java `KerberosPrincipal` înainte de salvare. Aceste căi pot produce reprezentări diferite. Nu presupuneți că fiecare reapariție a majusculelor reprezintă o redenumire în AD.

## Diagnostic rapid

**1. Validați AD pe DC-ul folosit de Keycloak (PowerShell):**

```powershell
Import-Module ActiveDirectory
Get-ADUser -Identity 'username' -Server 'dc01.sts.nest' -Properties userPrincipalName,displayName,sAMAccountName |
  Select-Object SamAccountName,UserPrincipalName,DisplayName |
  Format-List
```

Înlocuiți DC-ul exemplu cu serverul LDAP real. Schimbarea lui `displayName` nu presupune obligatoriu schimbarea lui `userPrincipalName`.

**2. Verificați principalul salvat în Keycloak (SQL de citire, compatibil PostgreSQL și MySQL/MariaDB):**

```sql
SELECT u.username, ua.value AS kerberos_principal
FROM user_entity u
JOIN user_attribute ua ON ua.user_id = u.id
JOIN realm r ON r.id = u.realm_id
WHERE r.name = 'AD'
  AND u.username = 'username'
  AND ua.name = 'KERBEROS_PRINCIPAL';
```

## Interogare — diferențe REALE de nume (ignoră capitalizarea)

**MySQL / MariaDB:**

```sql
SELECT
  u.username,
  ua.value AS kerberos_principal,
  CONCAT(u.username, '@sts.nest') AS principal_estimat
FROM user_entity u
JOIN user_attribute ua ON ua.user_id = u.id
JOIN realm r ON r.id = u.realm_id
WHERE r.name = 'AD'
  AND u.enabled = 1
  AND ua.name = 'KERBEROS_PRINCIPAL'
  AND LOWER(ua.value) <> LOWER(CONCAT(u.username, '@sts.nest'))
ORDER BY u.username;
```

Pentru PostgreSQL, înlocuiți `u.enabled = 1` cu `u.enabled = TRUE` (dacă coloana este boolean).

**Limitare esențială:** `username@sts.nest` este **un principal estimat**, nu neapărat UPN-ul real din AD. Rezultatele sunt candidați de verificat, nu dovadă definitivă de eroare. Dacă UPN-ul nu urmează convenția, comparați în mod obligatoriu cu `userPrincipalName` din AD.

## Interogare — numai diferențe de capitalizare (MySQL/MariaDB)

```sql
SELECT
  u.username,
  ua.value AS kerberos_principal,
  CONCAT(u.username, '@sts.nest') AS principal_estimat
FROM user_entity u
JOIN user_attribute ua ON ua.user_id = u.id
JOIN realm r ON r.id = u.realm_id
WHERE r.name = 'AD'
  AND u.enabled = 1
  AND ua.name = 'KERBEROS_PRINCIPAL'
  AND LOWER(ua.value) = LOWER(CONCAT(u.username, '@sts.nest'))
  AND BINARY ua.value <> BINARY CONCAT(u.username, '@sts.nest')
ORDER BY u.username;
```

Această interogare folosește sintaxa `BINARY` din MySQL/MariaDB; nu se execută neschimbată în PostgreSQL.

## Interpretare și decizie

| Situație | Decizie |
|---|---|
| Diferă doar `@STS.NEST` versus `@sts.nest`; autentificarea funcționează | **Nu modificați nimic**; consemnați diferența de reprezentare |
| UPN-ul a fost schimbat, iar `KERBEROS_PRINCIPAL` conține numele vechi | Verificați mapperul și sincronizarea LDAP — [P-KC-03](./03-Mapper-Kerberos-LDAP.md) |
| Valoarea din DB este corectă, dar interfața afișează date vechi | Verificați cache-ul — [P-KC-02](./02-Stergere-cache-utilizatori.md) |
| Autentificarea Kerberos eșuează | Investigați principalul efectiv din tichet, LDAP, SPN, keytab și logurile Keycloak; nu considerați capitalizarea singura cauză |

## Ce NU facem

- Nu schimbăm `kerberosRealm=STS.NEST` în `sts.nest` pentru uniformizare cosmetică.
- Nu executăm `UPDATE` direct pe `user_attribute` pentru simple diferențe de litere mari/mici.
- Nu ștergem și nu recreăm utilizatori doar pentru a modifica formatul principalului.
- Nu considerăm diferența `username` vs `KERBEROS_PRINCIPAL` drept eroare fără verificarea UPN-ului efectiv din AD.

## Proceduri conexe

- [P-KC-01 — CLI](./01-Logare-CLI-kcadm.md)
- [P-KC-02 — Cache](./02-Stergere-cache-utilizatori.md)
- [P-KC-03 — Mapper Kerberos](./03-Mapper-Kerberos-LDAP.md)
- [Înapoi la index](./00-Index-proceduri-administrare-Keycloak.md)

## Referințe

- [Keycloak 26.6.2 — KerberosPrincipalAttributeMapper.java](https://github.com/keycloak/keycloak/blob/26.6.2/federation/ldap/src/main/java/org/keycloak/storage/ldap/mappers/KerberosPrincipalAttributeMapper.java)
- [Keycloak 26.6.2 — LDAPStorageProvider.java](https://github.com/keycloak/keycloak/blob/26.6.2/federation/ldap/src/main/java/org/keycloak/storage/ldap/LDAPStorageProvider.java)
- [Oracle — Kerberos realm naming conventions](https://docs.oracle.com/en/java/javase/25/security/security-developer-guide.pdf)
