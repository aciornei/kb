# P-KC-03 — Verificarea și administrarea mapperului Kerberos LDAP

| Metadate | Valoare |
|---|---|
| Serviciu | Keycloak — Identity & SSO |
| Încadrare | 05 — Proceduri / Runbooks |
| Scop | Menținerea atributului `KERBEROS_PRINCIPAL` în concordanță cu UPN-ul din AD |
| Versiune de referință | 26.6.2 |
| Revizie | 1.0 — 13.11.2026 |
| Risc | Citire: scăzut. Creare mapper / Full Sync: modificări în producție — schimbare controlată |

## Context

În mediul curent, providerul LDAP este configurat `READ_ONLY`, cu:

- `allowKerberosAuthentication=true`
- `krbPrincipalAttribute=userPrincipalName`
- `kerberosRealm=STS.NEST`

După redenumiri în AD, unele conturi au păstrat vechiul `KERBEROS_PRINCIPAL` local. În urma diagnosticării a fost adăugat mapperul `kerberos-principal-attribute-mapper`, urmat de un Full Sync.

Mapperul din Keycloak 26.6.2 compară valoarea LDAP cu atributul local și o actualizează dacă diferă. Nu rescrie automat fiecare utilizator la orice cerere; actualizarea ține de mecanismele de import/sincronizare LDAP.

## A. Verificarea configurației (numai citire)

**1. Autentificați CLI**, conform [P-KC-01](./01-Logare-CLI-kcadm.md).

**2. Identificați ID-ul providerului LDAP:**

```bash
/opt/keycloak/bin/kcadm.sh get components -r AD \
  -q type=org.keycloak.storage.UserStorageProvider | \
  jq -r '.[] | select(.providerId == "ldap") | [.id, .name] | @tsv'
```

**3. Setați variabila shell cu UUID-ul afișat:**

```bash
LDAP_ID="UUID_REAL_AL_PROVIDERULUI_LDAP"
```

**4. Verificați opțiunile Kerberos ale providerului:**

```bash
/opt/keycloak/bin/kcadm.sh get components/$LDAP_ID -r AD | \
  jq '{name, providerId, config: (.config | with_entries(select(.key | test("kerberos|principal|import"; "i"))))}'
```

**5. Listați mapperele asociate providerului:**

```bash
/opt/keycloak/bin/kcadm.sh get components -r AD -q "parent=$LDAP_ID" | \
  jq -r '.[] | [.name, .providerId, .id] | @tsv'
```

`parent` trebuie să fie **UUID-ul providerului LDAP**, nu un UUID de mapper sau numele providerului. Dacă filtrul nu returnează rezultate, verificați variabila cu `echo "$LDAP_ID"`.

**6. Verificați existența exactă a mapperului:**

```bash
/opt/keycloak/bin/kcadm.sh get components -r AD -q "parent=$LDAP_ID" | \
  jq '.[] | select(.providerId == "kerberos-principal-attribute-mapper")'
```

Dacă apare, **nu creați un duplicat**.

## B. Crearea mapperului, dacă lipsește (schimbare controlată)

**Precondiții:** backup verificat al bazei **externe**, export al configurației providerului și aprobare de schimbare. Nu confundați snapshotul VM-ului SSO cu un backup al bazei de date de pe alt server.

```bash
/opt/keycloak/bin/kcadm.sh create components -r AD \
  -s 'name=Kerberos principal attribute mapper' \
  -s 'providerId=kerberos-principal-attribute-mapper' \
  -s 'providerType=org.keycloak.storage.ldap.mappers.LDAPStorageMapper' \
  -s "parentId=$LDAP_ID"
```

Verificați apariția sa repetând pasul A.6. Înregistrarea mapperului nu necesită în mod normal restart Keycloak.

## C. Sincronizare completă (schimbare controlată)

După ce confirmați configurația și planul de revenire:

```bash
/opt/keycloak/bin/kcadm.sh create \
  "user-storage/$LDAP_ID/sync?action=triggerFullSync" \
  -r AD
```

Operația poate modifica atributele locale ale utilizatorilor importați și trebuie urmărită până la final. Executați într-o perioadă cu activitate redusă și verificați rezultatul prin eșantionare: un utilizator redenumit, un utilizator nemodificat și un utilizator cu UPN în majuscule/minuscule.

**Important:** Full Sync nu este același lucru cu golirea cache-ului; consultați [P-KC-02](./02-Stergere-cache-utilizatori.md).

## D. Validare și revenire

- Verificați că mapperul există o singură dată și este asociat providerului corect.
- Comparați `KERBEROS_PRINCIPAL` local cu **UPN-ul real din AD**, nu exclusiv cu `username@sts.nest`.
- Verificați autentificarea Kerberos pentru un utilizator din domeniu și autentificarea prin formular pentru clienții configurați fără Kerberos.
- Dacă mapperul introdus recent provoacă probleme, după evaluarea impactului îl puteți elimina **doar după identificarea UUID-ului său** cu:

```bash
# Exemplu; executați doar după aprobare și cu UUID-ul mapperului, NU al LDAP-ului
/opt/keycloak/bin/kcadm.sh delete components/UUID_MAPPER -r AD
```

Ștergerea mapperului **nu inversează automat** actualizările deja făcute de Full Sync. Pentru revenire completă poate fi necesară restaurarea controlată a bazei externe.

## Probleme întâlnite

- Mapperul poate lipsi dacă opțiunile Kerberos au fost adăugate după configurarea inițială a LDAP.
- Mapperul `username` și alte mappere care scriu `username` trebuie verificate dacă există discrepanțe între `cn` și `sAMAccountName`, dar nu se modifică fără analiză separată.
- Dacă există diferențe numai de capitalizare, consultați [P-KC-04](./04-Kerberos-majuscule-minuscule.md).

## Proceduri conexe

- [P-KC-01 — CLI](./01-Logare-CLI-kcadm.md)
- [P-KC-02 — Cache utilizatori](./02-Stergere-cache-utilizatori.md)
- [P-KC-04 — Litere mari/mici](./04-Kerberos-majuscule-minuscule.md)
- [Înapoi la index](./00-Index-proceduri-administrare-Keycloak.md)

## Referințe

- [Keycloak — codul mapperului Kerberos, tag 26.6.2](https://github.com/keycloak/keycloak/blob/26.6.2/federation/ldap/src/main/java/org/keycloak/storage/ldap/mappers/KerberosPrincipalAttributeMapper.java)
- [Keycloak — Server Administration Guide, Storage provider operations](https://www.keycloak.org/docs/26.6.4/server_admin/)
