# KB → Outline Manual Linker v0.1.0

Extensie Chrome separată de KB → Outline Migrator și KB Inventory Reporter.

## Scop

Caută documente în Outline după titlul paginii Confluence KB curente. După alegere și verificare manuală, marchează în **KB** pagina cu `[M]`, un banner de status, responsabilul curent, data validării și linkul Outline. Salvează și `content property` cu cheia `outline-migrator`, în același format ca migratorul principal. **Nu modifică documentele Outline.**

## Instalare

1. Dezarhivați ZIP-ul într-un director stabil.
2. Chrome → `chrome://extensions` → activați **Developer mode**.
3. Alegeți **Load unpacked** și indicați exact directorul `KB-Outline-Manual-Linker` (acesta conține `manifest.json`).
4. Deschideți o pagină Confluence KB și autentificați-vă cu propriul cont.
5. Apăsați pictograma extensiei. Se deschide o filă dedicată; aceasta păstrează rezultatele căutării cât timp verificați documentele Outline.

## Setare Outline

1. În Outline: **Settings → API & Apps / API Keys → New API Key**.
2. Pentru scope restrâns, permiteți endpointurile API `documents.search_titles`, `documents.search`, `documents.info` (scope-urile sunt introduse separat prin spații, dacă versiunea instalată acceptă acest format). Dacă politica locală impune alte scope-uri, coordonați cu administratorul. Nu este necesară permisiunea de scriere în Outline pentru această extensie.
3. În fila extensiei completați **Adresa Outline** (URL-ul de bază) și tokenul personal; apăsați **Salvează și testează conexiunea** și acordați permisiunea de acces la domeniu.
4. Implicit, tokenul este stocat doar în sesiunea Chrome; bifa „Reține tokenul” îl persistă necriptat la nivelul extensiei (protejat doar de profilul de browser). Nu distribuiți tokenul.

## Utilizare

1. Navigați la pagina sursă KB (fără `[M]` / `[X]`).
2. Apăsați pictograma **KB → Outline Manual Linker**.
3. Extensia completează automat căutarea cu titlul KB. Puteți schimba textul când documentul Outline a fost redenumit.
4. Examinați rezultatele. **Deschideți** documentul pe care îl considerați corespondent și verificați conținutul.
5. Alegeți **radio** de lângă documentul corect, bifați confirmarea și apăsați **Marchează pagina KB cu [M]**.
6. Confirmați titlul, URL-ul, responsabilul și data. Extensia modifică exclusiv KB.
7. Reîncărcați pagina KB și verificați apariția `[M]`, statusului și linkului.
8. Regenerați Excelul din KB Inventory Reporter, care va prelua informațiile din antetul KB.

## Protecții

- Nu există asociere automată sau marcare fără selecție explicită.
- Pagini deja `[M]`, `[X]`, în stare `P` sau cu inconsistențe de stare sunt blocate pentru rescriere.
- Înainte de scriere sunt reverificate documentul Outline (după ID) și versiunea Confluence.
- Documentul Outline nu este modificat.
- Dacă scrierea proprietății `outline-migrator` eșuează **după** ce prefixul `[M]` a fost confirmat, se afișează avertizare; nu reluați marcarea orbește. Solicitați intervenția administratorului.
- Autorul original al migrării manuale **nu poate fi dedus** doar din căutarea titlului. `Responsabil` și `Data` înseamnă persoana și data **validării asocierii**.

## Limitări

- Căutarea poate returna mai multe documente cu nume identice; verificați documentul ales.
- Se văd doar documentele la care utilizatorul Outline are acces.
- Dacă API-ul `documents.search_titles` lipsește, se încearcă `documents.search`.
- Nu modifică backlinkul în documentul Outline și nu transferă fișiere.
- Filă KB sursă trebuie să rămână deschisă, ne-navigată, până la finalizarea marcării. Dacă navigați la altă pagină, redeschideți extensia din pagina nouă.
- Este o versiune pilot, verificată local, fără test de integrare pe serverele dumneavoastră.
