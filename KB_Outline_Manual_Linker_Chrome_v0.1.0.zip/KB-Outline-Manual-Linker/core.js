"use strict";
/* Pure helpers: intentionally no Chrome APIs, network, or DOM dependencies. */
const KBLinkCore = (() => {
  const cleanTitle = s => String(s || "").replace(/^\s*\[(?:M|X|NM)\]\s*/i, "").trim();
  const normalize = s => cleanTitle(s).normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[șş]/gi,"s").replace(/[țţ]/gi,"t").toLocaleLowerCase("ro").replace(/[^\p{L}\p{N}]+/gu," ").trim().replace(/\s+/g," ");
  function similarity(a,b) {
    const x=normalize(a),y=normalize(b);
    if(!x || !y) return 0;
    if(x===y)return 100;
    if(x.startsWith(y)||y.startsWith(x))return 80;
    const aa=new Set(x.split(" ")),bb=new Set(y.split(" "));
    let n=0;for(const w of aa)if(bb.has(w))n++;
    return Math.round(n/Math.max(aa.size,bb.size)*65);
  }
  function unwrapResults(body) {
    const data=body?.data??body;
    const arr=Array.isArray(data)?data:Array.isArray(data?.results)?data.results:Array.isArray(data?.documents)?data.documents:[];
    return arr.map(item=>{
      const d=item?.document??item?.data?.document??item;
      if(!d || typeof d!=="object")return null;
      const id=String(d.id||d.urlId||"").trim();
      const title=String(d.title||"").trim();
      if(!id || !title)return null;
      return {id,title,url:String(d.url||item?.url||""),collection:String(d.collection?.name||d.collectionName||item?.collection?.name||""),updatedAt:String(d.updatedAt||""),archived:!!d.archivedAt};
    }).filter(Boolean);
  }
  function linkFor(doc, outlineBase) {
    const base=new URL(outlineBase),href=doc.url?new URL(doc.url,base.href.replace(/\/$/,"")+"/"):new URL("doc/"+encodeURIComponent(doc.id),base.href.replace(/\/$/,"")+"/");
    if(href.origin!==base.origin || !["https:","http:"].includes(href.protocol))throw new Error("Documentul are un URL din afara serverului Outline configurat.");
    href.hash="";
    return href.href;
  }
  function esc(s) {return String(s??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&apos;");}
  function markBlock(user,date,url) {
    return `<ac:structured-macro ac:name="status" ac:schema-version="1"><ac:parameter ac:name="title">MIGRAT ÎN OUTLINE</ac:parameter><ac:parameter ac:name="colour">Green</ac:parameter></ac:structured-macro>`+
      `<p><strong>KB → Outline</strong> | Responsabil: ${esc(user)} | Data: ${esc(date)}</p>`+
      `<p><strong>Destinație Outline:</strong> <a href="${esc(url)}">${esc(url)}</a></p><hr />`;
  }
  function status(page,record){
    const p=String(page?.title||"").match(/^\s*\[(M|X)\](?:\s|$)/i)?.[1]?.toUpperCase()||"";
    const r=String(record?.status||"").toUpperCase();
    if(p && r && p!==r)return "CONFLICT";
    return p || r || "";
  }
  function day(d){const z=new Date(d);if(!Number.isFinite(z.getTime()))throw Error("Data invalidă.");return `${z.getFullYear()}-${String(z.getMonth()+1).padStart(2,"0")}-${String(z.getDate()).padStart(2,"0")}`;}
  return {cleanTitle,normalize,similarity,unwrapResults,linkFor,markBlock,status,day};
})();
if(typeof module!=="undefined"&&module.exports)module.exports=KBLinkCore;
