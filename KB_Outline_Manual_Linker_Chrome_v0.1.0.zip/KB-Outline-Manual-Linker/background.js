"use strict";
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab?.id) return;
  const u = chrome.runtime.getURL("match.html") + "?sourceTab=" + encodeURIComponent(tab.id);
  await chrome.tabs.create({url: u});
});
