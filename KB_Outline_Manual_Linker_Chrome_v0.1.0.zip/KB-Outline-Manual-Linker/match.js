"use strict";
const $=id=>document.getElementById(id);
const sourceTab=Number(new URL(location.href).searchParams.get("sourceTab")||0);
const state={kb:null,page:null,user:null,property:null,token:"",base:"",results:[],selectedId:"",busy:false,searchBusy:false,mode:"",nextOffset:0,more:false,searchQuery:"",searchBase:"",logs:[],readVersion:0};
function log(msg,level="INFO"){
  const t=new Date().toLocaleTimeString("ro-RO",{hour12:false});
  const line=`[${t}] ${level}: ${msg}`;
  state.logs.push(line);if(state.logs.length>400)state.logs.shift();
  $("log").textContent=state.logs.join("\n");$("log").scrollTop=$("log").scrollHeight;
}
function notice(msg,type=""){$("notice").textContent=msg;$("notice").className="notice"+(type?" "+type:"");}
function baseUrl(input){const u=new URL(String(input||"").trim());if(!["https:","http:"].includes(u.protocol)||u.username||u.password||u.search||u.hash)throw new Error("Introdu adresa HTTP(S) de bază Outline, fără parolă, query sau ancoră.");return u.origin+u.pathname.replace(/\/$/,"");}
function originPattern(base){return new URL(base).origin+"/*";}
function migrationStatus(){return KBLinkCore.status(state.page,state.property?.value||null);}
function updateActions(){
  const st=migrationStatus();
  const ready=!!state.page&&!st&&!!state.selectedId&&$("reviewed").checked&&!state.busy;
  $("mark").disabled=!ready;
  const block=$("kbStatus");block.hidden=!st;
  if(st){
    const record=state.property?.value;
    const info=record?.outlineUrl?"\nDestinație înregistrată: "+record.outlineUrl:"";
    block.textContent=st==="M"?"Pagina este deja marcată [M]. Asocierea repetată este blocată."+info:
      st==="X"?"Pagina este exclusă [X]. Asocierea este blocată.":
      st==="P"?"Există o migrare neterminată (P). Finalizeaz-o în migratorul principal înainte de asociere.":
      "Pagina are un conflict între titlu și registrul Confluence. Verifică manual înainte de modificare.";
  }
}
function selectResult(id){
  state.selectedId=id;$("reviewed").checked=false;
  for(const el of document.querySelectorAll('input[name="selectedDocument"]'))el.checked=el.value===id;
  const doc=state.results.find(x=>x.id===id);
  if(!doc){$("selectedInfo").textContent="Nu ai ales niciun document Outline.";updateActions();return;}
  let link="";try{link=KBLinkCore.linkFor(doc,state.base);}catch(e){notice(e.message,"error");}
  $("selectedInfo").replaceChildren();
  const title=document.createElement("strong");title.textContent=doc.title;
  const text=document.createElement("div");text.textContent="ID: "+doc.id;
  const a=document.createElement("a");a.href=link||"#";a.textContent=link||"URL indisponibil";a.target="_blank";a.rel="noopener noreferrer";
  $("selectedInfo").append(title,text,a);
  updateActions();
}
function scoreLabel(n){if(n>=100)return "Titlu identic";if(n>=80)return "Titlu apropiat";return "Potrivire posibilă";}
function renderResults(){
  const root=$("results");root.replaceChildren();
  if(!state.results.length){const d=document.createElement("div");d.className="empty";d.textContent="Niciun rezultat. Încearcă un termen mai scurt sau cuvinte-cheie din titlul KB.";root.append(d);}
  for(const [i,doc] of state.results.entries()){
    const tile=document.createElement("div");tile.className="result";
    const head=document.createElement("div");head.className="result-head";
    const radio=document.createElement("input");radio.type="radio";radio.name="selectedDocument";radio.value=doc.id;radio.id="doc"+i;radio.checked=doc.id===state.selectedId;
    radio.addEventListener("change",()=>selectResult(doc.id));
    const content=document.createElement("div");content.className="result-content";
    const title=document.createElement("label");title.className="result-title";title.htmlFor=radio.id;title.textContent=doc.title;
    const meta=document.createElement("div");meta.className="result-meta";
    const info=[];if(doc.collection)info.push("Colecție: "+doc.collection);if(doc.updatedAt)info.push("Modificat: "+doc.updatedAt.slice(0,10));if(doc.archived)info.push("Arhivat");
    meta.textContent=info.join(" · ")||"Document accesibil în Outline";
    const url=document.createElement("div");url.className="result-url";
    const a=document.createElement("a");
    try{a.href=KBLinkCore.linkFor(doc,state.base);a.textContent=a.href;a.target="_blank";a.rel="noopener noreferrer";}catch(e){a.textContent="Link invalid: "+e.message;radio.disabled=true;}
    url.append(a);content.append(title,meta,url);
    const score=KBLinkCore.similarity(state.page?.title||$("query").value,doc.title);
    const badge=document.createElement("span");badge.className="match-badge"+(score<80?" partial":"");badge.textContent=scoreLabel(score);
    head.append(radio,content,badge);tile.append(head);root.append(tile);
  }
  $("more").hidden=!state.more;
  updateActions();
}
async function outlineCall(op,data){
  const base=baseUrl($("outlineBase").value);const token=$("outlineToken").value.trim();
  if(!token)throw new Error("Lipsește tokenul personal Outline.");
  if(!await chrome.permissions.contains({origins:[originPattern(base)]}))throw new Error("Nu există permisiune pentru Outline. Folosește «Salvează și testează conexiunea».");
  const response=await fetch(base+"/api/"+op,{method:"POST",headers:{"Authorization":"Bearer "+token,"Content-Type":"application/json","Accept":"application/json"},body:JSON.stringify(data||{}),cache:"no-store"});
  const raw=await response.text();let json;
  try{json=JSON.parse(raw);}catch(_){const e=new Error("Outline a returnat HTTP "+response.status+" cu răspuns non-JSON (proxy/login?).");e.status=response.status;throw e;}
  if(!response.ok||json.success===false||json.ok===false){const e=new Error("Outline "+op+": HTTP "+response.status+" – "+String(json.message||json.error||JSON.stringify(json).slice(0,180)));e.status=response.status;throw e;}
  return json;
}
async function saveConfig(){
  const base=baseUrl($("outlineBase").value),token=$("outlineToken").value.trim();
  if(!token)throw Error("Token Outline lipsă.");
  state.base=base;state.token=token;
  await chrome.storage.local.set({outlineBase:base,rememberToken:$("rememberToken").checked});
  await chrome.storage.session.set({outlineToken:token});
  if($("rememberToken").checked){await chrome.storage.local.set({outlineToken:token});log("Token reținut local în profilul Chrome (fără criptare proprie).","ATENȚIE");}
  else await chrome.storage.local.remove("outlineToken");
}
async function restoreConfig(){
  const local=await chrome.storage.local.get(["outlineBase","rememberToken","outlineToken"]);
  const session=await chrome.storage.session.get("outlineToken");
  $("outlineBase").value=local.outlineBase||"";
  $("outlineToken").value=session.outlineToken||local.outlineToken||"";
  $("rememberToken").checked=!!local.rememberToken;
  state.base=local.outlineBase||"";state.token=$("outlineToken").value.trim();
}
async function loadPage(){
  if(!sourceTab)throw new Error("Lipsește fila de origine. Deschide pagina Confluence KB și apasă din nou extensia.");
  const kb=await KBBridge.detect(sourceTab);
  if(!kb.pageId)throw new Error("Fila sursă nu pare a fi o pagină KB validă (nu am găsit pageId).");
  const page=await KBBridge.getPage(sourceTab,kb.baseUrl,kb.pageId);
  const user=await KBBridge.getUser(sourceTab,kb.baseUrl);
  const property=await KBBridge.getProperty(sourceTab,kb.baseUrl,kb.pageId);
  state.kb=kb;state.page=page;state.user=user;state.property=property;state.readVersion=page.version?.number||0;
  $("kbTitle").textContent=page.title;
  const canonical=kb.baseUrl.replace(/\/$/,"")+"/pages/viewpage.action?pageId="+encodeURIComponent(kb.pageId);
  $("kbMeta").replaceChildren();
  const a=document.createElement("a");a.textContent="Deschide KB · pageId "+kb.pageId;a.href=canonical;a.target="_blank";a.rel="noopener noreferrer";
  $("kbMeta").append(a,document.createTextNode(" · "+(page.space?.key||"?")+" · versiunea "+state.readVersion));
  $("responsible").textContent="Confirmă: "+(user.displayName||user.username)+" ("+user.username+") · Data: "+KBLinkCore.day(new Date());
  $("query").value=KBLinkCore.cleanTitle(page.title);
  state.selectedId="";state.results=[];$("reviewed").checked=false;$("selectedInfo").textContent="Nu ai ales niciun document Outline.";
  $("searchInfo").textContent="";$("results").replaceChildren();$("more").hidden=true;
  const st=migrationStatus();
  if(st)notice("Pagina KB are deja stare "+st+". Căutarea este permisă, dar o nouă marcare este blocată.");
  else notice("Pagina KB a fost identificată: "+page.title);
  updateActions();
  log("Pagina KB citită: "+kb.pageId+" / "+page.title+"; utilizator "+user.username+"; status="+(st||"NEEVALUAT"));
}
async function runSearch(append=false){
  if(state.searchBusy)return;
  const query=$("query").value.trim();if(query.length<2)throw Error("Introdu cel puțin 2 caractere pentru căutarea în Outline.");
  state.searchBusy=true;$("search").disabled=true;$("more").disabled=true;
  try{
    if(!append){state.results=[];state.selectedId="";$("reviewed").checked=false;$("selectedInfo").textContent="Nu ai ales niciun document Outline.";state.nextOffset=0;state.mode="";state.searchQuery=query;state.searchBase=baseUrl($("outlineBase").value);}
    const offset=state.nextOffset,limit=50;
    let endpoint=state.mode||"documents.search_titles",body;
    try{body=await outlineCall(endpoint,{query:state.searchQuery,offset,limit});}
    catch(e){if(!state.mode && [400,404,405,422].includes(e.status)){
      log("Căutarea după titlu nu este disponibilă: încerc documents.search.","AVERTISMENT");
      endpoint="documents.search";body=await outlineCall(endpoint,{query:state.searchQuery,offset,limit});
    }else throw e;}
    state.mode=endpoint;
    const arr=KBLinkCore.unwrapResults(body),seen=new Set(state.results.map(x=>x.id));
    for(const doc of arr)if(!seen.has(doc.id)){seen.add(doc.id);state.results.push(doc);}
    state.results.sort((a,b)=>KBLinkCore.similarity(state.page?.title||state.searchQuery,b.title)-KBLinkCore.similarity(state.page?.title||state.searchQuery,a.title) || a.title.localeCompare(b.title,"ro"));
    state.nextOffset=offset+arr.length;
    const total=Number(body.pagination?.total??body.data?.pagination?.total);
    state.more=Number.isFinite(total)?state.nextOffset<total:arr.length===limit;
    $("searchInfo").textContent=`${state.results.length} documente găsite · Căutare ${endpoint} · ${state.more?"există și alte rezultate":"rezultate afișate integral"}`;
    renderResults();
    notice(state.results.length?"Alege documentul Outline care corespunde paginii KB și verifică-l înainte de marcare.":"Nu s-a găsit un document după acest titlu. Poți încerca o căutare mai scurtă.");
    log(`Căutare Outline «${state.searchQuery}» prin ${endpoint}: ${arr.length} rezultate (offset ${offset}).`);
  }finally{state.searchBusy=false;$("search").disabled=false;$("more").disabled=!state.more;}
}
async function connect(){
  // Permission request occurs immediately within the click handler, before other awaits.
  const base=baseUrl($("outlineBase").value);
  const permitted=await chrome.permissions.request({origins:[originPattern(base)]});
  if(!permitted)throw Error("Chrome nu a acordat accesul la domeniul Outline.");
  await saveConfig();
  notice("Conexiunea la Outline se verifică printr-o căutare…");
  await runSearch(false);
  log("Conexiunea la API Outline a fost verificată.");
}
async function markPage(){
  if(state.busy)return;
  if(!state.page||!state.user||!state.kb)throw Error("Pagina KB nu a fost citită.");
  if(migrationStatus())throw Error("Pagina KB nu mai este eligibilă pentru marcare; există deja o stare de migrare/excludere.");
  if(!$("reviewed").checked)throw Error("Confirmă că ai deschis și verificat documentul Outline.");
  if(baseUrl($("outlineBase").value)!==state.searchBase)throw Error("Domeniul Outline a fost schimbat după căutare. Reia căutarea și selecția.");
  const chosen=state.results.find(d=>d.id===state.selectedId);if(!chosen)throw Error("Selectează un document Outline.");
  state.busy=true;updateActions();
  try{
    // Verify the Outline document by immutable ID, not just an untrusted search URL.
    const dResponse=await outlineCall("documents.info",{id:chosen.id});
    const d0=dResponse.data?.document??dResponse.data??dResponse.document??dResponse;
    if(!d0||String(d0.id||"")!==chosen.id)throw Error("Outline a returnat alt identificator de document. Operația este anulată.");
    if(String(d0.title||"")!==chosen.title)throw Error("Titlul Outline a fost modificat după căutare. Reia căutarea și verificarea.");
    const outlineUrl=KBLinkCore.linkFor(d0,$("outlineBase").value);
    const visible=await KBBridge.detect(sourceTab);
    if(visible.pageId!==state.kb.pageId || visible.baseUrl!==state.kb.baseUrl)throw Error("Fila KB sursă a navigat la altă pagină. Revino la pagina inițială și reîncarcă extensia.");
    const current=await KBBridge.getPage(sourceTab,state.kb.baseUrl,state.kb.pageId);
    const property=await KBBridge.getProperty(sourceTab,state.kb.baseUrl,state.kb.pageId);
    const st=KBLinkCore.status(current,property?.value||null);
    if(st)throw Error("Pagina KB are deja stare "+st+". Reîncarcă, nu o marca de două ori.");
    if(current.version?.number!==state.readVersion||current.title!==state.page.title||current.body?.storage?.value!==state.page.body?.storage?.value)
      throw Error("Pagina KB a fost modificată după încărcare. Apasă Reîncarcă înainte să o marchezi.");
    const username=state.user.displayName||state.user.username,iso=KBLinkCore.day(new Date());
    const text=`Pagina KB: ${current.title}\nDocument ales: ${d0.title}\n${outlineUrl}\nResponsabil asociere: ${username}\nData: ${iso}\n\nVei adăuga [M] în KB, fără să modifici Outline. Confirmi?`;
    if(!window.confirm(text)){log("Marcarea a fost anulată de utilizator.");return;}
    const title="[M] "+KBLinkCore.cleanTitle(current.title);
    const body=KBLinkCore.markBlock(username,iso,outlineUrl)+String(current.body?.storage?.value||"");
    log("Actualizare KB: PUT pageId "+state.kb.pageId+", versiune "+(current.version?.number+1)+"; document Outline ID "+d0.id);
    await KBBridge.updatePage(sourceTab,state.kb.baseUrl,state.kb.pageId,title,body,current.version.number);
    const checked=await KBBridge.getPage(sourceTab,state.kb.baseUrl,state.kb.pageId);
    if(checked.title!==title)throw Error("KB a răspuns la actualizare, dar [M] nu este confirmat la recitire. Verifică pagina.");
    const stamp=new Date().toISOString();
    const record={status:"M",kbPageId:state.kb.pageId,outlineId:d0.id,outlineUrl,
      migratedBy:state.user.username,migratedAt:stamp,validatedAt:stamp,method:"manual-association"};
    let propError="";
    try{await KBBridge.setProperty(sourceTab,state.kb.baseUrl,state.kb.pageId,record);}
    catch(e){propError=String(e.message||e);log("[M] a fost scris în KB, dar salvarea Content Property a eșuat: "+propError,"AVERTISMENT");}
    state.page=checked;state.property=propError?null:{value:record};state.readVersion=checked.version.number;
    $("kbTitle").textContent=checked.title;$("reviewed").checked=false;
    updateActions();
    const message="Pagina KB a fost marcată [M].\nDestinație: "+outlineUrl+(propError?"\nATENȚIE: registrul outline-migrator nu s-a salvat. " + propError:"");
    notice(message,propError?"error":"ok");log("Marcare [M] confirmată pe pagina KB. "+outlineUrl);
  }finally{state.busy=false;updateActions();}
}
function handle(fn){return async()=>{try{await fn();}catch(e){const msg=e.message||String(e);notice(msg,"error");log(msg,"EROARE");}};}
$("refresh").addEventListener("click",handle(async()=>{await loadPage();if($("outlineToken").value.trim()&&$("outlineBase").value.trim())await runSearch();}));
$("connect").addEventListener("click",handle(connect));
$("search").addEventListener("click",handle(async()=>{await runSearch(false);}));
$("more").addEventListener("click",handle(async()=>{await runSearch(true);}));
$("mark").addEventListener("click",handle(markPage));
$("reviewed").addEventListener("change",updateActions);
$("query").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();$("search").click();}});
$("copyLog").addEventListener("click",handle(async()=>{await navigator.clipboard.writeText(state.logs.join("\n"));notice("Jurnal copiat. Nu conține tokenul Outline.","ok");}));
handle(async()=>{
  await restoreConfig();await loadPage();
  const base=$("outlineBase").value.trim(),token=$("outlineToken").value.trim();
  if(base&&token&&await chrome.permissions.contains({origins:[originPattern(base)]}))await runSearch(false);
  else notice("Pagina KB este gata. Configurează Outline, apoi apasă «Salvează și testează conexiunea».");
})();
