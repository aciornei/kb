# Scenarii de acceptanță – KB → Outline Manual Linker 0.1.0

## Migrare manuală normală
- Sursă KB fără prefix, cu pageId și versiune.
- Titlu găsit în Outline (exact sau apropiat).
- Deschideți linkul, verificați documentul, alegeți radio, bifați confirmarea.
- După apăsare, documentul Outline NU este editat; titlul KB devine `[M] ...`.
- Banner: `MIGRAT ÎN OUTLINE`, rând `KB → Outline | Responsabil: ... | Data: YYYY-MM-DD`, hyperlink Outline.
- Content property `outline-migrator` primește `status:M`, `outlineId`, `outlineUrl`, `migratedBy`, `validatedAt`, `method:manual-association`.

## Siguranță
- Fără selecție: buton [M] dezactivat.
- Selecție fără bifă: buton [M] dezactivat.
- `[M]` sau `[X]` existent: nu permite rescrierea.
- Registru `P`: blocat; se finalizează în migratorul principal.
- Conflict titlu/registru: blocat.
- Se schimbă versiunea KB înainte de validare: operația se oprește.
- Se schimbă titlul documentului Outline: operația se oprește.
- Permisiune/Token Outline invalid: căutarea eșuează; nu se modifică KB.
- Confluence PUT a reușit, dar salvarea property a eșuat: avertizare explicită, fără repetarea marcării.

## Căutare
- Titlu cu diacritice, fără diacritice, cu `[M]`/`[X]`: comparația ignoră prefixele/diacriticele, dar pagina marcată nu poate fi rescrisă.
- Mai multe titluri similare: radio, URL vizibil, alegere manuală, nu asociere automată.
- Fără rezultate: modificare query.
- Server fără `documents.search_titles`: fallback `documents.search` la HTTP 400/404/405/422.
- Mai mult de 50 rezultate: buton „Încarcă alte rezultate”.

## Compatibilitate raport Excel
- După `[M]`, KB Inventory Reporter trebuie să arate `MIGRATĂ`, responsabil, dată și link Outline.
- Verificați că textul inițial al paginii KB este păstrat integral sub bannerul adăugat.
